# -*- coding: utf-8 -*-
"""
按钮裁切审查：遍历主程序、登录/改密、渲染参数、个人中心、管理员全部页面，
对比按钮样式内容区与实际文字尺寸，输出不合格按钮。
运行：python tests/audit_buttons.py   （需要桌面环境）
"""
import os
import shutil
import sys
import tempfile

os.environ.setdefault("QT_QPA_PLATFORM", "windows")
import PyQt5
os.environ.setdefault(
    "QT_PLUGIN_PATH",
    os.path.join(os.path.dirname(PyQt5.__file__), "Qt5", "plugins"),
)

TMP = tempfile.mkdtemp(prefix="jtkc_audit_")
os.environ["JTKC_DATA_DIR"] = TMP
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))

from PyQt5.QtCore import QSettings
from PyQt5.QtWidgets import (
    QApplication, QPushButton, QStyle, QStyleOptionButton, QMessageBox
)
from PIL import Image, ImageDraw

app = QApplication([])

QMessageBox.information = staticmethod(lambda *a, **k: QMessageBox.Ok)
QMessageBox.warning = staticmethod(lambda *a, **k: QMessageBox.Ok)
QMessageBox.critical = staticmethod(lambda *a, **k: QMessageBox.Ok)
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.Yes)
QMessageBox.exec_ = lambda self, *a, **k: 0

from ui import theme

theme.apply_theme(app)

from core import auth, repo
from core.models import init_db

init_db()
assert auth.create_account("审核用户")[0]
user, _ = auth.authenticate("审核用户", auth.DEFAULT_PASSWORD)
auth.reset_password(user["id"], "Passw0rd123")
user, _ = auth.authenticate("审核用户", "Passw0rd123")


def make_sample():
    width, height = 900, 600
    img = Image.new("RGB", (width, height))
    draw = ImageDraw.Draw(img)
    top, bottom = (240, 190, 130), (45, 58, 90)
    for y in range(height):
        t = (y / (height - 1)) ** 0.9
        color = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
        draw.line([(0, y), (width, y)], fill=color)
    draw.ellipse([width * 0.6, height * 0.2, width * 0.6 + 130,
                  height * 0.2 + 130], fill=(255, 232, 180))
    draw.polygon([(0, height * 0.72), (width * 0.3, height * 0.5),
                  (width * 0.6, height * 0.85), (0, height)], fill=(35, 42, 58))
    draw.polygon([(width * 0.35, height * 0.9), (width * 0.72, height * 0.62),
                  (width, height * 0.78), (width, height), (width * 0.35, height)],
                 fill=(26, 31, 44))
    return img


img_dir = os.path.join(TMP, "imgs")
os.makedirs(img_dir, exist_ok=True)
sample = os.path.join(img_dir, "sample.png")
make_sample().save(sample)
for i in range(3):
    dst = os.path.join(img_dir, f"审核{i}.png")
    make_sample().save(dst)
    repo.add_modification(
        user["id"], sample, dst,
        '{"scale":2,"local":true,"regions":[{"x":0.6,"y":0.5,"w":0.3,"h":0.3}]}',
    )

issues = []
checked = []


def check_buttons(root, context):
    for btn in root.findChildren(QPushButton):
        text = btn.text()
        if not text or btn.width() <= 0 or btn.height() <= 0:
            continue
        opt = QStyleOptionButton()
        btn.initStyleOption(opt)
        rect = btn.style().subElementRect(
            QStyle.SE_PushButtonContents, opt, btn
        )
        fm = btn.fontMetrics()
        lines = text.splitlines() or [""]
        need_w = max(fm.horizontalAdvance(line) for line in lines)
        need_h = fm.height() * len(lines)
        checked.append((context, text, btn.width(), btn.height(),
                        rect.width(), rect.height(), need_w, need_h))
        if need_w > rect.width() + 1 or need_h > rect.height() + 1:
            issues.append((context, text, btn.width(), btn.height(),
                           rect.width(), rect.height(), need_w, need_h))


app.processEvents()

from app_main import MainWindow, LoginDialog, ResetPasswordDialog

main = MainWindow()
main.settings = QSettings("JTKC-Audit", "app")
main.resize(800, 533)
main.show()
app.processEvents()
check_buttons(main, "主程序-未登录")

main.session.set_user(user)
main._apply_logged_in()
app.processEvents()
check_buttons(main, "主程序-已登录")

login = LoginDialog(main)
login.show()
app.processEvents()
check_buttons(login, "登录对话框")
login.close()

reset = ResetPasswordDialog(user, main)
reset.show()
app.processEvents()
check_buttons(reset, "改密对话框")
reset.close()

from ui.render_dialog import RenderDialog

rd = RenderDialog(
    {"scale": 2, "local": True,
     "regions": [{"x": 0.6, "y": 0.5, "w": 0.3, "h": 0.3}]},
    os.path.join(img_dir, "审核0.png"), main,
)
rd.show()
app.processEvents()
check_buttons(rd, "渲染参数")
rd.close()

from pages.profile_page import ProfilePage

profile = ProfilePage(user["id"])
profile.resize(667, 507)
profile.show()
app.processEvents()
check_buttons(profile, "个人中心-修改记录")
profile._switch_tab(1)
app.processEvents()
check_buttons(profile, "个人中心-账号设置")
profile.close()

from admin_main import AdminWindow

admin = AdminWindow()
admin.resize(853, 547)
admin.show()
app.processEvents()
for index, name in enumerate(
    ["运营概览", "注册账号", "员工管理", "账号管理", "操作日志"]
):
    admin.set_page(index)
    app.processEvents()
    check_buttons(admin, f"管理员-{name}")

admin.set_page(2)
admin.employees_page.open_detail(user["id"])
app.processEvents()
check_buttons(admin, "管理员-员工详情")
admin.close()

from app_main import BatchProgressDialog

progress = BatchProgressDialog(2)
progress.show()
app.processEvents()
check_buttons(progress, "批量进度")
progress.close()

print(f"CHECKED: {len(checked)}  ISSUES: {len(issues)}")
for item in issues:
    ctx, text, w, h, cw, ch, nw, nh = item
    print(
        f"[{ctx}] '{text}' button={w}x{h} content={cw}x{ch} "
        f"text={nw}x{nh}"
    )

shutil.rmtree(TMP, ignore_errors=True)
sys.exit(1 if issues else 0)
