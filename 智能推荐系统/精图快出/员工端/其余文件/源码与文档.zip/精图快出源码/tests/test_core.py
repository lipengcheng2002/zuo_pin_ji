# -*- coding: utf-8 -*-
"""核心业务自动化测试：python -m unittest discover -s tests -v"""

import os
import shutil
import sqlite3
import sys
import tempfile
import unittest

TMP = tempfile.mkdtemp(prefix="jtkc_test_")
os.environ["JTKC_DATA_DIR"] = TMP
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))

from core import audit, auth, backup, render_params, repo  # noqa: E402
from core.config import BACKUP_DIR, DB_PATH  # noqa: E402
from core.models import get_connection, init_db  # noqa: E402
from ui.export import write_csv  # noqa: E402
from utils import engine  # noqa: E402

_counter = [0]


def unique_name(prefix="测试"):
    _counter[0] += 1
    return f"{prefix}{_counter[0]:03d}"


class CoreTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        assert init_db(), "数据库初始化失败"
        print("测试数据库:", DB_PATH)

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(TMP, ignore_errors=True)

    def _create_active_user(self):
        name = unique_name()
        ok, msg = auth.create_account(name)
        self.assertTrue(ok, msg)
        user, err = auth.authenticate(name, auth.DEFAULT_PASSWORD)
        self.assertIsNotNone(user, err)
        self.assertTrue(user["must_reset"])
        ok, msg = auth.reset_password(user["id"], "Passw0rd123")
        self.assertTrue(ok, msg)
        user, err = auth.authenticate(name, "Passw0rd123")
        self.assertIsNotNone(user, err)
        self.assertFalse(user["must_reset"])
        return user

    def test_account_lifecycle(self):
        name = unique_name("生命周期")
        ok, _ = auth.create_account(name)
        self.assertTrue(ok)
        ok, msg = auth.create_account(name)
        self.assertFalse(ok)
        self.assertIn("已存在", msg)

        user, err = auth.authenticate(name, "wrong")
        self.assertIsNone(user)
        self.assertIn("密码错误", err)

        user, err = auth.authenticate(name, auth.DEFAULT_PASSWORD)
        self.assertIsNotNone(user, err)
        self.assertTrue(user["must_reset"])

        self.assertFalse(auth.validate_password("12345678")[0])
        self.assertFalse(auth.validate_password("abcdefgh")[0])
        self.assertFalse(auth.validate_password("a1b2")[0])
        self.assertTrue(auth.validate_password("Passw0rd123")[0])

        ok, msg = auth.reset_password(user["id"], "12345678")
        self.assertFalse(ok)
        ok, msg = auth.reset_password(user["id"], "Newpass123")
        self.assertTrue(ok, msg)

        old, _ = auth.authenticate(name, auth.DEFAULT_PASSWORD)
        self.assertIsNone(old)
        user, err = auth.authenticate(name, "Newpass123")
        self.assertIsNotNone(user, err)
        self.assertFalse(user["must_reset"])

        ok, msg = auth.change_password(user["id"], "bad", "Another123")
        self.assertFalse(ok)
        ok, msg = auth.change_password(user["id"], "Newpass123", "Another123")
        self.assertTrue(ok, msg)
        user, err = auth.authenticate(name, "Another123")
        self.assertIsNotNone(user, err)

    def test_disable_and_delete(self):
        user = self._create_active_user()
        repo.set_active(user["id"], False)
        self.assertEqual(auth.get_account_state(user["id"]), "disabled")
        blocked, err = auth.authenticate(user["name"], "Passw0rd123")
        self.assertIsNone(blocked)
        self.assertIn("停用", err)

        repo.set_active(user["id"], True)
        self.assertEqual(auth.get_account_state(user["id"]), "ok")
        allowed, _ = auth.authenticate(user["name"], "Passw0rd123")
        self.assertIsNotNone(allowed)

        result = repo.delete_user(user["id"])
        self.assertEqual(result["name"], user["name"])
        self.assertEqual(auth.get_account_state(user["id"]), "deleted")
        gone, err = auth.authenticate(user["name"], "Passw0rd123")
        self.assertIsNone(gone)
        self.assertIn("尚未开通", err)

    def test_pagination_and_search(self):
        user = self._create_active_user()
        img_dir = os.path.join(TMP, "images")
        os.makedirs(img_dir, exist_ok=True)
        paths = []
        for i in range(25):
            path = os.path.join(img_dir, f"{user['name']}_{i}.png")
            with open(path, "wb") as f:
                f.write(b"png")
            repo.add_modification(user["id"], os.path.join(img_dir, "原图.jpg"), path)
            paths.append(path)

        rows, total = repo.page_user_modifications(user["id"], "", 1, 20)
        self.assertEqual(total, 25)
        self.assertEqual(len(rows), 20)
        rows2, total2 = repo.page_user_modifications(user["id"], "", 2, 20)
        self.assertEqual(total2, 25)
        self.assertEqual(len(rows2), 5)
        _, search_total = repo.page_user_modifications(
            user["id"], f"{user['name']}_1", 1, 20
        )
        self.assertGreaterEqual(search_total, 5)

        employees, emp_total = repo.page_employees(user["name"], "all", 1, 20)
        self.assertEqual(emp_total, 1)
        self.assertEqual(employees[0]["modify_count"], 25)

        repo.set_active(user["id"], False)
        disabled, disabled_total = repo.page_employees(user["name"], "disabled", 1, 20)
        self.assertEqual(disabled_total, 1)
        self.assertEqual(disabled[0]["name"], user["name"])
        repo.set_active(user["id"], True)

        deleted = repo.delete_user(user["id"])
        self.assertEqual(deleted["records"], 25)
        self.assertEqual(repo.remove_image_files(deleted["image_paths"]), 25)

    def test_audit(self):
        user = self._create_active_user()
        auth.authenticate(user["name"], "wrong-password")
        rows, total = audit.page_logs("", "", 1, 20)
        self.assertGreater(total, 0)
        self.assertIn("登录成功", audit.distinct_actions())
        failed, failed_total = audit.page_logs("", "登录失败", 1, 50)
        self.assertGreaterEqual(failed_total, 1)
        self.assertEqual(audit.role_label("admin"), "管理员")
        self.assertEqual(audit.role_label("user"), "员工")
        _, filtered = audit.page_logs(user["name"], "", 1, 20)
        self.assertGreaterEqual(filtered, 1)

    def test_backup(self):
        user = self._create_active_user()
        path = backup.create_backup()
        self.assertTrue(os.path.isfile(path))
        self.assertEqual(os.path.dirname(path), BACKUP_DIR)
        conn = sqlite3.connect(path)
        count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        conn.close()
        self.assertGreaterEqual(count, 1)
        self.assertGreaterEqual(repo.count_employees(), 1)

    def test_csv_export(self):
        path = os.path.join(TMP, "export.csv")
        write_csv(path, ["姓名", "次数"], [("张三", 3), ("李四", 0)])
        with open(path, "rb") as f:
            raw = f.read()
        self.assertTrue(raw.startswith(b"\xef\xbb\xbf"))
        text = raw.decode("utf-8-sig")
        self.assertIn("姓名,次数", text)
        self.assertIn("张三,3", text)

    def test_schema(self):
        with get_connection() as conn:
            tables = [
                row["name"]
                for row in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                )
            ]
            version = conn.execute("PRAGMA user_version").fetchone()[0]
            cols = [row["name"] for row in conn.execute("PRAGMA table_info(users)")]
            mod_cols = [
                row["name"]
                for row in conn.execute("PRAGMA table_info(modifications)")
            ]
        for table in ("users", "modifications", "audit_logs"):
            self.assertIn(table, tables)
        self.assertEqual(version, 3)
        self.assertNotIn("balance", cols)
        self.assertNotIn("free_count", cols)
        self.assertIn("params", mod_cols)

    def test_render_engine(self):
        from PIL import Image

        source = os.path.join(TMP, "render_source.png")
        Image.linear_gradient("L").resize((320, 200)).convert("RGB").save(source)

        params = {
            "scale": 1,
            "brightness": 20,
            "saturation": 30,
            "shadows": 20,
            "projection": 50,
        }
        output = os.path.join(TMP, "render_projection.png")
        self.assertTrue(engine.render_image(source, output, params))
        with Image.open(output) as result:
            self.assertGreater(result.width, 320)
            self.assertGreater(result.height, 200)

        summary = render_params.summary(params)
        self.assertIn("亮度+20", summary)
        self.assertIn("投影+50", summary)
        roundtrip = render_params.load_json(render_params.dump_json(params))
        self.assertEqual(roundtrip["projection"], 50)

        scale_output = os.path.join(TMP, "render_2x.png")
        self.assertTrue(engine.render_image(source, scale_output, {"scale": 2}))
        with Image.open(scale_output) as result:
            self.assertEqual((result.width, result.height), (640, 400))

        uniform = os.path.join(TMP, "uniform.png")
        Image.new("RGB", (200, 200), (128, 128, 128)).save(uniform)
        local_params = {
            "scale": 1,
            "local": True,
            "feather": 0,
            "brightness": 50,
            "regions": [{"x": 0.5, "y": 0.5, "w": 0.5, "h": 0.5}],
        }
        local_output = os.path.join(TMP, "render_local.png")
        self.assertTrue(engine.render_image(uniform, local_output, local_params))
        with Image.open(local_output) as result:
            inside = result.getpixel((160, 160))[0]
            outside = result.getpixel((20, 20))[0]
        self.assertGreater(inside, 170)
        self.assertLess(abs(outside - 128), 8)
        self.assertIn("局部×1", render_params.summary(local_params))

        events = []
        progress_output = os.path.join(TMP, "render_progress.png")
        self.assertTrue(engine.render_image(
            source, progress_output, {"scale": 1},
            progress=lambda percent, stage: events.append(percent),
        ))
        self.assertTrue(events)
        self.assertEqual(events[-1], 100)

        rgba = Image.new("RGBA", (100, 100), (200, 60, 60, 255))
        rgba.putpixel((0, 0), (0, 0, 0, 0))
        alpha_source = os.path.join(TMP, "alpha.png")
        rgba.save(alpha_source)
        alpha_output = os.path.join(TMP, "alpha_out.png")
        self.assertTrue(engine.render_image(alpha_source, alpha_output, {"scale": 1}))
        with Image.open(alpha_output) as result:
            self.assertEqual(result.mode, "RGBA")
            self.assertEqual(result.getpixel((0, 0))[3], 0)
            self.assertEqual(result.getpixel((50, 50))[3], 255)


if __name__ == "__main__":
    unittest.main(verbosity=2)
