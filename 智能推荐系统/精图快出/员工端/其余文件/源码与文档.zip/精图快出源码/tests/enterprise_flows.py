# -*- coding: utf-8 -*-
"""
企业级全流程审查（连续 5 轮）
用法：
    python tests\enterprise_flows.py            # 父进程，连续跑 5 轮
    python tests\enterprise_flows.py --child DIR # 单轮（内部使用）
覆盖：账号生命周期、登录锁定、改密、停用/删除、个人中心、批量/取消/中途停用、
渲染引擎、管理员全部页面、导出、备份、并发、SQL/CSV 注入、文件清理。
"""
import glob
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src")

if "--child" not in sys.argv:
    rounds = 5
    results = []
    for index in range(1, rounds + 1):
        data = tempfile.mkdtemp(prefix=f"jtkc_flow_{index}_")
        log = os.path.join(data, "child.log")
        print(f"\n===== 第 {index}/{rounds} 轮 =====", flush=True)
        with open(log, "w", encoding="utf-8", errors="replace") as err:
            proc = subprocess.run(
                [sys.executable, os.path.abspath(__file__), "--child", data],
                stdout=subprocess.PIPE, stderr=err, timeout=900,
                cwd=os.path.dirname(os.path.abspath(__file__)),
            )
        out = proc.stdout.decode("utf-8", errors="replace")
        print(out, end="")
        passed = "RESULT: PASS" in out
        results.append((index, passed, proc.returncode))
        if not passed:
            print(f"  [失败轮次日志] {log}（目录已保留）")
        else:
            shutil.rmtree(data, ignore_errors=True)
    ok = all(item[1] for item in results)
    print("\n================ 五轮汇总 ================")
    for index, passed, code in results:
        print(f"第 {index} 轮：{'PASS' if passed else 'FAIL'}（退出码 {code}）")
    print("FINAL:", "PASS" if ok else "FAIL")
    sys.exit(0 if ok else 1)

# -------------------- 单轮 --------------------
DATA = os.path.abspath(sys.argv[sys.argv.index("--child") + 1])
ITER = os.path.basename(DATA)
os.environ["JTKC_DATA_DIR"] = DATA
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
import PyQt5  # noqa: E402
os.environ.setdefault(
    "QT_PLUGIN_PATH",
    os.path.join(os.path.dirname(PyQt5.__file__), "Qt5", "plugins"),
)
sys.path.insert(0, SRC)

from PyQt5.QtCore import Qt, QSettings  # noqa: E402
from PyQt5.QtWidgets import (  # noqa: E402
    QApplication, QDialog, QFileDialog, QLineEdit, QMessageBox
)
from PIL import Image, ImageDraw  # noqa: E402

app = QApplication([])

from core import audit, auth, backup, render_params, repo  # noqa: E402
from core.config import BACKUP_DIR, DB_PATH, MAX_IMAGE_MB, PAGE_SIZE  # noqa: E402
from core.models import get_connection, init_db  # noqa: E402
from core.session import Session  # noqa: E402
from ui import theme  # noqa: E402
from ui.export import export_csv, write_csv  # noqa: E402
from ui.imageutils import image_info  # noqa: E402
from utils import engine  # noqa: E402

import app_main  # noqa: E402
import admin_main  # noqa: E402
from app_main import (  # noqa: E402
    BatchProgressDialog, LoginDialog, MainWindow, ResetPasswordDialog
)
from pages.profile_page import ProfilePage  # noqa: E402
from ui import preview as preview_module  # noqa: E402
from ui.render_dialog import RenderDialog  # noqa: E402


class AuditSettings(QSettings):
    def __init__(self, *args, **kwargs):
        super().__init__("JTKC-Flow-Audit", f"iter-{ITER}")


app_main.QSettings = AuditSettings
admin_main.QSettings = AuditSettings
AuditSettings().clear()
theme.apply_theme(app)
assert init_db(), "数据库初始化失败"

PASS = 0
FAIL = 0
FAILS = []
MESSAGES = []
QUESTION_ANSWER = True
AUTO_CONFIRM_DELETE = True
OPEN_QUEUE = []
SAVE_QUEUE = []
LAST_SAVE_DEFAULT = ""
_counter = [0]
WINDOWS = []


def check(condition, label, detail=""):
    global PASS, FAIL
    if condition:
        PASS += 1
    else:
        FAIL += 1
        FAILS.append(label)
        print(f"FAIL: {label} {detail}")


def reset_dialogs():
    global MESSAGES, QUESTION_ANSWER, AUTO_CONFIRM_DELETE
    MESSAGES = []
    QUESTION_ANSWER = True
    AUTO_CONFIRM_DELETE = True


def _fake_question(parent, title, text, *args, **kwargs):
    MESSAGES.append(("question", title, text))
    return QMessageBox.Yes if QUESTION_ANSWER else QMessageBox.No


def _fake_info(kind):
    def inner(parent, title, text, *args, **kwargs):
        MESSAGES.append((kind, title, text))
        return QMessageBox.Ok
    return inner


def _fake_exec(self, *args, **kwargs):
    MESSAGES.append(("box", self.windowTitle(), self.text()))
    self._auto_clicked = None
    if AUTO_CONFIRM_DELETE:
        for button in self.buttons():
            if self.buttonRole(button) == QMessageBox.DestructiveRole:
                self._auto_clicked = button
                break
    return 0


def _fake_clicked(self):
    return getattr(self, "_auto_clicked", None)


QMessageBox.question = _fake_question
QMessageBox.information = _fake_info("info")
QMessageBox.warning = _fake_info("warning")
QMessageBox.critical = _fake_info("critical")
QMessageBox.exec_ = _fake_exec
QMessageBox.clickedButton = _fake_clicked


def _fake_open_names(*args, **kwargs):
    if OPEN_QUEUE:
        return OPEN_QUEUE.pop(0)
    return [], ""


def _fake_open_one(*args, **kwargs):
    if OPEN_QUEUE:
        return OPEN_QUEUE.pop(0)
    return "", ""


def _fake_save(*args, **kwargs):
    global LAST_SAVE_DEFAULT
    LAST_SAVE_DEFAULT = args[2] if len(args) > 2 else kwargs.get("directory", "")
    if SAVE_QUEUE:
        return SAVE_QUEUE.pop(0)
    return "", ""


QFileDialog.getOpenFileNames = _fake_open_names
QFileDialog.getOpenFileName = _fake_open_one
QFileDialog.getSaveFileName = _fake_save
preview_module.QMessageBox.question = _fake_question
preview_module.QMessageBox.information = _fake_info("info")
preview_module.QMessageBox.warning = _fake_info("warning")
preview_module.QMessageBox.critical = _fake_info("critical")
preview_module.ImagePreviewDialog.exec_ = lambda self, *a, **k: 0
preview_module.save_image_as.__globals__["QFileDialog"] = QFileDialog


def process_events(seconds=0.03):
    app.processEvents()
    if seconds:
        time.sleep(seconds)


def unique(prefix="员工"):
    _counter[0] += 1
    return f"{prefix}{_counter[0]:03d}"


def make_user(name=None, password="Passw0rd123"):
    name = name or unique()
    ok, msg = auth.create_account(name)
    assert ok, msg
    user, err = auth.authenticate(name, auth.DEFAULT_PASSWORD)
    assert user, err
    ok, msg = auth.reset_password(user["id"], password)
    assert ok, msg
    user, err = auth.authenticate(name, password)
    assert user, err
    return user


def user_count():
    with get_connection() as conn:
        return conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]


def mod_count(user_id):
    return repo.count_user_modifications(user_id)


def outputs_for(paths):
    result = []
    for path in paths:
        base = os.path.splitext(path)[0]
        result.extend(sorted(glob.glob(glob.escape(base) + "_精修*.png")))
    return sorted(set(result))


def wait_worker(window, timeout=40):
    end = time.time() + timeout
    while time.time() < end:
        app.processEvents()
        if window.worker is None:
            app.processEvents()
            return True
        time.sleep(0.01)
    return False


def new_main(user=None, apply_login=True):
    window = MainWindow()
    WINDOWS.append(window)
    window.show()
    app.processEvents()
    window.render_settings = render_params.normalize({"scale": 1})
    if user:
        window.session.set_user(user)
        if apply_login:
            window._apply_logged_in()
    return window


def make_images():
    folder = os.path.join(DATA, "fixtures")
    os.makedirs(folder, exist_ok=True)
    base = Image.new("RGB", (360, 240), (120, 90, 60))
    draw = ImageDraw.Draw(base)
    for y in range(240):
        draw.line([(0, y), (360, y)], fill=(120 + y // 4, 90 + y // 6, 60 + y // 8))
    draw.ellipse([230, 40, 330, 140], fill=(250, 220, 150))
    draw.rectangle([30, 150, 180, 220], fill=(40, 60, 90))
    rgb = os.path.join(folder, "sample.png")
    base.save(rgb)
    jpg = os.path.join(folder, "sample.jpg")
    base.save(jpg, quality=90)
    bmp = os.path.join(folder, "sample.bmp")
    base.save(bmp)
    webp = os.path.join(folder, "sample.webp")
    try:
        base.save(webp)
    except Exception:
        webp = None
    rgba = Image.new("RGBA", (120, 120), (200, 60, 60, 255))
    rgba.putpixel((0, 0), (0, 0, 0, 0))
    rgba_path = os.path.join(folder, "alpha.png")
    rgba.save(rgba_path)
    dpi_path = os.path.join(folder, "dpi.png")
    Image.new("RGB", (200, 120), (100, 100, 100)).save(
        dpi_path, dpi=(300, 300)
    )
    wide = os.path.join(folder, "wide.png")
    Image.new("RGB", (3500, 100), (128, 128, 128)).save(wide)
    corrupt = os.path.join(folder, "corrupt.png")
    with open(corrupt, "wb") as f:
        f.write(b"not an image")
    unsupported = os.path.join(folder, "note.txt")
    with open(unsupported, "w", encoding="utf-8") as f:
        f.write("x")
    huge = os.path.join(folder, "huge.png")
    with open(huge, "wb") as f:
        f.seek(MAX_IMAGE_MB * 1024 * 1024 + 1)
        f.write(b"\0")
    return {
        "rgb": rgb, "jpg": jpg, "bmp": bmp, "webp": webp,
        "rgba": rgba_path, "dpi": dpi_path, "wide": wide,
        "corrupt": corrupt, "unsupported": unsupported, "huge": huge,
        "folder": folder,
    }


FIX = make_images()


# ==================== 账号与登录 ====================
def test_auth():
    global QUESTION_ANSWER
    reset_dialogs()
    for bad in ("", "   ", "x" * 21, "<b>粗体</b>", "a\u200bb", "a\tb"):
        ok, msg = auth.create_account(bad)
        check(not ok, f"非法姓名被拒绝: {bad!r}", msg)

    name = unique("账号")
    ok, _ = auth.create_account(name)
    check(ok, "开通账号")
    ok, msg = auth.create_account(name)
    check(not ok and "已存在" in msg, "重复姓名被拒绝", msg)
    ok, msg = auth.create_account(name.upper())
    check(not ok, "大小写变体重复被拒绝", msg)

    latin = unique("Case")
    check(auth.create_account(latin)[0], "开通英文姓名账号")
    ok, msg = auth.create_account(latin.lower())
    check(not ok, "英文姓名大小写重复被拒绝", msg)
    latin_user, err = auth.authenticate(latin, auth.DEFAULT_PASSWORD)
    check(latin_user is not None, "英文姓名默认密码登录", err)
    if latin_user:
        auth.reset_password(latin_user["id"], "Passw0rd123")
        check(auth.authenticate(latin.lower(), "Passw0rd123")[0] is not None,
              "英文姓名大小写不敏感登录")

    user, err = auth.authenticate("不存在的姓名", "x")
    check(user is None, "未开通姓名无法登录", err)
    user, err = auth.authenticate("' OR 1=1 --", "x")
    check(user is None, "SQL 注入无法登录", err)

    user, err = auth.authenticate(name, auth.DEFAULT_PASSWORD)
    check(user is not None and user["must_reset"], "默认密码登录要求改密", err)
    uid = user["id"]

    ok, msg = auth.reset_password(uid, auth.DEFAULT_PASSWORD)
    check(not ok, "默认密码不能作为新密码", msg)
    ok, msg = auth.reset_password(uid, "abcdefgh")
    check(not ok, "纯字母密码被拒绝", msg)
    ok, msg = auth.reset_password(uid, "12345678")
    check(not ok, "纯数字密码被拒绝", msg)
    ok, msg = auth.reset_password(uid, " Abc12345 ")
    check(not ok, "首尾空格密码被拒绝", msg)
    ok, msg = auth.reset_password(uid, "Passw0rd123")
    check(ok, "合法新密码设置成功", msg)
    user, err = auth.authenticate(name, auth.DEFAULT_PASSWORD)
    check(user is None, "改密后默认密码失效", err)
    user, err = auth.authenticate(name, "Passw0rd123")
    check(user is not None and not user["must_reset"], "新密码登录成功", err)
    check(auth.authenticate(name.lower(), "Passw0rd123")[0] is not None,
          "姓名大小写不敏感登录")

    ok, msg = auth.change_password(uid, "wrong", "Another123")
    check(not ok, "旧密码错误不能改密", msg)
    ok, msg = auth.change_password(uid, "Passw0rd123", "Passw0rd123")
    check(not ok and "相同" in msg, "新密码不能与当前密码相同", msg)
    ok, msg = auth.change_password(uid, "Passw0rd123", "Another123")
    check(ok, "正常修改密码", msg)
    check(auth.authenticate(name, "Passw0rd123")[0] is None, "旧密码失效")
    check(auth.authenticate(name, "Another123")[0] is not None, "新密码生效")

    # 锁定、解除、停用
    lock_name = unique("锁定")
    lock_user = make_user(lock_name)
    for _ in range(5):
        user, err = auth.authenticate(lock_name, "wrong-password")
    check(user is None and "锁定" in err, "连续 5 次错误后锁定", err)
    user, err = auth.authenticate(lock_name, "Passw0rd123")
    check(user is None and "锁定" in err, "锁定期内正确密码仍拒绝", err)
    with get_connection() as conn:
        conn.execute(
            "UPDATE users SET locked_until = ? WHERE id = ?",
            ((datetime.now() - timedelta(minutes=1)).isoformat(timespec="seconds"),
             lock_user["id"]),
        )
    user, err = auth.authenticate(lock_name, "Passw0rd123")
    check(user is not None, "锁定到期后可登录", err)
    for _ in range(5):
        auth.authenticate(lock_name, "wrong-password")
    check(repo.get_employee(lock_user["id"])["locked_until"] is not None,
          "再次锁定成功")
    repo.set_active(lock_user["id"], False)
    check(auth.authenticate(lock_name, "Passw0rd123")[0] is None, "停用后无法登录")
    ok, msg = auth.reset_password(lock_user["id"], "NewPass123")
    check(not ok and "停用" in msg, "停用状态不能重置密码", msg)
    repo.set_active(lock_user["id"], True)
    check(auth.authenticate(lock_name, "Passw0rd123")[0] is not None,
          "重新启用后登录并解除锁定")

    # 管理员解除锁定
    unlock_user = make_user(unique("解锁"))
    for _ in range(5):
        auth.authenticate(unlock_user["name"], "wrong")
    check(repo.unlock_user(unlock_user["id"]) is True, "管理员解除锁定")
    check(auth.authenticate(unlock_user["name"], "Passw0rd123")[0] is not None,
          "解除锁定后可登录")

    # 管理员重置密码：保留历史、强制首次改密、解除锁定
    reset_user = make_user(unique("重置"))
    folder = os.path.join(DATA, "reset_case")
    os.makedirs(folder, exist_ok=True)
    reset_out = os.path.join(folder, "out.png")
    Image.new("RGB", (40, 40), (60, 60, 60)).save(reset_out)
    repo.add_modification(reset_user["id"], FIX["rgb"], reset_out)
    for _ in range(5):
        auth.authenticate(reset_user["name"], "wrong")
    ok, msg = auth.reset_to_default(reset_user["id"])
    check(ok, "管理员重置密码", msg)
    reset_login, err = auth.authenticate(
        reset_user["name"], auth.DEFAULT_PASSWORD
    )
    check(reset_login is not None and reset_login["must_reset"],
          "重置后使用初始密码并强制改密", err)
    check(auth.authenticate(reset_user["name"], "Passw0rd123")[0] is None,
          "重置后旧密码失效")
    check(mod_count(reset_user["id"]) == 1, "重置密码保留历史记录")
    check(repo.get_employee(reset_user["id"])["locked_until"] is None,
          "重置密码解除锁定")
    logs, _ = audit.page_logs("", "重置密码", 1, 20)
    check(len(logs) >= 1, "重置密码写入审计")

    # 删除级联、文件清理、原图保留
    del_user = make_user(unique("删除"))
    folder = os.path.join(DATA, "delete_case")
    os.makedirs(folder, exist_ok=True)
    original = os.path.join(folder, "original.png")
    Image.new("RGB", (40, 40), (10, 20, 30)).save(original)
    generated = []
    for i in range(2):
        out = os.path.join(folder, f"out_{i}.png")
        Image.new("RGB", (40, 40), (50, 60, 70)).save(out)
        generated.append(out)
        repo.add_modification(del_user["id"], original, out)
    result = repo.delete_user(del_user["id"])
    check(result["records"] == 2, "删除账号返回记录数")
    repo.remove_image_files(result["image_paths"])
    check(all(not os.path.exists(p) for p in generated), "删除账号清理效果图")
    check(os.path.exists(original), "删除账号不删除原图")
    check(auth.get_account_state(del_user["id"]) == "deleted", "删除后状态为 deleted")
    check(auth.authenticate(del_user["name"], "Passw0rd123")[0] is None,
          "删除后无法登录")
    ok, _ = auth.create_account(del_user["name"])
    check(ok, "删除后同名可重新开通")

    # 密码存储与审计
    with get_connection() as conn:
        row = conn.execute(
            "SELECT pwd_hash, pwd_salt FROM users WHERE id = ?", (uid,)
        ).fetchone()
    check(row["pwd_hash"] != "Another123", "数据库不存明文密码")
    check(len(row["pwd_hash"]) == 64 and len(row["pwd_salt"]) == 32,
          "密码哈希/盐长度符合 PBKDF2")
    rows, _ = audit.page_logs("", "", 1, 500)
    text = " ".join((r["detail"] or "") + (r["target"] or "") for r in rows)
    check("Passw0rd123" not in text and "Another123" not in text,
          "审计日志不含密码明文")


# ==================== 主程序：校验 / 登录流 ====================
def test_main_validation():
    reset_dialogs()
    check(MainWindow._validate_image("/no/such/file.png") is not None,
          "不存在文件被拒绝")
    check(MainWindow._validate_image(FIX["unsupported"]) is not None,
          "不支持格式被拒绝")
    check(MainWindow._validate_image(FIX["corrupt"]) is not None,
          "损坏图片被拒绝")
    check(MainWindow._validate_image(FIX["huge"]) is not None,
          "超过 50MB 被拒绝")
    old_pixels = app_main.MAX_IMAGE_PIXELS
    app_main.MAX_IMAGE_PIXELS = 1000
    try:
        check(MainWindow._validate_image(FIX["rgb"]) is not None,
              "超过像素上限被拒绝")
    finally:
        app_main.MAX_IMAGE_PIXELS = old_pixels
    check(MainWindow._validate_image(FIX["rgb"]) is None, "合法 PNG 通过校验")
    check(MainWindow._validate_image(FIX["jpg"]) is None, "合法 JPG 通过校验")
    check(MainWindow._validate_image(FIX["bmp"]) is None, "合法 BMP 通过校验")
    if FIX["webp"]:
        check(MainWindow._validate_image(FIX["webp"]) is None,
              "合法 WEBP 通过校验")

    user = make_user(unique("登录流"))
    window = new_main()
    window.session.logout()
    window._apply_logged_out()

    def fake_open_login():
        window.session.set_user(user)
        window._apply_logged_in()

    window._open_login = fake_open_login
    folder = os.path.join(DATA, "login_continue")
    os.makedirs(folder, exist_ok=True)
    img = os.path.join(folder, "a.png")
    Image.new("RGB", (160, 100), (90, 120, 150)).save(img)
    OPEN_QUEUE.append(([img], ""))
    before = mod_count(user["id"])
    window._on_generate()
    check(wait_worker(window), "未登录点击生成会先登录并继续处理")
    check(mod_count(user["id"]) == before + 1, "登录后继续生成本次图片")

    QUESTION_ANSWER = True
    window._logout()
    check(not window.session.is_logged_in(), "退出登录清空会话")
    check(not window.welcome_label.isVisible(), "退出后隐藏欢迎信息")
    window.close()

    periodic_user = make_user(unique("定时踢"))
    periodic_window = new_main(periodic_user)
    repo.set_active(periodic_user["id"], False)
    periodic_window._periodic_state_check()
    check(not periodic_window.session.is_logged_in(),
          "定时检查停用账号并强制退出")
    periodic_window.close()

    reset = ResetPasswordDialog(
        {"id": 1, "name": "测试", "must_reset": True}, None
    )
    reset.show()
    app.processEvents()
    reset.new_edit.setText("NewPass123")
    reset.confirm_edit.setText("Different123")
    reset._submit()
    check("不一致" in reset.error_label.text(), "改密两次输入不一致提示")
    reset.close()


# ==================== 主程序：批量 ====================
def _batch_source(folder, name="a.png", size=(200, 120)):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, name)
    Image.new("RGB", size, (60, 100, 140)).save(path)
    return path


def _slow_hook(action):
    state = {"n": 0}
    real = app_main.render_image

    def wrapper(src, out, params, progress=None):
        state["n"] += 1
        if state["n"] == 1:
            action()
        time.sleep(0.06)
        return real(src, out, params, progress)

    return wrapper


def run_batch(window, paths, slow=None):
    real = app_main.render_image
    if slow is not None:
        app_main.render_image = slow
    try:
        window._start_batch(paths)
        finished = wait_worker(window)
    finally:
        app_main.render_image = real
    app.processEvents()
    return finished


def test_main_batch():
    reset_dialogs()
    user = make_user(unique("批量"))
    window = new_main(user)

    # 全部不可用
    before = user_count()
    window._start_batch([FIX["corrupt"], FIX["unsupported"]])
    app.processEvents()
    check(window.worker is None, "全部无效时不启动后台任务")
    check(any("图片不可用" in m[1] for m in MESSAGES), "全部无效时提示")

    # 混合有效/跳过
    folder = os.path.join(DATA, "batch_mix")
    valid = _batch_source(folder, "mix.png")
    start = mod_count(user["id"])
    check(run_batch(window, [valid, FIX["corrupt"]]), "混合批次完成")
    check(mod_count(user["id"]) == start + 1, "混合批次只处理有效图片")
    check(any("跳过 1" in m[2] for m in MESSAGES if m[0] == "box"),
          "混合批次汇总包含跳过数")

    # 重复路径去重
    folder = os.path.join(DATA, "batch_dup")
    dup = _batch_source(folder)
    start = mod_count(user["id"])
    check(run_batch(window, [dup, dup]), "重复路径批次完成")
    check(window._batch_total == 1, "重复路径去重为 1 张")
    check(mod_count(user["id"]) == start + 1, "重复路径只生成一次")

    # 输出重名
    folder = os.path.join(DATA, "batch_collision")
    src = _batch_source(folder, "collision.png")
    existing = os.path.join(folder, "collision_精修.png")
    Image.new("RGB", (10, 10), (1, 2, 3)).save(existing)
    check(run_batch(window, [src]), "输出重名批次完成")
    check(os.path.exists(os.path.join(folder, "collision_精修_1.png")),
          "已有输出时自动追加序号")
    check(image_info(existing)["width"] == 10, "已有输出文件未被覆盖")

    # 同目录同基名不同扩展
    folder = os.path.join(DATA, "batch_same_base")
    a_png = _batch_source(folder, "same.png")
    a_jpg = os.path.join(folder, "same.jpg")
    Image.new("RGB", (200, 120), (60, 100, 140)).save(a_jpg)
    start = mod_count(user["id"])
    check(run_batch(window, [a_png, a_jpg]), "同基名不同格式批次完成")
    outs = outputs_for([a_png, a_jpg])
    check(len(outs) == 2 and len(set(outs)) == 2, "同基名输出互不覆盖")
    check(mod_count(user["id"]) == start + 2, "同基名生成两条记录")

    # 单张成功 -> 预览
    folder = os.path.join(DATA, "batch_single")
    single = _batch_source(folder)
    FakePreview.count = 0
    old_preview = app_main.ImagePreviewDialog
    app_main.ImagePreviewDialog = FakePreview
    try:
        check(run_batch(window, [single]), "单张批次完成")
    finally:
        app_main.ImagePreviewDialog = old_preview
    check(FakePreview.count == 1, "单张成功后打开预览")

    # 多张成功 -> 汇总
    folder = os.path.join(DATA, "batch_multi")
    multi = [_batch_source(folder, f"m{i}.png") for i in range(3)]
    start = mod_count(user["id"])
    check(run_batch(window, multi), "多张批次完成")
    check(mod_count(user["id"]) == start + 3, "多张批次逐张保存记录")
    check(all(os.path.exists(p) for p in outputs_for(multi)), "多张输出齐全")

    # 取消：第一张后停止
    folder = os.path.join(DATA, "batch_cancel")
    cancel_paths = [_batch_source(folder, f"c{i}.png") for i in range(3)]
    start = mod_count(user["id"])
    slow = _slow_hook(lambda: window._cancel_batch())
    check(run_batch(window, cancel_paths, slow), "取消批次结束")
    check(mod_count(user["id"]) == start + 1, "取消后只保存已完成记录")
    check(len(outputs_for(cancel_paths)) == 1, "取消后不再生成后续图片")
    check(any("已取消" in m[2] for m in MESSAGES if m[0] == "box"),
          "取消汇总提示")
    check("已取消" in window.status_label.text(), "取消后状态文案")

    # 中途停用
    user2 = make_user(unique("停用批"))
    window2 = new_main(user2)
    folder = os.path.join(DATA, "batch_disable")
    paths = [_batch_source(folder, f"d{i}.png") for i in range(3)]
    slow = _slow_hook(lambda: repo.set_active(user2["id"], False))
    check(run_batch(window2, paths, slow), "停用批次结束")
    check(mod_count(user2["id"]) == 1, "停用后只处理当前一张")
    check(len(outputs_for(paths)) == 1, "停用后不再生成后续图片")
    check(not window2.session.is_logged_in(), "停用后强制退出登录")
    check("停用" in window2.status_label.text(), "停用后状态提示")
    window2.close()

    # 中途删除
    user3 = make_user(unique("删除批"))
    window3 = new_main(user3)
    folder = os.path.join(DATA, "batch_delete")
    paths = [_batch_source(folder, f"x{i}.png") for i in range(3)]
    slow = _slow_hook(lambda: repo.delete_user(user3["id"]))
    check(run_batch(window3, paths, slow), "删除批次结束")
    check(mod_count(user3["id"]) == 0, "删除后无修改记录")
    check(len(outputs_for(paths)) == 1, "删除后不再生成后续图片")
    check(not window3.session.is_logged_in(), "删除后强制退出登录")
    check("删除" in window3.status_label.text(), "删除后状态提示")
    window3.close()

    # 批次中关闭主窗口被拒绝
    user4 = make_user(unique("关闭批"))
    window4 = new_main(user4)
    folder = os.path.join(DATA, "batch_close")
    paths = [_batch_source(folder, f"z{i}.png") for i in range(2)]
    slow = _slow_hook(lambda: time.sleep(0.05))
    real = app_main.render_image
    app_main.render_image = slow
    try:
        window4._start_batch(paths)
        process_events(0.05)
        window4.close()
        check(window4.isVisible(), "批次进行中关闭窗口被拒绝")
        check(window4.worker is not None and window4.worker.isRunning(),
              "关闭被拒绝时后台任务仍在运行")
    finally:
        app_main.render_image = real
    window4._cancel_batch()
    check(wait_worker(window4), "关闭测试取消后结束")
    window4.close()

    # 关闭进度弹窗触发取消
    user5 = make_user(unique("进度批"))
    window5 = new_main(user5)
    folder = os.path.join(DATA, "batch_progress")
    paths = [_batch_source(folder, f"p{i}.png") for i in range(2)]
    slow = _slow_hook(lambda: time.sleep(0.05))
    real = app_main.render_image
    app_main.render_image = slow
    try:
        window5._start_batch(paths)
        process_events(0.05)
        dialog = window5.progress_dialog
        check(dialog is not None, "批量进度弹窗存在")
        if dialog is not None:
            dialog.close()
        check(wait_worker(window5), "关闭进度弹窗后批次结束")
    finally:
        app_main.render_image = real
    window5.close()

    # 账号开始时已停用
    user6 = make_user(unique("停用开始"))
    repo.set_active(user6["id"], False)
    window6 = new_main(user6, apply_login=False)
    folder = os.path.join(DATA, "batch_disabled_start")
    path = _batch_source(folder)
    window6._start_batch([path])
    app.processEvents()
    check(window6.worker is None, "账号停用时批次不启动")
    check(not window6.session.is_logged_in(), "账号停用时立即退出")
    check(not outputs_for([path]), "账号停用时未生成文件")
    window6.close()

    # 渲染失败
    user7 = make_user(unique("失败批"))
    window7 = new_main(user7)
    folder = os.path.join(DATA, "batch_fail")
    path = _batch_source(folder)
    start = mod_count(user7["id"])
    real = app_main.render_image
    app_main.render_image = lambda *a, **k: False
    try:
        window7._start_batch([path])
        wait_worker(window7)
    finally:
        app_main.render_image = real
    check(mod_count(user7["id"]) == start, "渲染失败不写修改记录")
    check("失败" in window7.status_label.text(), "渲染失败状态提示")
    window7.close()

    window.close()


class FakePreview:
    count = 0

    def __init__(self, *args, **kwargs):
        FakePreview.count += 1

    def exec_(self):
        return 0


# ==================== 个人中心 ====================
def add_records(user_id, count, folder_name):
    folder = os.path.join(DATA, folder_name)
    os.makedirs(folder, exist_ok=True)
    paths = []
    for i in range(count):
        out = os.path.join(folder, f"record_{i:02d}.png")
        Image.new("RGB", (220, 140), (50 + i, 90, 130)).save(out)
        repo.add_modification(
            user_id,
            os.path.join(folder, "原图.jpg"),
            out,
            render_params.dump_json({
                "scale": 1, "brightness": 10 + i % 20,
                "local": i % 3 == 0,
                "regions": [{"x": 0.1, "y": 0.1, "w": 0.4, "h": 0.4}],
            }),
        )
        paths.append(out)
    return paths


def test_profile():
    reset_dialogs()
    user = make_user(unique("记录"))
    paths = add_records(user["id"], 25, "profile_records")
    profile = ProfilePage(user["id"])
    WINDOWS.append(profile)
    profile.show()
    app.processEvents()
    check("25" in profile.count_label.text(), "个人中心记录总数")
    check(profile.table.rowCount() == PAGE_SIZE, "个人中心第一页 20 条")
    profile._on_page_changed(2)
    check(profile.table.rowCount() == 5, "个人中心第二页 5 条")
    profile.records_page = 1
    profile.records_search = "record_1"
    profile._load_records()
    check(0 < profile.records_total < 25, "个人中心搜索筛选")
    profile.records_search = ""
    profile._load_records()

    dest = os.path.join(DATA, "profile_export.csv")
    SAVE_QUEUE.append((dest, ""))
    profile._export_records()
    check(os.path.exists(dest), "个人中心导出 CSV")
    raw = open(dest, "rb").read()
    check(raw.startswith(b"\xef\xbb\xbf"), "CSV 带 UTF-8 BOM")
    check("修改时间" in raw.decode("utf-8-sig"), "CSV 表头正确")

    download = os.path.join(DATA, "downloaded.png")
    SAVE_QUEUE.append((download, ""))
    check(preview_module.save_image_as(profile, paths[0]), "个人中心下载图片")
    check(os.path.exists(download), "下载文件已保存")
    missing = os.path.join(DATA, "missing.png")
    check(not preview_module.save_image_as(profile, missing), "缺失图片下载失败")
    check(any("图片不存在" in m[1] for m in MESSAGES), "缺失图片提示")

    # 损坏参数不崩溃
    with get_connection() as conn:
        conn.execute(
            "UPDATE modifications SET params = ? WHERE user_id = ?",
            ("{bad json", user["id"]),
        )
    profile.refresh()
    app.processEvents()
    check(profile.table.rowCount() > 0, "损坏参数仍能显示记录")

    # 修改密码（UI）
    profile._switch_tab(1)
    profile.old_pwd.setText("wrong")
    profile.new_pwd.setText("NewPass456")
    profile.confirm_pwd.setText("NewPass456")
    profile._change_password()
    check(profile.pwd_error.isVisible(), "UI 改密旧密码错误提示")
    profile.old_pwd.setText("Passw0rd123")
    profile.new_pwd.setText("Passw0rd123")
    profile.confirm_pwd.setText("Passw0rd123")
    profile._change_password()
    check(profile.pwd_error.isVisible() and "相同" in profile.pwd_error.text(),
          "UI 改密不允许同密码")
    profile.new_pwd.setText("NewPass456")
    profile.confirm_pwd.setText("NewPass456")
    profile._change_password()
    check(not profile.pwd_error.isVisible(), "UI 改密成功无错误")
    check(auth.authenticate(user["name"], "NewPass456")[0] is not None,
          "UI 改密后新密码可登录")

    # 退出回调
    calls = []
    p2 = ProfilePage(
        user["id"], on_close=lambda: calls.append("close"),
        on_logout=lambda: calls.append("logout"),
    )
    WINDOWS.append(p2)
    global QUESTION_ANSWER
    QUESTION_ANSWER = False
    p2._logout()
    check(not calls, "取消退出登录不触发回调")
    QUESTION_ANSWER = True
    p2._logout()
    check(calls == ["close", "logout"], "确认退出触发关闭与退出回调")

    # 已删除账号
    dead = make_user(unique("已删"))
    repo.delete_user(dead["id"])
    p3 = ProfilePage(dead["id"])
    WINDOWS.append(p3)
    p3.show()
    app.processEvents()
    check("账号不存在" in p3.name_label.text(), "删除后个人中心显示账号不存在")
    check(p3.name_label.textFormat() == Qt.PlainText, "姓名标签使用纯文本")
    profile.close()


# ==================== 渲染引擎 ====================
def test_engine():
    out = os.path.join(DATA, "engine_1x.png")
    check(engine.render_image(FIX["rgb"], out, {"scale": 1}), "引擎 1x 渲染")
    with Image.open(out) as im:
        check(im.size == (360, 240), "1x 尺寸保持")
        check(im.mode == "RGB", "1x 输出 RGB")

    out2 = os.path.join(DATA, "engine_2x.png")
    check(engine.render_image(FIX["rgb"], out2, {"scale": 2}), "引擎 2x 渲染")
    with Image.open(out2) as im:
        check(im.size == (720, 480), "2x 尺寸翻倍")

    out_dpi = os.path.join(DATA, "engine_dpi.png")
    check(engine.render_image(FIX["dpi"], out_dpi, {"scale": 1}), "DPI 渲染")
    with Image.open(out_dpi) as im:
        dpi = im.info.get("dpi")
        check(dpi and abs(dpi[0] - 300) < 2, "DPI 保留", str(dpi))

    out_alpha = os.path.join(DATA, "engine_alpha.png")
    check(engine.render_image(FIX["rgba"], out_alpha, {"scale": 1}), "透明图渲染")
    with Image.open(out_alpha) as im:
        check(im.mode == "RGBA" and im.getpixel((0, 0))[3] == 0,
              "透明通道保留")
    out_alpha_proj = os.path.join(DATA, "engine_alpha_proj.png")
    check(engine.render_image(
        FIX["rgba"], out_alpha_proj, {"scale": 1, "projection": 50}
    ), "透明图投影渲染")
    with Image.open(out_alpha_proj) as im:
        check(im.mode == "RGB", "投影输出白底 RGB")

    uniform = os.path.join(DATA, "uniform.png")
    Image.new("RGB", (200, 200), (128, 128, 128)).save(uniform)
    local_out = os.path.join(DATA, "engine_local.png")
    local_params = {
        "scale": 1, "local": True, "feather": 0, "brightness": 50,
        "regions": [{"x": 0.5, "y": 0.5, "w": 0.5, "h": 0.5}],
    }
    check(engine.render_image(uniform, local_out, local_params), "局部渲染")
    with Image.open(local_out) as im:
        inside = im.getpixel((160, 160))[0]
        outside = im.getpixel((20, 20))[0]
    check(inside > 170 and abs(outside - 128) < 8, "局部区域内亮、区域外不变",
          f"{inside}/{outside}")

    projection = os.path.join(DATA, "engine_projection.png")
    check(engine.render_image(
        FIX["wide"], projection, {"scale": 2, "projection": 100}
    ), "超宽图投影渲染")
    with Image.open(projection) as im:
        check(max(im.size) <= 6000, "投影输出长边不超过 6000", str(im.size))

    progress = []
    progress_out = os.path.join(DATA, "engine_progress.png")
    check(engine.render_image(
        FIX["rgb"], progress_out, {"scale": 1},
        progress=lambda p, s: progress.append(p),
    ), "进度回调渲染")
    check(progress and progress[-1] == 100, "进度以 100 结束")

    check(not engine.render_image(
        FIX["corrupt"], os.path.join(DATA, "corrupt_out.png"), {"scale": 1}
    ), "损坏图片渲染返回 False")
    check(not engine.render_image(
        FIX["rgb"], os.path.join(DATA, "no_dir", "x.png"), {"scale": 1}
    ), "不存在的输出目录返回 False")
    check(not glob.glob(os.path.join(DATA, "no_dir", "*.tmp")),
          "失败后无临时文件残留")

    # 两个线程写同一输出：临时文件唯一，最终文件可用
    out_concurrent = os.path.join(DATA, "engine_concurrent.png")
    results = []
    barrier = threading.Barrier(2)

    def render_concurrent():
        barrier.wait()
        results.append(engine.render_image(
            FIX["jpg"], out_concurrent, {"scale": 1}
        ))

    threads = [threading.Thread(target=render_concurrent) for _ in range(2)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    check(all(results) and os.path.exists(out_concurrent),
          "并发写同一输出不损坏", str(results))
    try:
        with Image.open(out_concurrent) as im:
            check(im.width == 360, "并发输出可正常读取")
    except Exception as exc:
        check(False, "并发输出可正常读取", str(exc))

    # 区域参数规范化
    normalized = render_params.normalize({
        "scale": 9, "brightness": 999, "local": True, "feather": -5,
        "regions": [{"x": -1, "y": 0.9, "w": 3, "h": 3}] * 25,
    })
    check(normalized["scale"] == 2 and normalized["brightness"] == 100,
          "参数范围规范化")
    check(len(normalized["regions"]) <= render_params.MAX_REGIONS,
          "局部区域数量上限")
    check(normalized["feather"] == 0, "羽化范围规范化")

    # 渲染参数面板
    dialog = RenderDialog(
        {"scale": 1, "local": True,
         "regions": [{"x": 0.1, "y": 0.1, "w": 0.3, "h": 0.3}]},
        FIX["rgb"], None,
    )
    WINDOWS.append(dialog)
    dialog.show()
    app.processEvents()
    check(dialog.range_combo.currentIndex() == 1, "渲染面板读取局部模式")
    dialog.preview_widget.clear_regions()
    dialog._apply()
    check(dialog.region_error.isVisible(), "局部模式无区域时阻止应用")
    dialog.preview_widget.regions = [
        {"x": 0.1, "y": 0.1, "w": 0.2, "h": 0.2}
    ]
    dialog._update_region_controls()
    dialog._apply()
    check(dialog.result() == dialog.Accepted, "有区域时可应用")
    dialog.close()


# ==================== 管理员端 ====================
def test_admin():
    reset_dialogs()
    admin = admin_main.AdminWindow()
    WINDOWS.append(admin)
    admin.show()
    app.processEvents()
    check(admin.pages.count() == 5, "管理员端五个页面")
    check(admin.stack_index == 0, "默认打开运营概览")
    admin.set_page(0)
    check(admin.dashboard_page.card_users.value_label.text().isdigit(),
          "运营概览数据加载")

    # 备份与完整性
    path = backup.create_backup()
    check(os.path.isfile(path), "创建数据备份")
    conn = sqlite3.connect(path)
    check(conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok",
          "备份数据库完整")
    check(conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] > 0,
          "备份包含账号数据")
    conn.close()
    for _ in range(10):
        backup.create_backup()
    backups = glob.glob(os.path.join(BACKUP_DIR, "jingtu_*.db"))
    check(len(backups) <= 10, "备份保留最近 10 份", str(len(backups)))

    # 注册页
    admin.set_page(1)
    register = admin.register_page
    global QUESTION_ANSWER
    register.name_edit.setText("")
    register._register()
    check("请填写" in register.error_label.text(), "注册空姓名提示")
    bad = unique("注册")
    register.name_edit.setText("<b>坏</b>")
    register._register()
    check("尖括号" in register.error_label.text(), "注册尖括号姓名被拒绝")
    ok_name = unique("注册")
    register.name_edit.setText(ok_name)
    register._register()
    check(not register.error_label.text(), "注册合法姓名无错误")
    check(bool(register.notice.text()), "注册成功提示")
    register.name_edit.setText(ok_name.upper())
    register._register()
    check(bool(register.error_label.text()), "大小写变体重复注册提示")

    # 员工分页/筛选/详情
    employees = admin.employees_page
    admin.set_page(2)
    check(employees.stack.currentIndex() == 0, "员工管理默认列表")
    check(employees.list_total > 0, "员工列表有数据")
    employees.search_edit.setText(ok_name)
    employees._on_search()
    check(employees.list_total >= 1, "员工姓名搜索")
    employees.search_edit.clear()
    employees._on_search()
    if employees.list_total > PAGE_SIZE:
        employees._on_page_changed(2)
        check(employees.list_page == 2, "员工列表分页")
        employees._on_page_changed(1)

    detail_user = make_user(unique("明细"))
    add_records(detail_user["id"], 25, "admin_detail")
    employees.open_detail(detail_user["id"])
    app.processEvents()
    check(employees.stack.currentIndex() == 1, "打开员工详情")
    check(employees.detail_name.text() == detail_user["name"], "详情姓名正确")
    check(employees.detail_name.textFormat() == Qt.PlainText, "详情姓名纯文本")
    check(employees.detail_table.rowCount() == PAGE_SIZE, "详情第一页 20 条")
    employees._on_detail_page_changed(2)
    check(employees.detail_table.rowCount() == 5, "详情第二页 5 条")
    employees._on_detail_page_changed(1)

    dest = os.path.join(DATA, "detail_export.csv")
    SAVE_QUEUE.append((dest, ""))
    employees._export_detail()
    check(os.path.exists(dest), "导出员工明细")

    # 侧边栏回到列表
    employees.open_detail(detail_user["id"])
    admin.set_page(2)
    check(employees.stack.currentIndex() == 0, "点击员工管理回到列表")

    # 管理员重置密码（界面）
    employees.open_detail(detail_user["id"])
    QUESTION_ANSWER = True
    employees._reset_password()
    reset_login, err = auth.authenticate(
        detail_user["name"], auth.DEFAULT_PASSWORD
    )
    check(reset_login is not None and reset_login["must_reset"],
          "界面重置密码后要求首次改密", err)
    check(mod_count(detail_user["id"]) == 25, "界面重置密码保留明细")

    # 解锁
    lock_user = make_user(unique("锁定管"))
    for _ in range(5):
        auth.authenticate(lock_user["name"], "wrong")
    employees.open_detail(lock_user["id"])
    check(employees.detail_chip.text() == "登录锁定", "详情显示登录锁定")
    check(not employees.unlock_btn.isHidden(), "锁定账号显示解除按钮")
    check(employees._is_locked(repo.get_employee(lock_user["id"])),
          "员工列表识别登录锁定")
    employees._unlock()
    check(auth.authenticate(lock_user["name"], "Passw0rd123")[0] is not None,
          "管理员解除锁定后员工可登录")
    check(auth.authenticate(lock_user["name"], "Passw0rd123")[0] is not None,
          "解除锁定后重复登录正常")
    logs, _ = audit.page_logs("", "解除锁定", 1, 20)
    check(len(logs) >= 1, "解除锁定写入审计")

    # 账号管理：停用/启用
    accounts = admin.accounts_page
    admin.set_page(3)
    toggled = make_user(unique("启停"))
    accounts._toggle(toggled["id"], toggled["name"], True)
    check(auth.get_account_state(toggled["id"]) == "disabled", "停用账号")
    check(auth.authenticate(toggled["name"], "Passw0rd123")[0] is None,
          "停用后无法登录")
    accounts._toggle(toggled["id"], toggled["name"], False)
    check(auth.authenticate(toggled["name"], "Passw0rd123")[0] is not None,
          "启用后恢复登录")

    # 删除：取消二次确认 / 确认删除
    victim = make_user(unique("删除管"))
    folder = os.path.join(DATA, "admin_delete")
    os.makedirs(folder, exist_ok=True)
    original = os.path.join(folder, "origin.png")
    output = os.path.join(folder, "origin_精修.png")
    Image.new("RGB", (60, 60), (10, 10, 10)).save(original)
    Image.new("RGB", (120, 120), (90, 90, 90)).save(output)
    repo.add_modification(victim["id"], original, output)
    QUESTION_ANSWER = False
    accounts._delete(victim["id"], victim["name"], 1)
    check(auth.get_account_state(victim["id"]) != "deleted", "取消删除保留账号")
    QUESTION_ANSWER = True
    global AUTO_CONFIRM_DELETE
    AUTO_CONFIRM_DELETE = False
    accounts._delete(victim["id"], victim["name"], 1)
    check(auth.get_account_state(victim["id"]) != "deleted", "取消二次确认保留账号")
    AUTO_CONFIRM_DELETE = True
    accounts._delete(victim["id"], victim["name"], 1)
    check(auth.get_account_state(victim["id"]) == "deleted", "确认二次删除账号")
    check(not os.path.exists(output), "管理员删除清理效果图")
    check(os.path.exists(original), "管理员删除保留原图")
    check(mod_count(victim["id"]) == 0, "删除账号级联记录")
    logs, _ = audit.page_logs("", "删除账号", 1, 20)
    check(len(logs) >= 1, "删除账号写入审计")
    ok, _ = auth.create_account(victim["name"])
    check(ok, "删除后同名重新开通")
    if ok:
        recreated, _ = auth.authenticate(victim["name"], auth.DEFAULT_PASSWORD)
        check(recreated is not None and recreated["must_reset"],
              "重新开通后重置为默认密码流程")

    # 效果图丢失时删除仍成功并提示未清理数量
    lost = make_user(unique("丢失图"))
    repo.add_modification(
        lost["id"], FIX["rgb"], os.path.join(DATA, "never_exists.png")
    )
    accounts._delete(lost["id"], lost["name"], 1)
    check(auth.get_account_state(lost["id"]) == "deleted",
          "效果图丢失时仍可删除账号")
    info_messages = [m for m in MESSAGES if m[0] == "info" and m[1] == "删除完成"]
    check(bool(info_messages) and "未能删除" in info_messages[-1][2],
          "删除时提示未清理的效果图数量")

    # 删除时主程序已登录 -> 下次操作强制退出
    live_user = make_user(unique("在线删"))
    live_window = new_main(live_user)
    accounts._delete(live_user["id"], live_user["name"], 0)
    check(not live_window._check_account(), "在线账号被删后校验失败")
    check(not live_window.session.is_logged_in(), "在线账号被删后退出会话")
    live_window.close()

    # 导出账号（含公式注入姓名）与默认文件名清洗
    formula_name = "=1+1"
    ok, _ = auth.create_account(formula_name)
    check(ok, "公式样式姓名可开通（导出时转义）")
    dest2 = os.path.join(DATA, "accounts_export.csv")
    SAVE_QUEUE.append((dest2, ""))
    accounts._export()
    check(os.path.exists(dest2), "导出账号 CSV")
    text = open(dest2, encoding="utf-8-sig").read()
    check("'=1+1" in text, "账号 CSV 公式注入已转义")
    SAVE_QUEUE.append((os.path.join(DATA, "name_test.csv"), ""))
    export_csv(None, "a:b*c?.csv", ["姓名"], [("张三",)])
    check(":" not in os.path.basename(LAST_SAVE_DEFAULT)
          and "*" not in os.path.basename(LAST_SAVE_DEFAULT)
          and "?" not in os.path.basename(LAST_SAVE_DEFAULT),
          "导出默认文件名已清洗", LAST_SAVE_DEFAULT)

    # 审计页
    audit_page = admin.audit_page
    admin.set_page(4)
    check(audit_page.total > 0, "审计页有日志")
    audit_page.search_edit.setText("登录失败")
    audit_page._on_search()
    check(audit_page.total > 0, "审计搜索登录失败")
    dest3 = os.path.join(DATA, "audit_export.csv")
    SAVE_QUEUE.append((dest3, ""))
    audit_page._export()
    check(os.path.exists(dest3), "导出审计日志")
    audit_page.search_edit.clear()
    audit_page._on_search()

    # 管理员页面切换与刷新不崩溃
    for index in range(5):
        admin.set_page(index)
        app.processEvents()
    check(True, "管理员五页切换正常")

    # 账号搜索/状态筛选/分页
    accounts.search_edit.setText("启停")
    accounts._on_search()
    check(accounts.total >= 1, "账号搜索")
    accounts.search_edit.clear()
    accounts._on_search()
    accounts.status_combo.setCurrentIndex(2)
    check(accounts.status == "disabled", "账号停用状态筛选")
    accounts.status_combo.setCurrentIndex(0)
    check(accounts.status == "all", "账号全部状态筛选")
    if accounts.total > PAGE_SIZE:
        accounts._on_page_changed(2)
        check(accounts.page == 2, "账号列表分页")
        accounts._on_page_changed(1)

    # 审计动作筛选
    admin.set_page(4)
    audit_page.refresh()
    index = audit_page.action_combo.findText("登录失败")
    if index >= 0:
        audit_page.action_combo.setCurrentIndex(index)
        audit_page._on_action(index)
        check(audit_page.action == "登录失败", "审计按动作筛选")
        if audit_page.table.rowCount():
            check(audit_page.table.item(0, 3).text() == "登录失败",
                  "审计筛选结果动作一致")
        audit_page.action_combo.setCurrentIndex(0)
        audit_page._on_action(0)

    # 无记录员工详情
    empty_user = make_user(unique("空明细"))
    employees.open_detail(empty_user["id"])
    check(employees.detail_table.rowCount() == 0
          and employees.detail_stack.currentIndex() == 1,
          "无记录员工显示空状态")

    # 趋势 30 天
    admin.set_page(0)
    admin.dashboard_page.range_combo.setCurrentIndex(1)
    check(admin.dashboard_page.chart_days == 30, "运营概览 30 天趋势")

    admin.close()


# ==================== 登录界面 / 个人中心弹窗 ====================
def test_login_ui():
    reset_dialogs()
    user = make_user(unique("登录UI"), password="UiPass123")
    dialog = LoginDialog(None)
    dialog.show()
    app.processEvents()
    dialog.name_edit.setText(user["name"])
    dialog.pwd_edit.setText("wrong")
    dialog._submit()
    check("密码错误" in dialog.error_label.text(), "登录框错误密码提示")
    check(dialog.result() != QDialog.Accepted, "错误密码不进入主程序")
    dialog._toggle_password()
    check(dialog.pwd_edit.echoMode() == QLineEdit.Normal, "密码明文切换")
    dialog._toggle_password()
    dialog.close()

    for _ in range(5):
        auth.authenticate(user["name"], "wrong")
    locked = LoginDialog(None)
    locked.show()
    app.processEvents()
    locked.name_edit.setText(user["name"])
    locked.pwd_edit.setText("UiPass123")
    locked._submit()
    check("锁定" in locked.error_label.text(), "登录框显示账号锁定")
    locked.close()

    # 首登必须改密：取消改密不能进入
    name = unique("首登UI")
    auth.create_account(name)
    must_user, _ = auth.authenticate(name, auth.DEFAULT_PASSWORD)
    rejected = LoginDialog(None)
    rejected.show()
    app.processEvents()
    rejected.name_edit.setText(name)
    rejected.pwd_edit.setText(auth.DEFAULT_PASSWORD)

    class FakeReset:
        def __init__(self, user, parent=None):
            pass

        def exec_(self):
            return QDialog.Rejected

    old_reset = app_main.ResetPasswordDialog
    app_main.ResetPasswordDialog = FakeReset
    try:
        rejected._submit()
    finally:
        app_main.ResetPasswordDialog = old_reset
    check("必须重置" in rejected.error_label.text(),
          "取消首次改密不能进入主程序")
    check(rejected.result() != QDialog.Accepted, "取消改密登录未通过")
    rejected.close()

    real_reset = ResetPasswordDialog(must_user, None)
    real_reset.show()
    app.processEvents()
    real_reset.new_edit.setText("FirstPass123")
    real_reset.confirm_edit.setText("FirstPass123")
    real_reset._submit()
    check(real_reset.result() == QDialog.Accepted, "首次改密界面提交成功")
    check(auth.authenticate(name, auth.DEFAULT_PASSWORD)[0] is None,
          "首次改密后默认密码失效")
    check(auth.authenticate(name, "FirstPass123")[0] is not None,
          "首次改密后新密码可登录")

    accepted = LoginDialog(None)
    accepted.show()
    app.processEvents()
    accepted.name_edit.setText(name)
    accepted.pwd_edit.setText("FirstPass123")
    accepted._submit()
    check(accepted.result() == QDialog.Accepted and accepted.user is not None,
          "改密后正常登录界面")
    accepted.close()


def test_main_profile_dialog():
    reset_dialogs()
    user = make_user(unique("弹窗"))
    window = new_main(user)
    old_exec = QDialog.exec_
    QDialog.exec_ = lambda self, *args, **kwargs: 0
    try:
        window._open_profile()
    finally:
        QDialog.exec_ = old_exec
    check(window.session.is_logged_in(), "打开个人中心后会话保持")
    window.close()

    user2 = make_user(unique("弹窗停"))
    window2 = new_main(user2)
    repo.set_active(user2["id"], False)
    window2._open_profile()
    check(not window2.session.is_logged_in(), "停用后打开个人中心强制退出")
    window2.close()


def test_render_local_batch():
    reset_dialogs()
    user = make_user(unique("局部批"))
    window = new_main(user)
    folder = os.path.join(DATA, "local_batch")
    path = _batch_source(folder, "local.png", (240, 160))

    class FakeRender:
        last = None

        def __init__(self, params, preview_path=None, parent=None,
                     allow_change_preview=True):
            self.params = dict(params)
            FakeRender.last = dict(params)

        def exec_(self):
            return QDialog.Accepted

    old = app_main.RenderDialog
    app_main.RenderDialog = FakeRender
    window.render_settings = render_params.normalize({
        "scale": 1, "local": True, "feather": 10,
        "brightness": 20,
        "regions": [{"x": 0.2, "y": 0.2, "w": 0.4, "h": 0.4}],
    })
    try:
        check(run_batch(window, [path]), "局部参数批量完成")
    finally:
        app_main.RenderDialog = old
    rows, total = repo.page_user_modifications(user["id"], "", 1, 1)
    check(total == 1, "局部批量写入记录")
    if rows:
        saved = render_params.load_json(rows[0]["params"])
        check(saved["local"] and saved["regions"], "局部参数随记录保存")
    window.close()


def test_engine_formats():
    cmyk = os.path.join(DATA, "cmyk.jpg")
    Image.new("CMYK", (200, 120), (0, 50, 80, 10)).save(cmyk)
    cmyk_out = os.path.join(DATA, "cmyk_out.png")
    check(engine.render_image(cmyk, cmyk_out, {"scale": 1}), "CMYK 图片渲染")
    with Image.open(cmyk_out) as im:
        check(im.mode == "RGB", "CMYK 输出 sRGB")

    exif_path = os.path.join(DATA, "exif6.jpg")
    base = Image.open(FIX["jpg"])
    exif = base.getexif()
    exif[274] = 6
    base.save(exif_path, exif=exif)
    base.close()
    exif_out = os.path.join(DATA, "exif_out.png")
    check(engine.render_image(exif_path, exif_out, {"scale": 1}),
          "EXIF 方向图片渲染")
    with Image.open(exif_out) as im:
        check(im.size == (240, 360), "EXIF 方向已转正", str(im.size))

    palette = os.path.join(DATA, "palette.png")
    pimg = Image.new("P", (120, 120), 0)
    palette_data = [0, 0, 0, 200, 60, 60]
    palette_data.extend([0, 0, 0] * 254)
    pimg.putpalette(palette_data)
    pimg.save(palette, transparency=0)
    palette_out = os.path.join(DATA, "palette_out.png")
    check(engine.render_image(palette, palette_out, {"scale": 1}),
          "调色板透明图片渲染")
    with Image.open(palette_out) as im:
        check(im.mode == "RGBA" and im.getpixel((0, 0))[3] == 0,
              "调色板透明通道保留")

    uniform = os.path.join(DATA, "combo_uniform.png")
    Image.new("RGB", (200, 150), (120, 90, 60)).save(uniform)
    combos = [
        {
            "scale": 1, "local": True, "feather": 20, "brightness": 30,
            "shadows": 20, "temperature": 30, "sharpen": 40,
            "denoise": 30, "vignette": 40, "projection": 30,
            "regions": [{"x": 0.1, "y": 0.1, "w": 0.5, "h": 0.5}],
        },
        {
            "scale": 2, "local": True, "feather": 5, "contrast": -20,
            "highlights": 30, "saturation": 40, "sharpen": 80,
            "projection": 60,
            "regions": [{"x": 0.4, "y": 0.4, "w": 0.5, "h": 0.5}],
        },
        {
            "scale": 1, "projection": 100, "brightness": -30,
            "contrast": 40, "denoise": 60, "vignette": 100,
        },
    ]
    for index, params in enumerate(combos):
        out = os.path.join(DATA, f"combo_{index}.png")
        ok = engine.render_image(uniform, out, params)
        check(ok, f"组合参数渲染 {index}")
        if ok:
            with Image.open(out) as im:
                check(max(im.size) <= 6000, f"组合输出尺寸上限 {index}")
                check(im.mode in ("RGB", "RGBA"), f"组合输出模式 {index}")


def test_export_empty():
    dest = os.path.join(DATA, "empty_export.csv")
    SAVE_QUEUE.append((dest, ""))
    export_csv(None, "empty.csv", ["姓名", "次数"], [])
    check(os.path.exists(dest), "空数据仍可导出 CSV")
    text = open(dest, encoding="utf-8-sig").read().strip()
    check(text == "姓名,次数", "空数据 CSV 仅表头", repr(text))


def test_settings_persistence():
    first = MainWindow()
    WINDOWS.append(first)
    first.settings.setValue(
        "render/params", render_params.dump_json({"scale": 1, "brightness": 42})
    )
    first.close()
    second = MainWindow()
    WINDOWS.append(second)
    check(second.render_settings["brightness"] == 42, "渲染参数跨窗口持久化")
    second.close()


# ==================== 并发与数据 ====================
def test_concurrency():
    user = make_user(unique("并发"))
    barrier = threading.Barrier(4)
    errors = []

    def writer():
        barrier.wait()
        for _ in range(5):
            try:
                repo.add_modification(user["id"], FIX["rgb"], FIX["rgb"])
            except Exception as exc:
                errors.append(str(exc))

    threads = [threading.Thread(target=writer) for _ in range(4)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    check(not errors, "并发写修改记录无异常", str(errors[:2]))
    check(mod_count(user["id"]) == 20, "并发写入 20 条全部保存")

    name = unique("并发注册")
    results = []
    lock = threading.Lock()
    barrier = threading.Barrier(6)

    def creator():
        barrier.wait()
        ok, _ = auth.create_account(name)
        with lock:
            results.append(ok)

    threads = [threading.Thread(target=creator) for _ in range(6)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    check(results.count(True) == 1, "并发同名注册只成功一次", str(results))
    with get_connection() as conn:
        count = conn.execute(
            "SELECT COUNT(*) c FROM users WHERE name = ?", (name,)
        ).fetchone()["c"]
    check(count == 1, "并发注册数据库仅一条")

    # 备份与写入并发
    writer_user = make_user(unique("备份并"))
    stop = [False]

    def background_writer():
        while not stop[0]:
            try:
                repo.add_modification(writer_user["id"], FIX["rgb"], FIX["rgb"])
            except Exception:
                pass
            time.sleep(0.005)

    thread = threading.Thread(target=background_writer)
    thread.start()
    try:
        path = backup.create_backup()
    finally:
        stop[0] = True
        thread.join()
    conn = sqlite3.connect(path)
    check(conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok",
          "并发写入时备份完整")
    conn.close()

    # 删除与写入竞争
    race_user = make_user(unique("删并"))
    errors = []

    def racer():
        for _ in range(20):
            try:
                repo.add_modification(race_user["id"], FIX["rgb"], FIX["rgb"])
            except Exception as exc:
                errors.append(type(exc).__name__)
            time.sleep(0.003)

    thread = threading.Thread(target=racer)
    thread.start()
    time.sleep(0.01)
    repo.delete_user(race_user["id"])
    thread.join()
    check(mod_count(race_user["id"]) == 0, "删除与写入竞争后无残余记录")
    check(auth.get_account_state(race_user["id"]) == "deleted", "竞争后账号已删除")

    # SQL 注入搜索
    rows, total = repo.page_employees("' OR 1=1 --", "all", 1, 20)
    check(total == 0, "员工搜索 SQL 注入无效")
    all_logs = audit.page_logs("", "", 1, 1)[1]
    logs, log_total = audit.page_logs("zzz' OR 1=1 --", "", 1, 20)
    check(log_total < all_logs, "审计搜索 SQL 注入无效",
          f"{log_total}/{all_logs}")
    with get_connection() as conn:
        version = conn.execute("PRAGMA user_version").fetchone()[0]
        journal = conn.execute("PRAGMA journal_mode").fetchone()[0]
        fk = conn.execute("PRAGMA foreign_keys").fetchone()[0]
    check(version == 3, "数据库版本 v3")
    check(str(journal).lower() == "wal", "数据库 WAL 模式")
    check(fk == 1, "数据库外键开启")


# ==================== 安全与导出 ====================
def test_security():
    csv_path = os.path.join(DATA, "formula.csv")
    write_csv(
        csv_path, ["姓名", "值"],
        [("=1+1", 1), ("+SUM(A1)", 2), ("-2+3", 3), ("@cmd", 4), ("普通", 5)],
    )
    text = open(csv_path, encoding="utf-8-sig").read()
    check("'=1+1" in text and "'+SUM(A1)" in text and "'-2+3" in text
          and "'@cmd" in text, "CSV 公式注入全部转义", text)
    check("普通,5" in text, "普通 CSV 单元格不变")

    # 姓名不可见字符、尖括号
    for bad in ("a\u200bb", "<x>", "a\tb", "\u202eabc"):
        ok, _ = auth.create_account(bad)
        check(not ok, f"危险姓名被拒绝 {bad!r}")

    # 审计日志不含密码
    rows, _ = audit.page_logs("", "", 1, 500)
    blob = " ".join(
        (r["actor"] or "") + (r["target"] or "") + (r["detail"] or "")
        for r in rows
    )
    check("Passw0rd123" not in blob and "NewPass456" not in blob,
          "审计日志无密码")

    # 主窗口与个人中心用户数据标签为纯文本
    user = make_user(unique("纯文本"))
    window = new_main(user)
    check(window.welcome_label.textFormat() == Qt.PlainText,
          "欢迎标签纯文本")
    check(window.usage_name.textFormat() == Qt.PlainText, "使用姓名纯文本")
    window.close()

    # 备份文件未加密（企业风险已知）
    path = backup.create_backup()
    with open(path, "rb") as f:
        header = f.read(16)
    check(header.startswith(b"SQLite format 3"), "备份为可读 SQLite（已知风险）")

    # 应用目录与数据目录分离
    check(os.path.isdir(DATA) and os.path.isfile(DB_PATH),
          "数据目录独立存在")


# ==================== 执行 ====================
start = time.time()
test_auth()
test_main_validation()
test_login_ui()
test_main_profile_dialog()
test_main_batch()
test_render_local_batch()
test_profile()
test_engine()
test_engine_formats()
test_export_empty()
test_settings_persistence()
test_admin()
test_concurrency()
test_security()
for window in WINDOWS:
    try:
        window.close()
    except Exception:
        pass
app.processEvents()

print(f"CHECKS: {PASS + FAIL}  PASS: {PASS}  FAIL: {FAIL}")
for item in FAILS:
    print("FAILED:", item)
print(f"ELAPSED: {time.time() - start:.1f}s")
print("RESULT:", "PASS" if FAIL == 0 else "FAIL")
sys.exit(0 if FAIL == 0 else 1)
