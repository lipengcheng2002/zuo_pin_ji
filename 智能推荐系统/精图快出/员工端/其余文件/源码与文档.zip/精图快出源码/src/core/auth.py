# core/auth.py
# 职责：账号开通、登录鉴权、首次登录改密、密码修改

import hashlib
import hmac
import math
import re
import secrets
import sqlite3
import unicodedata
from datetime import datetime, timedelta

from core import audit
from core.logging_setup import get_logger
from core.models import get_connection

DEFAULT_PASSWORD = "12345678"
PASSWORD_MIN_LENGTH = 8
PASSWORD_MAX_LENGTH = 64
MAX_FAILED_ATTEMPTS = 5
LOCKOUT_MINUTES = 15
PBKDF2_ITERATIONS = 120_000


# -------------------- 密码工具 --------------------
def _hash_password(salt: str, password: str) -> str:
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt.encode("utf-8"), PBKDF2_ITERATIONS
    ).hex()


def validate_password(password: str) -> tuple:
    """
    新密码规则：8~64 位，必须同时包含字母和数字。
    返回 (True, None) 或 (False, 原因)。
    """
    if len(password) < PASSWORD_MIN_LENGTH:
        return False, f"密码长度不能少于 {PASSWORD_MIN_LENGTH} 位"
    if len(password) > PASSWORD_MAX_LENGTH:
        return False, f"密码长度不能超过 {PASSWORD_MAX_LENGTH} 位"
    if password != password.strip():
        return False, "密码首尾不能包含空格"
    if not re.search(r"[A-Za-z]", password):
        return False, "密码必须包含字母"
    if not re.search(r"\d", password):
        return False, "密码必须包含数字"
    return True, None


def validate_name(name: str) -> tuple:
    """姓名规则：去空格后 1~20 个字符，不含控制/不可见字符与尖括号。"""
    name = (name or "").strip()
    if not name:
        return False, "请输入姓名"
    if len(name) > 20:
        return False, "姓名不能超过 20 个字符"
    if any(unicodedata.category(ch) in ("Cc", "Cf", "Cs") for ch in name):
        return False, "姓名不能包含控制字符或不可见字符"
    if "<" in name or ">" in name:
        return False, "姓名不能包含尖括号"
    return True, None


# -------------------- 账号开通（管理员端） --------------------
def create_account(name: str) -> tuple:
    """
    管理员开通账号：只需姓名，初始密码固定为 12345678，
    首次登录必须重置密码。
    """
    ok, msg = validate_name(name)
    if not ok:
        return False, msg
    name = name.strip()

    salt = secrets.token_hex(16)
    pwd_hash = _hash_password(salt, DEFAULT_PASSWORD)

    try:
        with get_connection() as conn:
            existing = conn.execute(
                "SELECT name FROM users WHERE name = ? COLLATE NOCASE",
                (name,),
            ).fetchone()
            if existing:
                audit.record(
                    "开通失败", "管理员", "admin", name,
                    "姓名已存在（不区分大小写）",
                )
                return False, f"姓名「{existing['name']}」已存在，不能重复开通"
            conn.execute(
                "INSERT INTO users (name, pwd_hash, pwd_salt, must_reset, is_active) "
                "VALUES (?, ?, ?, 1, 1)",
                (name, pwd_hash, salt),
            )
        audit.record("开通账号", "管理员", "admin", name, "初始密码已设置")
        return True, f"已开通账号：{name}，初始密码 {DEFAULT_PASSWORD}"
    except sqlite3.IntegrityError:
        audit.record("开通失败", "管理员", "admin", name, "姓名已存在")
        return False, f"姓名「{name}」已存在，不能重复开通"
    except Exception:
        get_logger().exception("开通账号失败")
        audit.record("开通失败", "管理员", "admin", name, "数据库异常")
        return False, "数据库异常，请稍后重试"


# -------------------- 登录 --------------------
def authenticate(name: str, password: str) -> tuple:
    """
    登录校验。返回 (user_dict, None) 或 (None, 错误原因)。

    user_dict 包含 id/name/must_reset。
    """
    name = (name or "").strip()
    if not name or not password:
        return None, "请输入姓名和密码"

    with get_connection() as conn:
        rows = conn.execute(
            "SELECT id, name, pwd_hash, pwd_salt, must_reset, is_active, "
            "failed_attempts, locked_until FROM users "
            "WHERE name = ? COLLATE NOCASE",
            (name,),
        ).fetchall()

    if not rows:
        audit.record("登录失败", name or "未知", "guest", name, "账号未开通")
        return None, "该姓名尚未开通账号，请联系管理员"

    exact = [row for row in rows if row["name"] == name]
    if exact:
        row = exact[0]
    elif len(rows) == 1:
        row = rows[0]
    else:
        return None, "存在多个大小写不同的同名账号，请使用注册时的准确姓名"

    if not row["is_active"]:
        audit.record("登录失败", row["name"], "guest", row["name"], "账号已停用")
        return None, "账号已停用，请联系管理员"

    locked_until = row["locked_until"]
    if locked_until:
        try:
            lock_time = datetime.fromisoformat(locked_until)
        except ValueError:
            lock_time = None
        if lock_time and datetime.now() < lock_time:
            remain = max(
                1,
                int(math.ceil(
                    (lock_time - datetime.now()).total_seconds() / 60.0
                )),
            )
            audit.record(
                "登录失败", row["name"], "guest", row["name"],
                f"账号锁定中，约 {remain} 分钟"
            )
            return None, f"密码错误次数过多，账号已锁定，请 {remain} 分钟后再试"
        with get_connection() as conn:
            conn.execute(
                "UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?",
                (row["id"],),
            )

    expected = _hash_password(row["pwd_salt"], password)
    if hmac.compare_digest(expected, row["pwd_hash"]):
        with get_connection() as conn:
            conn.execute(
                "UPDATE users SET failed_attempts = 0, locked_until = NULL, "
                "last_login_at = datetime('now', 'localtime') WHERE id = ?",
                (row["id"],),
            )
        audit.record("登录成功", row["name"], "user", row["name"])
        return {
            "id": row["id"],
            "name": row["name"],
            "must_reset": bool(row["must_reset"]),
        }, None

    new_count = (row["failed_attempts"] or 0) + 1
    if new_count >= MAX_FAILED_ATTEMPTS:
        lock_until = (datetime.now() + timedelta(minutes=LOCKOUT_MINUTES)).isoformat(
            timespec="seconds"
        )
        with get_connection() as conn:
            conn.execute(
                "UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?",
                (new_count, lock_until, row["id"]),
            )
        audit.record(
            "登录失败", row["name"], "guest", row["name"],
            f"连续错误 {MAX_FAILED_ATTEMPTS} 次，锁定 {LOCKOUT_MINUTES} 分钟"
        )
        return None, f"密码错误次数过多，账号已锁定 {LOCKOUT_MINUTES} 分钟"

    with get_connection() as conn:
        conn.execute(
            "UPDATE users SET failed_attempts = ? WHERE id = ?",
            (new_count, row["id"]),
        )
    remain = MAX_FAILED_ATTEMPTS - new_count
    audit.record(
        "登录失败", row["name"], "guest", row["name"],
        f"密码错误，剩余 {remain} 次机会"
    )
    return None, f"密码错误，还可尝试 {remain} 次"


# -------------------- 密码重置 / 修改 --------------------
def reset_password(user_id: int, new_password: str) -> tuple:
    """首次登录重置密码。"""
    ok, msg = validate_password(new_password)
    if not ok:
        return False, msg

    salt = secrets.token_hex(16)
    pwd_hash = _hash_password(salt, new_password)
    with get_connection() as conn:
        row = conn.execute(
            "SELECT name, is_active FROM users WHERE id = ?", (user_id,)
        ).fetchone()
        if not row:
            return False, "账号不存在"
        if not row["is_active"]:
            return False, "账号已停用，请联系管理员"
        conn.execute(
            "UPDATE users SET pwd_hash = ?, pwd_salt = ?, must_reset = 0, "
            "failed_attempts = 0, locked_until = NULL WHERE id = ?",
            (pwd_hash, salt, user_id),
        )
    audit.record("首次改密", row["name"], "user", row["name"], "默认密码已重置")
    return True, "密码已重置"


def reset_to_default(user_id: int) -> tuple:
    """管理员重置密码：恢复初始密码并要求首次改密，保留历史记录。"""
    salt = secrets.token_hex(16)
    pwd_hash = _hash_password(salt, DEFAULT_PASSWORD)
    with get_connection() as conn:
        row = conn.execute(
            "SELECT name FROM users WHERE id = ?", (user_id,)
        ).fetchone()
        if not row:
            return False, "账号不存在"
        conn.execute(
            "UPDATE users SET pwd_hash = ?, pwd_salt = ?, must_reset = 1, "
            "failed_attempts = 0, locked_until = NULL WHERE id = ?",
            (pwd_hash, salt, user_id),
        )
    audit.record(
        "重置密码", "管理员", "admin", row["name"],
        "恢复初始密码，要求首次登录改密",
    )
    return True, "密码已重置为初始密码"


def change_password(user_id: int, old_password: str, new_password: str) -> tuple:
    """已登录用户修改密码。"""
    ok, msg = validate_password(new_password)
    if not ok:
        return False, msg

    with get_connection() as conn:
        row = conn.execute(
            "SELECT name, pwd_hash, pwd_salt, is_active FROM users WHERE id = ?",
            (user_id,)
        ).fetchone()
    if not row:
        return False, "账号不存在"
    if not row["is_active"]:
        return False, "账号已停用，请联系管理员"
    if not hmac.compare_digest(_hash_password(row["pwd_salt"], old_password), row["pwd_hash"]):
        return False, "当前密码错误"
    if hmac.compare_digest(_hash_password(row["pwd_salt"], new_password), row["pwd_hash"]):
        return False, "新密码不能与当前密码相同"

    salt = secrets.token_hex(16)
    pwd_hash = _hash_password(salt, new_password)
    with get_connection() as conn:
        conn.execute(
            "UPDATE users SET pwd_hash = ?, pwd_salt = ? WHERE id = ?",
            (pwd_hash, salt, user_id),
        )
    audit.record("修改密码", row["name"], "user", row["name"])
    return True, "密码修改成功"


def get_account_state(user_id: int) -> str:
    """返回 ok / disabled / deleted，供主程序在操作前校验账号状态。"""
    with get_connection() as conn:
        row = conn.execute(
            "SELECT is_active FROM users WHERE id = ?", (user_id,)
        ).fetchone()
    if not row:
        return "deleted"
    return "ok" if row["is_active"] else "disabled"
