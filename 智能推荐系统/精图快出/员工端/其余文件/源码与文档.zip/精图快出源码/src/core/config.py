# core/config.py
# 职责：全局配置、版本与数据目录

import os

APP_NAME = "精图快出"
APP_NAME_EN = "JingTuKuaiChu"
ADMIN_TITLE = "精图快出 · 管理员智能体"
ORG_NAME = "臭皮匠小组"
VERSION = "2.5.0"

PAGE_SIZE = 20
MAX_IMAGE_MB = 50
MAX_IMAGE_PIXELS = 80_000_000

# 全局限定：在原有窗口尺寸基础上按比例缩小三分之一（2/3）
UI_SCALE = 2.0 / 3.0


def scaled(value):
    """按全局 UI 缩放因子换算尺寸。"""
    return max(1, int(round(float(value) * UI_SCALE)))
SUPPORTED_IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".bmp", ".webp")
SUPPORTED_IMAGE_FILTER = "图片文件 (*.png *.jpg *.jpeg *.bmp *.webp)"


def resolve_data_dir() -> str:
    """默认写入当前用户 LOCALAPPDATA，两个程序共用同一份数据。"""
    override = os.environ.get("JTKC_DATA_DIR", "").strip()
    if override:
        return os.path.abspath(override)
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, APP_NAME_EN)


DATA_DIR = resolve_data_dir()
DB_PATH = os.path.join(DATA_DIR, "jingtu.db")
LOG_DIR = os.path.join(DATA_DIR, "logs")
BACKUP_DIR = os.path.join(DATA_DIR, "backups")


def ensure_dirs():
    for path in (DATA_DIR, LOG_DIR, BACKUP_DIR):
        os.makedirs(path, exist_ok=True)
