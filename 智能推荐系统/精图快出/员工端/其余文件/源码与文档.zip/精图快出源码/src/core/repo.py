# core/repo.py
# 职责：账号、修改记录、运营统计的数据访问层（支持分页/筛选）

import os
from datetime import datetime, timedelta

from core.config import PAGE_SIZE
from core.models import get_connection


# -------------------- 查询条件 --------------------
def _employee_filter(search="", status="all"):
    clauses = []
    params = []
    search = (search or "").strip()
    if search:
        clauses.append("u.name LIKE ?")
        params.append(f"%{search}%")
    if status == "active":
        clauses.append("u.is_active = 1")
    elif status == "disabled":
        clauses.append("u.is_active = 0")
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    return where, params


EMPLOYEE_SELECT = """
    SELECT u.id, u.name, u.is_active, u.created_at, u.last_login_at,
           u.locked_until, u.failed_attempts,
           COUNT(m.id) AS modify_count,
           MAX(m.created_at) AS last_modified_at
    FROM users u
    LEFT JOIN modifications m ON m.user_id = u.id
"""


def page_employees(search="", status="all", page=1, page_size=PAGE_SIZE):
    where, params = _employee_filter(search, status)
    offset = (max(1, page) - 1) * page_size
    with get_connection() as conn:
        total = conn.execute(
            f"SELECT COUNT(*) c FROM users u {where}", params
        ).fetchone()["c"]
        rows = conn.execute(
            f"{EMPLOYEE_SELECT} {where} GROUP BY u.id "
            "ORDER BY u.created_at DESC, u.id DESC LIMIT ? OFFSET ?",
            params + [page_size, offset],
        ).fetchall()
    return [dict(row) for row in rows], total


def list_employees(search="", status="all"):
    """导出用：返回符合筛选条件的全部员工。"""
    where, params = _employee_filter(search, status)
    with get_connection() as conn:
        rows = conn.execute(
            f"{EMPLOYEE_SELECT} {where} GROUP BY u.id "
            "ORDER BY u.created_at DESC, u.id DESC",
            params,
        ).fetchall()
    return [dict(row) for row in rows]


def count_employees(search="", status="all"):
    where, params = _employee_filter(search, status)
    with get_connection() as conn:
        return conn.execute(
            f"SELECT COUNT(*) c FROM users u {where}", params
        ).fetchone()["c"]


def get_employee(user_id):
    with get_connection() as conn:
        row = conn.execute(
            f"{EMPLOYEE_SELECT} WHERE u.id = ? GROUP BY u.id", (user_id,)
        ).fetchone()
    return dict(row) if row else None


def get_user_summary(user_id):
    """主程序使用：姓名、累计修改次数、最近修改时间、开通时间、状态。"""
    with get_connection() as conn:
        row = conn.execute(
            """
            SELECT u.id, u.name, u.is_active, u.created_at,
                   COUNT(m.id) AS modify_count,
                   MAX(m.created_at) AS last_modified_at
            FROM users u
            LEFT JOIN modifications m ON m.user_id = u.id
            WHERE u.id = ?
            GROUP BY u.id
            """,
            (user_id,),
        ).fetchone()
    return dict(row) if row else None


def set_active(user_id, active):
    with get_connection() as conn:
        if active:
            conn.execute(
                "UPDATE users SET is_active = 1, failed_attempts = 0, "
                "locked_until = NULL WHERE id = ?",
                (user_id,),
            )
        else:
            conn.execute(
                "UPDATE users SET is_active = 0 WHERE id = ?", (user_id,)
            )


def unlock_user(user_id):
    """管理员解除登录锁定，返回是否确有锁定记录。"""
    with get_connection() as conn:
        row = conn.execute(
            "SELECT failed_attempts, locked_until FROM users WHERE id = ?",
            (user_id,),
        ).fetchone()
        if not row:
            return False
        was_locked = bool(row["locked_until"]) or bool(row["failed_attempts"])
        conn.execute(
            "UPDATE users SET failed_attempts = 0, locked_until = NULL "
            "WHERE id = ?",
            (user_id,),
        )
    return was_locked


def delete_user(user_id):
    """删除账号及全部修改记录，返回待清理的文件路径。"""
    with get_connection() as conn:
        row = conn.execute("SELECT name FROM users WHERE id = ?", (user_id,)).fetchone()
        if not row:
            return {"name": "", "records": 0, "image_paths": []}
        paths = [
            r["image_path"]
            for r in conn.execute(
                "SELECT image_path FROM modifications WHERE user_id = ?", (user_id,)
            ).fetchall()
        ]
        conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
    return {"name": row["name"], "records": len(paths), "image_paths": paths}


def remove_image_files(paths):
    removed = 0
    for path in paths:
        try:
            if path and os.path.isfile(path):
                os.remove(path)
                removed += 1
        except OSError:
            pass
    return removed


# -------------------- 修改记录 --------------------
def add_modification(user_id, original_path, image_path, params=""):
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO modifications (user_id, original_path, image_path, params) "
            "VALUES (?, ?, ?, ?)",
            (user_id, original_path, image_path, params or ""),
        )


def page_user_modifications(user_id, search="", page=1, page_size=PAGE_SIZE):
    search = (search or "").strip()
    where = "WHERE user_id = ?"
    params = [user_id]
    if search:
        where += " AND (image_path LIKE ? OR original_path LIKE ?)"
        like = f"%{search}%"
        params.extend([like, like])
    offset = (max(1, page) - 1) * page_size
    with get_connection() as conn:
        total = conn.execute(
            f"SELECT COUNT(*) c FROM modifications {where}", params
        ).fetchone()["c"]
        rows = conn.execute(
            f"SELECT id, original_path, image_path, params, created_at "
            f"FROM modifications "
            f"{where} ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?",
            params + [page_size, offset],
        ).fetchall()
    return [dict(row) for row in rows], total


def list_user_modifications(user_id, search=""):
    """导出用：返回该用户的全部修改记录。"""
    search = (search or "").strip()
    where = "WHERE user_id = ?"
    params = [user_id]
    if search:
        where += " AND (image_path LIKE ? OR original_path LIKE ?)"
        like = f"%{search}%"
        params.extend([like, like])
    with get_connection() as conn:
        rows = conn.execute(
            f"SELECT id, original_path, image_path, params, created_at "
            f"FROM modifications "
            f"{where} ORDER BY created_at DESC, id DESC",
            params,
        ).fetchall()
    return [dict(row) for row in rows]


def count_user_modifications(user_id, search=""):
    search = (search or "").strip()
    where = "WHERE user_id = ?"
    params = [user_id]
    if search:
        where += " AND (image_path LIKE ? OR original_path LIKE ?)"
        like = f"%{search}%"
        params.extend([like, like])
    with get_connection() as conn:
        return conn.execute(
            f"SELECT COUNT(*) c FROM modifications {where}", params
        ).fetchone()["c"]


def list_recent_modifications(limit=8):
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT m.id, m.image_path, m.params, m.created_at,
                   u.name, u.id AS user_id
            FROM modifications m
            JOIN users u ON u.id = m.user_id
            ORDER BY m.created_at DESC, m.id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
    return [dict(row) for row in rows]


def list_recent_users(limit=6):
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT id, name, is_active, must_reset, created_at FROM users "
            "ORDER BY created_at DESC, id DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [dict(row) for row in rows]


def daily_counts(days=7):
    """最近 N 天的修改量，返回 [(MM-DD, count), ...]，按时间正序。"""
    today = datetime.now().date()
    start = today - timedelta(days=days - 1)
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT substr(created_at, 1, 10) AS d, COUNT(*) AS c "
            "FROM modifications WHERE created_at >= ? GROUP BY d",
            (start.strftime("%Y-%m-%d"),),
        ).fetchall()
    counts = {row["d"]: row["c"] for row in rows}
    result = []
    for i in range(days):
        day = start + timedelta(days=i)
        result.append((day.strftime("%m-%d"), counts.get(day.strftime("%Y-%m-%d"), 0)))
    return result


def dashboard_stats():
    today = datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    with get_connection() as conn:
        total_users = conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
        active_users = conn.execute(
            "SELECT COUNT(*) c FROM users WHERE is_active = 1"
        ).fetchone()["c"]
        total_mods = conn.execute("SELECT COUNT(*) c FROM modifications").fetchone()["c"]
        today_mods = conn.execute(
            "SELECT COUNT(*) c FROM modifications WHERE substr(created_at, 1, 10) = ?",
            (today,),
        ).fetchone()["c"]
        yesterday_mods = conn.execute(
            "SELECT COUNT(*) c FROM modifications WHERE substr(created_at, 1, 10) = ?",
            (yesterday,),
        ).fetchone()["c"]
        today_new_users = conn.execute(
            "SELECT COUNT(*) c FROM users WHERE substr(created_at, 1, 10) = ?",
            (today,),
        ).fetchone()["c"]
    return {
        "total_users": total_users,
        "active_users": active_users,
        "disabled_users": total_users - active_users,
        "total_mods": total_mods,
        "today_mods": today_mods,
        "yesterday_mods": yesterday_mods,
        "today_new_users": today_new_users,
    }


def top_employee():
    with get_connection() as conn:
        row = conn.execute(
            """
            SELECT u.name, COUNT(m.id) AS c
            FROM users u JOIN modifications m ON m.user_id = u.id
            GROUP BY u.id ORDER BY c DESC, u.id ASC LIMIT 1
            """
        ).fetchone()
    return dict(row) if row and row["c"] > 0 else None


def idle_employee_count(days=7):
    cutoff = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    with get_connection() as conn:
        row = conn.execute(
            """
            SELECT COUNT(*) c FROM users u
            WHERE u.created_at <= ?
              AND NOT EXISTS (
                  SELECT 1 FROM modifications m
                  WHERE m.user_id = u.id AND m.created_at >= ?
              )
            """,
            (cutoff, cutoff),
        ).fetchone()
    return row["c"] if row else 0


def build_insights():
    """根据数据生成运营提示（规则化“智能体”建议）。"""
    stats = dashboard_stats()
    if stats["total_mods"] == 0:
        return ["还没有图片修改记录，员工开始使用后这里会生成运营提示。"]

    lines = []
    top = top_employee()
    if top:
        lines.append(f"最活跃员工：{top['name']}，累计修改 {top['c']} 张图片。")

    today, yesterday = stats["today_mods"], stats["yesterday_mods"]
    if yesterday > 0:
        delta = (today - yesterday) / yesterday * 100
        trend = "上升" if delta >= 0 else "下降"
        lines.append(f"今日修改 {today} 张，较昨日{trend} {abs(delta):.0f}%。")
    else:
        lines.append(f"今日修改 {today} 张，昨日没有修改记录。")

    if stats["disabled_users"] > 0:
        lines.append(f"当前有 {stats['disabled_users']} 个账号处于停用状态。")

    idle = idle_employee_count(7)
    if idle > 0:
        lines.append(f"{idle} 个员工近 7 天没有修改记录，可关注使用情况。")
    elif stats["today_new_users"] > 0:
        lines.append(f"今日新开通 {stats['today_new_users']} 个账号，记得提醒首次登录改密。")

    return lines[:3]
