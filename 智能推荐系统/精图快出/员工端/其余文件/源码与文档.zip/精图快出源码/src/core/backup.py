# core/backup.py
# 职责：SQLite 在线备份与备份文件轮换

import glob
import os
import sqlite3
from datetime import datetime

from core.config import BACKUP_DIR, DB_PATH, ensure_dirs

KEEP_BACKUPS = 10


def create_backup() -> str:
    """使用 SQLite 在线备份 API 生成一致性备份，返回备份文件路径。"""
    ensure_dirs()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    dest = os.path.join(BACKUP_DIR, f"jingtu_{stamp}.db")
    index = 1
    while os.path.exists(dest):
        dest = os.path.join(BACKUP_DIR, f"jingtu_{stamp}_{index}.db")
        index += 1

    source = sqlite3.connect(DB_PATH, timeout=10)
    target = sqlite3.connect(dest, timeout=10)
    try:
        source.execute("PRAGMA busy_timeout = 5000")
        target.execute("PRAGMA busy_timeout = 5000")
        source.backup(target)
    finally:
        target.close()
        source.close()

    _prune()
    return dest


def _prune():
    files = sorted(
        glob.glob(os.path.join(BACKUP_DIR, "jingtu_*.db")),
        key=os.path.getmtime,
        reverse=True,
    )
    for old in files[KEEP_BACKUPS:]:
        try:
            os.remove(old)
        except OSError:
            pass
