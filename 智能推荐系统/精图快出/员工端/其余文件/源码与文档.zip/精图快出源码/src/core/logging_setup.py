﻿# core/logging_setup.py
# 职责：结构化文件日志（轮转）与全局异常捕获

import logging
import logging.handlers
import os
import sys

from core.config import LOG_DIR, ensure_dirs

_LOGGER_NAME = "jtkc"
_configured = False


def setup_logging(component: str) -> logging.Logger:
    """初始化文件日志，输出到数据目录 logs/<component>.log。"""
    global _configured
    ensure_dirs()
    logger = logging.getLogger(_LOGGER_NAME)
    logger.setLevel(logging.INFO)
    if not _configured:
        handler = logging.handlers.RotatingFileHandler(
            os.path.join(LOG_DIR, f"{component}.log"),
            maxBytes=2 * 1024 * 1024,
            backupCount=5,
            encoding="utf-8",
        )
        handler.setFormatter(logging.Formatter(
            "%(asctime)s [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S"
        ))
        logger.addHandler(handler)
        logger.propagate = False
        _configured = True
    return logger


def get_logger() -> logging.Logger:
    return logging.getLogger(_LOGGER_NAME)


def install_excepthook(app_name: str):
    """未捕获异常写入日志，并给出友好提示，避免程序直接消失。"""
    def _hook(exc_type, exc_value, exc_tb):
        get_logger().exception(
            "未捕获异常", exc_info=(exc_type, exc_value, exc_tb)
        )
        try:
            from PyQt5.QtWidgets import QApplication, QMessageBox
            if QApplication.instance() is not None:
                QMessageBox.critical(
                    None, f"{app_name} - 程序异常",
                    f"程序遇到未处理的异常，已记录日志。\n\n{exc_value}"
                )
        except Exception:
            pass

    sys.excepthook = _hook
