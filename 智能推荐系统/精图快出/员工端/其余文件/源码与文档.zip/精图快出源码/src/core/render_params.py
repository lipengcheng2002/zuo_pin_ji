# core/render_params.py
# 职责：渲染参数模型（默认值、范围校验、摘要、JSON 序列化）
# 该模块不依赖 NumPy/Pillow，主程序与管理员端都可安全引用。

import json

DEFAULTS = {
    "scale": 2,          # 1 / 2
    "brightness": 0,     # -100 ~ 100
    "contrast": 0,       # -100 ~ 100
    "saturation": 0,     # -100 ~ 100
    "shadows": 0,        # -100 ~ 100 暗部
    "highlights": 0,     # -100 ~ 100 高光
    "temperature": 0,    # -100 ~ 100 色温
    "sharpen": 0,        # 0 ~ 100
    "denoise": 0,        # 0 ~ 100
    "vignette": 0,       # 0 ~ 100
    "projection": 0,     # 0 ~ 100 投影
    "local": False,      # 是否局部渲染
    "feather": 10,       # 局部羽化 0 ~ 100
    "regions": [],       # [{"x":0-1,"y":0-1,"w":0-1,"h":0-1}]
}

MAX_REGIONS = 20
MIN_REGION = 0.005

SIGNED_KEYS = (
    "brightness", "contrast", "saturation",
    "shadows", "highlights", "temperature",
)
UNSIGNED_KEYS = ("sharpen", "denoise", "vignette", "projection")

LABELS = {
    "brightness": "亮度",
    "contrast": "对比度",
    "saturation": "饱和度",
    "shadows": "阴影",
    "highlights": "高光",
    "temperature": "色温",
    "sharpen": "锐化",
    "denoise": "降噪",
    "vignette": "暗角",
    "projection": "投影",
}

ORDER = (
    "brightness", "contrast", "saturation", "shadows",
    "highlights", "temperature", "sharpen", "denoise",
    "vignette", "projection",
)


def normalize(params) -> dict:
    """合并默认值并做范围校验，返回一份新的完整参数。"""
    result = dict(DEFAULTS)
    if not isinstance(params, dict):
        return result

    try:
        scale = int(params.get("scale", DEFAULTS["scale"]))
    except (TypeError, ValueError):
        scale = DEFAULTS["scale"]
    result["scale"] = 2 if scale >= 2 else 1

    for key in SIGNED_KEYS:
        try:
            value = int(params.get(key, 0))
        except (TypeError, ValueError):
            value = 0
        result[key] = max(-100, min(100, value))

    for key in UNSIGNED_KEYS:
        try:
            value = int(params.get(key, 0))
        except (TypeError, ValueError):
            value = 0
        result[key] = max(0, min(100, value))

    result["local"] = bool(params.get("local", False))

    try:
        feather = int(params.get("feather", DEFAULTS["feather"]))
    except (TypeError, ValueError):
        feather = DEFAULTS["feather"]
    result["feather"] = max(0, min(100, feather))

    regions = []
    raw_regions = params.get("regions", [])
    if isinstance(raw_regions, list):
        for item in raw_regions:
            if not isinstance(item, dict):
                continue
            try:
                x = float(item.get("x", 0))
                y = float(item.get("y", 0))
                w = float(item.get("w", 0))
                h = float(item.get("h", 0))
            except (TypeError, ValueError):
                continue
            x = max(0.0, min(1.0, x))
            y = max(0.0, min(1.0, y))
            w = max(0.0, min(1.0 - x, w))
            h = max(0.0, min(1.0 - y, h))
            if w < MIN_REGION or h < MIN_REGION:
                continue
            regions.append({
                "x": round(x, 4),
                "y": round(y, 4),
                "w": round(w, 4),
                "h": round(h, 4),
            })
            if len(regions) >= MAX_REGIONS:
                break
    result["regions"] = regions

    return result


def is_default(params) -> bool:
    normalized = normalize(params)
    return all(normalized[key] == value for key, value in DEFAULTS.items())

def load_json(text) -> dict:
    if not text:
        return dict(DEFAULTS)
    try:
        data = json.loads(text)
    except (TypeError, ValueError):
        return dict(DEFAULTS)
    return normalize(data)


def dump_json(params) -> str:
    return json.dumps(normalize(params), ensure_ascii=False, sort_keys=True)


def summary(params) -> str:
    """人类可读的参数摘要，例如：局部×2 · 2x · 亮度+10 · 投影+40"""
    normalized = normalize(params)
    parts = []
    if normalized["local"]:
        count = len(normalized["regions"])
        parts.append(f"局部×{count}" if count else "局部（未框选）")
    parts.append(f"{normalized['scale']}x")
    for key in ORDER:
        value = normalized[key]
        if value:
            parts.append(f"{LABELS[key]}{value:+d}")

    if len(parts) == 1:
        return "2x 清晰度增强" if normalized["scale"] == 2 else "1x 原尺寸"
    return " · ".join(parts)


def active_count(params) -> int:
    normalized = normalize(params)
    return sum(
        1 for key in ORDER
        if normalized[key] != DEFAULTS[key]
    )
