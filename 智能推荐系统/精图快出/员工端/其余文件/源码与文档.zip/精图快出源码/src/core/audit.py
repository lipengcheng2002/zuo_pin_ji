# core/audit.py
# 职责：操作审计日志（只追加、不提供删除入口）

from core.logging_setup import get_logger
from core.models import get_connection

ROLE_LABELS = {
    "admin": "管理员",
    "user": "员工",
    "guest": "访客",
    "system": "系统",
}


def _clip(value, limit):
    text = str(value or "")
    return text[:limit]


def record(action: str, actor: str = "系统", role: str = "system",
           target: str = "", detail: str = ""):
    """写入一条审计日志。失败不影响主流程。"""
    try:
        with get_connection() as conn:
            conn.execute(
                "INSERT INTO audit_logs (actor, role, action, target, detail) "
                "VALUES (?, ?, ?, ?, ?)",
                (_clip(actor, 64), _clip(role, 16), _clip(action, 32),
                 _clip(target, 128), _clip(detail, 500)),
            )
        get_logger().info(
            "AUDIT %s | %s(%s) | %s | %s", action, actor, role, target, detail
        )
    except Exception:
        get_logger().exception("写入审计日志失败")


def _where(search, action):
    clauses = []
    params = []
    search = (search or "").strip()
    if search:
        clauses.append(
            "(actor LIKE ? OR target LIKE ? OR detail LIKE ? OR action LIKE ?)"
        )
        like = f"%{search}%"
        params.extend([like, like, like, like])
    if action:
        clauses.append("action = ?")
        params.append(action)
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    return where, params


def page_logs(search: str = "", action: str = "", page: int = 1,
              page_size: int = 20):
    where, params = _where(search, action)
    offset = (max(1, page) - 1) * page_size
    with get_connection() as conn:
        total = conn.execute(
            f"SELECT COUNT(*) c FROM audit_logs {where}", params
        ).fetchone()["c"]
        rows = conn.execute(
            f"SELECT id, created_at, actor, role, action, target, detail "
            f"FROM audit_logs {where} ORDER BY id DESC LIMIT ? OFFSET ?",
            params + [page_size, offset],
        ).fetchall()
    return [dict(row) for row in rows], total


def list_logs(search: str = "", action: str = ""):
    where, params = _where(search, action)
    with get_connection() as conn:
        rows = conn.execute(
            f"SELECT id, created_at, actor, role, action, target, detail "
            f"FROM audit_logs {where} ORDER BY id DESC",
            params,
        ).fetchall()
    return [dict(row) for row in rows]


def distinct_actions():
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT DISTINCT action FROM audit_logs ORDER BY action"
        ).fetchall()
    return [row["action"] for row in rows]


def role_label(role):
    return ROLE_LABELS.get(role, role or "系统")
