# core/session.py
# 职责：主程序登录会话

from core.models import get_connection


class Session:
    """全局单例会话，保存当前登录账号。"""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._init()
        return cls._instance

    def _init(self):
        self.user_id = None
        self.user_name = None

    def set_user(self, user: dict):
        self.user_id = user["id"]
        self.user_name = user["name"]

    def logout(self):
        self.user_id = None
        self.user_name = None

    def is_logged_in(self) -> bool:
        return self.user_id is not None

    def refresh_name(self) -> bool:
        """账号被改名/删除时同步会话。返回账号是否仍然有效。"""
        if self.user_id is None:
            return False
        with get_connection() as conn:
            row = conn.execute(
                "SELECT name FROM users WHERE id = ?", (self.user_id,)
            ).fetchone()
        if not row:
            self.logout()
            return False
        self.user_name = row["name"]
        return True
