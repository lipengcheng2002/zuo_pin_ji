# core/models.py
# 职责：共享数据库连接、表结构与版本迁移（主程序与管理员智能体共用）

import sqlite3
from contextlib import contextmanager

from core.config import DB_PATH, ensure_dirs
from core.logging_setup import get_logger

SCHEMA_VERSION = 3


@contextmanager
def get_connection():
    """
    数据库连接上下文管理器。

    - row_factory 允许按列名访问
    - 开启外键约束（删除账号时级联删除修改记录）
    - WAL 模式 + busy_timeout，允许主程序和管理员端同时访问
    """
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 5000")
    try:
        conn.execute("PRAGMA journal_mode = WAL")
    except sqlite3.Error:
        pass
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> bool:
    """初始化 / 升级数据库（幂等）。"""
    try:
        ensure_dirs()
        with get_connection() as conn:
            version = conn.execute("PRAGMA user_version").fetchone()[0]

            conn.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT UNIQUE NOT NULL,
                    pwd_hash TEXT NOT NULL,
                    pwd_salt TEXT NOT NULL,
                    must_reset INTEGER NOT NULL DEFAULT 1,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    failed_attempts INTEGER NOT NULL DEFAULT 0,
                    locked_until TEXT,
                    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
                    last_login_at TEXT
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS modifications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    original_path TEXT,
                    image_path TEXT NOT NULL,
                    params TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
                    actor TEXT NOT NULL DEFAULT '',
                    role TEXT NOT NULL DEFAULT 'system',
                    action TEXT NOT NULL,
                    target TEXT NOT NULL DEFAULT '',
                    detail TEXT NOT NULL DEFAULT ''
                )
            """)

            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_mod_user_time "
                "ON modifications(user_id, created_at DESC)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_mod_time "
                "ON modifications(created_at DESC)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_audit_time "
                "ON audit_logs(created_at DESC)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_audit_action "
                "ON audit_logs(action, id DESC)"
            )

            # v3：为旧库补充渲染参数字段
            columns = [
                row["name"]
                for row in conn.execute("PRAGMA table_info(modifications)")
            ]
            if "params" not in columns:
                conn.execute(
                    "ALTER TABLE modifications ADD COLUMN params TEXT NOT NULL DEFAULT ''"
                )

            if version < SCHEMA_VERSION:
                conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
        return True
    except Exception:
        get_logger().exception("数据库初始化失败")
        return False
