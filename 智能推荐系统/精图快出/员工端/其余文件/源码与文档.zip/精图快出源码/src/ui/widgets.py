# ui/widgets.py
# 职责：可复用的企业级界面组件

import math
import re

from PyQt5.QtCore import Qt, pyqtSignal, QRectF
from PyQt5.QtGui import QColor, QFont, QPainter, QPen
from PyQt5.QtWidgets import (
    QAbstractItemView, QApplication, QFrame, QHBoxLayout, QHeaderView, QLabel,
    QPushButton, QSizePolicy, QTableWidget, QVBoxLayout, QWidget
)

from core.config import scaled

from ui import theme


def make_button(text, variant="primary", height=None, min_width=None):
    btn = QPushButton(text)
    btn.setProperty("variant", variant)
    btn.setCursor(Qt.PointingHandCursor)
    if height:
        btn.setFixedHeight(height)
    if min_width:
        btn.setMinimumWidth(min_width)
    return btn


class Card(QFrame):
    """白底圆角卡片。"""

    def __init__(self, parent=None, padding=24, spacing=14):
        super().__init__(parent)
        self.setObjectName("card")
        self.body = QVBoxLayout(self)
        self.body.setContentsMargins(padding, padding, padding, padding)
        self.body.setSpacing(spacing)


class StatCard(QFrame):
    """数据指标卡：标题 + 大数字 + 辅助说明。"""

    def __init__(self, title, value="0", hint="", accent=theme.PRIMARY,
                 value_size=30, parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        self.setMinimumHeight(100)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(6)

        head = QHBoxLayout()
        head.setSpacing(8)
        dot = QLabel()
        dot.setFixedSize(8, 8)
        dot.setStyleSheet(f"background:{accent}; border-radius:4px;")
        title_label = QLabel(title)
        title_label.setStyleSheet(
            f"color:{theme.TEXT_SECONDARY}; font-size:13px; font-weight:600;"
        )
        head.addWidget(dot)
        head.addWidget(title_label)
        head.addStretch()
        layout.addLayout(head)

        self.value_label = QLabel(value)
        self.value_label.setStyleSheet(
            f"color:{theme.TEXT}; font-size:{value_size}px; font-weight:700;"
        )
        layout.addWidget(self.value_label)

        self.hint_label = QLabel(hint)
        self.hint_label.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:12px;")
        layout.addWidget(self.hint_label)

    def set_value(self, value, hint=None):
        self.value_label.setText(str(value))
        if hint is not None:
            self.hint_label.setText(hint)


class PageHeader(QWidget):
    """页面标题区：标题 + 说明 + 右侧操作区。"""

    def __init__(self, title, subtitle="", parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)

        left = QVBoxLayout()
        left.setSpacing(3)
        self.title_label = QLabel(title)
        self.title_label.setStyleSheet(
            f"color:{theme.TEXT}; font-size:24px; font-weight:700;"
        )
        left.addWidget(self.title_label)
        self.subtitle_label = QLabel(subtitle)
        self.subtitle_label.setStyleSheet(
            f"color:{theme.TEXT_SECONDARY}; font-size:13px;"
        )
        self.subtitle_label.setVisible(bool(subtitle))
        left.addWidget(self.subtitle_label)
        layout.addLayout(left)
        layout.addStretch()

        self.actions = QHBoxLayout()
        self.actions.setSpacing(8)
        layout.addLayout(self.actions)

    def add_action(self, widget):
        self.actions.addWidget(widget)


class SectionTitle(QLabel):
    def __init__(self, text, size=16, parent=None):
        super().__init__(text, parent)
        self.setStyleSheet(f"color:{theme.TEXT}; font-size:{size}px; font-weight:700;")


class StatusChip(QLabel):
    """状态胶囊：正常 / 已停用。"""

    STYLES = {
        "success": (theme.SUCCESS_SOFT, theme.SUCCESS, "正常"),
        "danger": (theme.DANGER_SOFT, theme.DANGER, "已停用"),
        "warning": (theme.WARNING_SOFT, theme.WARNING, "登录锁定"),
        "muted": ("#EEF1F5", theme.TEXT_SECONDARY, "—"),
        "info": (theme.INFO_SOFT, theme.INFO, ""),
    }

    def __init__(self, kind="success", text=None, parent=None):
        super().__init__(parent)
        bg, fg, default_text = self.STYLES.get(kind, self.STYLES["muted"])
        self.setText(text if text is not None else default_text)
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet(
            f"background:{bg}; color:{fg}; border-radius:9px; "
            f"padding:3px 10px; font-size:12px; font-weight:600;"
        )


class Avatar(QLabel):
    """姓名首字头像。"""

    def __init__(self, name, size=48, parent=None):
        super().__init__(parent)
        initial = (name or "?").strip()[:1] or "?"
        self.setText(initial)
        self.setFixedSize(size, size)
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet(
            f"background:{theme.PRIMARY}; color:#FFFFFF; border-radius:{size // 2}px; "
            f"font-size:{max(14, size // 2 - 2)}px; font-weight:700;"
        )


class EmptyState(QWidget):
    """空状态占位。"""

    def __init__(self, title="暂无数据", subtitle="", icon="▢", parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 28, 20, 28)
        layout.setSpacing(8)
        layout.setAlignment(Qt.AlignCenter)

        icon_label = QLabel(icon)
        icon_label.setFixedSize(56, 56)
        icon_label.setAlignment(Qt.AlignCenter)
        icon_label.setStyleSheet(
            f"background:#F3F5F7; color:{theme.TEXT_MUTED}; border-radius:28px; font-size:22px;"
        )
        layout.addWidget(icon_label, 0, Qt.AlignHCenter)

        title_label = QLabel(title)
        title_label.setStyleSheet(
            f"color:{theme.TEXT_SECONDARY}; font-size:14px; font-weight:600;"
        )
        title_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(title_label)

        if subtitle:
            sub = QLabel(subtitle)
            sub.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:12px;")
            sub.setAlignment(Qt.AlignCenter)
            sub.setWordWrap(True)
            layout.addWidget(sub)


class ClickableLabel(QLabel):
    clicked = pyqtSignal()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit()
            event.accept()
            return
        super().mouseReleaseEvent(event)


class ClickableFrame(QFrame):
    clicked = pyqtSignal()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit()
            event.accept()
            return
        super().mouseReleaseEvent(event)


class HLine(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("hLine")
        self.setFixedHeight(1)


class DataTable(QTableWidget):
    """统一风格的数据表格。"""

    def __init__(self, headers, row_height=54, parent=None):
        super().__init__(parent)
        self.setColumnCount(len(headers))
        self.setHorizontalHeaderLabels(headers)
        self.setShowGrid(False)
        self.setAlternatingRowColors(True)
        self.setSelectionMode(QAbstractItemView.NoSelection)
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.setFocusPolicy(Qt.NoFocus)
        self.verticalHeader().setVisible(False)
        self.verticalHeader().setDefaultSectionSize(row_height)
        self.horizontalHeader().setStretchLastSection(False)
        self.horizontalHeader().setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

    def set_widths(self, widths):
        header = self.horizontalHeader()
        for col, width in widths.items():
            header.setSectionResizeMode(col, QHeaderView.Fixed)
            self.setColumnWidth(col, width)


def format_time(value):
    return value or "—"


def clear_layout(layout):
    while layout.count():
        item = layout.takeAt(0)
        widget = item.widget()
        if widget is not None:
            widget.hide()
            widget.setParent(None)
            widget.deleteLater()
        elif item.layout() is not None:
            clear_layout(item.layout())


def fit_to_screen(widget, width, height, min_width=0, min_height=0):
    """按屏幕可用区域收缩窗口尺寸，避免小屏溢出。"""
    screen = QApplication.primaryScreen()
    if screen is not None:
        geo = screen.availableGeometry()
        width = min(width, geo.width() - 60)
        height = min(height, geo.height() - 60)
    if min_width and min_height:
        widget.setMinimumSize(min_width, min_height)
    widget.resize(max(min_width, width), max(min_height, height))


def fit_scaled(widget, width, height, min_width=0, min_height=0):
    """以全局 2/3 比例设置首选尺寸，并按屏幕可用区域自适应收缩。"""
    fit_to_screen(
        widget, scaled(width), scaled(height),
        scaled(min_width) if min_width else 0,
        scaled(min_height) if min_height else 0,
    )


def center_on_screen(widget):
    screen = QApplication.primaryScreen()
    if screen is None:
        return
    geo = screen.availableGeometry()
    frame = widget.frameGeometry()
    frame.moveCenter(geo.center())
    widget.move(frame.topLeft())


def center_on_parent(widget):
    parent = widget.parentWidget()
    if parent is None:
        center_on_screen(widget)
        return
    geo = parent.window().frameGeometry()
    frame = widget.frameGeometry()
    frame.moveCenter(geo.center())
    widget.move(frame.topLeft())


class MiniBarChart(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        self._data = []
        self.setMinimumHeight(170)

    def set_data(self, data):
        self._data = list(data)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        if not self._data:
            painter.setPen(QColor(theme.TEXT_MUTED))
            painter.drawText(self.rect(), Qt.AlignCenter, "暂无数据")
            return

        total = sum(v for _, v in self._data)
        if total == 0:
            painter.setPen(QColor(theme.TEXT_MUTED))
            painter.setFont(QFont(theme.FONT_FAMILY, 9))
            painter.drawText(self.rect(), Qt.AlignCenter, "近 7 天暂无修改记录")
            return

        width = self.width()
        height = self.height()
        left, right, top, bottom = 6, 6, 24, 26
        avail_w = max(1, width - left - right)
        avail_h = max(1, height - top - bottom)
        n = len(self._data)
        slot = avail_w / n
        bar_w = min(30.0, slot * 0.42)
        max_v = max(1, max(v for _, v in self._data))

        for i, (label, value) in enumerate(self._data):
            cx = left + slot * i + slot / 2
            bar_h = (value / max_v) * avail_h if value else 0
            if value:
                bar_h = max(4.0, bar_h)
            x = cx - bar_w / 2
            y = top + (avail_h - bar_h)
            color = theme.PRIMARY if i == n - 1 else "#F0C9AE"
            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(color))
            painter.drawRoundedRect(QRectF(x, y, bar_w, bar_h), 5, 5)

            if n <= 10 or i == n - 1:
                painter.setPen(QColor(theme.TEXT_SECONDARY))
                painter.setFont(QFont(theme.FONT_FAMILY, 9))
                painter.drawText(
                    QRectF(cx - slot / 2, max(0, y - 20), slot, 18),
                    Qt.AlignHCenter | Qt.AlignBottom,
                    str(value),
                )

            if n <= 10 or i == 0 or i == n - 1 or i % 5 == 0:
                painter.setPen(QColor(theme.TEXT_MUTED))
                painter.setFont(QFont(theme.FONT_FAMILY, 8))
                painter.drawText(
                    QRectF(cx - slot / 2, height - bottom + 6, slot, 18),
                    Qt.AlignHCenter | Qt.AlignTop,
                    label,
                )

        painter.setPen(QPen(QColor(theme.BORDER), 1))
        painter.drawLine(left, top + avail_h, width - right, top + avail_h)


class PaginationBar(QWidget):
    """分页条：上一页 / 第 x / y 页 / 下一页。"""

    page_changed = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._page = 1
        self._pages = 1
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        layout.addStretch()

        self.prev_btn = make_button("上一页", "ghost")
        self.prev_btn.setFixedSize(72, 30)
        self.prev_btn.clicked.connect(lambda: self._go(-1))
        layout.addWidget(self.prev_btn)

        self.page_label = QLabel("第 1 / 1 页")
        self.page_label.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:12px;")
        self.page_label.setAlignment(Qt.AlignCenter)
        self.page_label.setMinimumWidth(86)
        layout.addWidget(self.page_label)

        self.next_btn = make_button("下一页", "ghost")
        self.next_btn.setFixedSize(72, 30)
        self.next_btn.clicked.connect(lambda: self._go(1))
        layout.addWidget(self.next_btn)

        self.set_state(1, 0, 20)

    def set_state(self, page, total, page_size):
        pages = max(1, math.ceil((total or 0) / max(1, page_size)))
        page = min(max(1, page), pages)
        self._page = page
        self._pages = pages
        self.page_label.setText(f"第 {page} / {pages} 页")
        self.prev_btn.setEnabled(page > 1)
        self.next_btn.setEnabled(page < pages)
        self.setVisible((total or 0) > 0)

    def _go(self, delta):
        new_page = self._page + delta
        if not (1 <= new_page <= self._pages):
            return
        self._page = new_page
        self.page_label.setText(f"第 {new_page} / {self._pages} 页")
        self.prev_btn.setEnabled(new_page > 1)
        self.next_btn.setEnabled(new_page < self._pages)
        self.page_changed.emit(new_page)


class PasswordStrengthBar(QWidget):
    """密码强度条 + 规则提示。"""

    COLORS = {
        0: "#E4E9EF",
        1: theme.DANGER,
        2: theme.WARNING,
        3: theme.INFO,
        4: theme.SUCCESS,
    }
    LABELS = {2: "中", 3: "良好", 4: "强"}

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)

        row = QHBoxLayout()
        row.setSpacing(5)
        self.bars = []
        for _ in range(4):
            bar = QFrame()
            bar.setFixedHeight(4)
            bar.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            bar.setStyleSheet("background:#E4E9EF; border-radius:2px;")
            row.addWidget(bar)
            self.bars.append(bar)
        layout.addLayout(row)

        self.status = QLabel("至少 8 位，需包含字母和数字")
        self.status.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:11px;")
        layout.addWidget(self.status)

    def set_password(self, text):
        text = text or ""
        has_letter = bool(re.search(r"[A-Za-z]", text))
        has_digit = bool(re.search(r"\d", text))
        has_special = bool(re.search(r"[^A-Za-z0-9]", text))
        length = len(text)
        valid = length >= 8 and has_letter and has_digit

        if not text:
            score = 0
        else:
            score = 1
            if valid:
                score = 2
            if valid and length >= 12:
                score = 3
            if valid and (has_special or length >= 16):
                score = 4

        for index, bar in enumerate(self.bars):
            color = self.COLORS.get(score, "#E4E9EF") if index < score else "#E4E9EF"
            bar.setStyleSheet(f"background:{color}; border-radius:2px;")

        if not text:
            self.status.setText("至少 8 位，需包含字母和数字")
            self.status.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:11px;")
            return

        if not valid:
            missing = []
            if length < 8:
                missing.append(f"还需 {8 - length} 位")
            if not has_letter:
                missing.append("缺少字母")
            if not has_digit:
                missing.append("缺少数字")
            self.status.setText("密码强度：弱 · " + "，".join(missing))
            self.status.setStyleSheet(f"color:{theme.DANGER}; font-size:11px;")
            return

        label = self.LABELS.get(score, "中")
        self.status.setText(f"密码强度：{label} · 满足要求")
        color = self.COLORS.get(score, theme.SUCCESS)
        self.status.setStyleSheet(f"color:{color}; font-size:11px;")
