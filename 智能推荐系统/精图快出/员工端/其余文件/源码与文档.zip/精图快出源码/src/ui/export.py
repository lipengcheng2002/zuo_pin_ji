# ui/export.py
# 职责：CSV 导出（UTF-8 BOM，Excel 可直接打开中文）

import csv
import os
import re

from PyQt5.QtCore import QStandardPaths
from PyQt5.QtWidgets import QFileDialog, QMessageBox

from ui.toast import show_toast

_INVALID_FILENAME = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_FORMULA_PREFIXES = ("=", "+", "-", "@")


def safe_filename(name, max_length=80):
    """清理 Windows 文件名非法字符，避免姓名中的符号导致无法保存。"""
    cleaned = _INVALID_FILENAME.sub("_", str(name or ""))
    cleaned = cleaned.strip().rstrip(".")
    cleaned = cleaned[:max_length].rstrip(" .")
    return cleaned or "导出"


def _safe_cell(value):
    """防 CSV 公式注入：以公式字符开头的单元格加单引号前缀。"""
    if isinstance(value, str):
        stripped = value.lstrip(" \t\r\n")
        if stripped[:1] in _FORMULA_PREFIXES or value[:1] in ("\t", "\r", "\n"):
            return "'" + value
    return value


def write_csv(path, headers, rows):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        for row in rows:
            writer.writerow([_safe_cell(value) for value in row])
    return path


def export_csv(parent, default_name, headers, rows):
    desktop = QStandardPaths.writableLocation(QStandardPaths.DesktopLocation)
    stem, ext = os.path.splitext(os.path.basename(default_name))
    default_name = safe_filename(stem) + (ext or ".csv")
    default_path = os.path.join(desktop or os.path.expanduser("~"), default_name)
    path, _ = QFileDialog.getSaveFileName(
        parent, "导出 CSV", default_path, "CSV 文件 (*.csv)"
    )
    if not path:
        return None
    if not path.lower().endswith(".csv"):
        path += ".csv"
    try:
        write_csv(path, headers, rows)
    except OSError as exc:
        QMessageBox.critical(parent, "导出失败", f"写入文件失败：{exc}")
        return None
    show_toast(parent, f"已导出：{os.path.basename(path)}")
    return path
