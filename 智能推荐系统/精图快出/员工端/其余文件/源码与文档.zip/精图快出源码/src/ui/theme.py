# ui/theme.py
# 职责：统一配色、字体与全局样式（企业级视觉规范）

PRIMARY = "#C55A11"
PRIMARY_HOVER = "#D96A1E"
PRIMARY_PRESSED = "#A3470C"
PRIMARY_LIGHT = "#E58A4E"
PRIMARY_SOFT = "#FDF1E8"

BG = "#F3F5F7"
CARD = "#FFFFFF"
TEXT = "#1B2430"
TEXT_SECONDARY = "#5A6675"
TEXT_MUTED = "#8B95A3"
BORDER = "#E4E9EF"
BORDER_STRONG = "#CFD7E1"

SUCCESS = "#178A5B"
SUCCESS_SOFT = "#E7F6EF"
DANGER = "#C93C3C"
DANGER_SOFT = "#FDECEC"
WARNING = "#B7791F"
WARNING_SOFT = "#FDF4E3"
INFO = "#2B6CB0"
INFO_SOFT = "#EAF2FB"

SIDEBAR = "#151E28"
SIDEBAR_HOVER = "#1E2A37"
SIDEBAR_ACTIVE = "#243241"
SIDEBAR_TEXT = "#B9C3CF"
SIDEBAR_MUTED = "#7C8896"

FONT_FAMILY = "Microsoft YaHei UI"


APP_QSS = f"""
* {{
    font-family: "{FONT_FAMILY}";
    font-size: 14px;
    color: {TEXT};
}}
QMainWindow, QDialog {{
    background: {BG};
}}
QWidget#page {{
    background: {BG};
}}
QLabel {{
    background: transparent;
}}
QToolTip {{
    background: #1F2933;
    color: #FFFFFF;
    border: none;
    padding: 6px 8px;
    border-radius: 6px;
}}
QLineEdit {{
    background: #FFFFFF;
    border: 1px solid {BORDER};
    border-radius: 8px;
    padding: 9px 12px;
    min-height: 20px;
    selection-background-color: {PRIMARY};
    selection-color: #FFFFFF;
}}
QLineEdit:focus {{
    border: 1px solid {PRIMARY};
}}
QLineEdit:disabled {{
    background: #EEF1F5;
    color: {TEXT_MUTED};
    border: 1px solid #E4E9EF;
}}
QPushButton {{
    border-radius: 8px;
    padding: 4px 8px;
    font-size: 12px;
    font-weight: 600;
    background: transparent;
    border: none;
}}
QPushButton[variant="primary"] {{
    background: {PRIMARY};
    color: #FFFFFF;
    border: 1px solid {PRIMARY};
    font-size: 13px;
}}
QPushButton[variant="primary"]:hover {{
    background: {PRIMARY_HOVER};
    border-color: {PRIMARY_HOVER};
}}
QPushButton[variant="primary"]:pressed {{
    background: {PRIMARY_PRESSED};
    border-color: {PRIMARY_PRESSED};
}}
QPushButton[variant="primary"]:disabled {{
    background: #E8C9B4;
    border-color: #E8C9B4;
    color: #FFFFFF;
}}
QPushButton[variant="ghost"] {{
    background: #FFFFFF;
    color: {TEXT};
    border: 1px solid {BORDER};
}}
QPushButton[variant="ghost"]:hover {{
    background: #F7F9FB;
    border-color: {BORDER_STRONG};
}}
QPushButton[variant="ghost"]:disabled {{
    background: #FAFBFC;
    color: #B8C0CB;
    border-color: #EEF1F5;
}}
QPushButton[variant="subtle"] {{
    background: {PRIMARY_SOFT};
    color: {PRIMARY};
    border: 1px solid #F0D6C2;
}}
QPushButton[variant="subtle"]:hover {{
    background: #FBE4D3;
}}
QPushButton[variant="danger"] {{
    background: {DANGER_SOFT};
    color: {DANGER};
    border: 1px solid #F3C9C9;
}}
QPushButton[variant="danger"]:hover {{
    background: #FBDDDD;
}}
QPushButton[variant="danger-solid"] {{
    background: {DANGER};
    color: #FFFFFF;
    border: 1px solid {DANGER};
}}
QPushButton[variant="danger-solid"]:hover {{
    background: #B33232;
    border-color: #B33232;
}}
QPushButton[variant="success"] {{
    background: {SUCCESS_SOFT};
    color: {SUCCESS};
    border: 1px solid #C6E8D8;
}}
QPushButton[variant="success"]:hover {{
    background: #D9F2E5;
}}
QPushButton#navButton {{
    text-align: left;
    padding: 10px 12px;
    border: none;
    border-left: 3px solid transparent;
    border-radius: 0;
    background: transparent;
    color: {SIDEBAR_TEXT};
    font-weight: 500;
    font-size: 13px;
}}
QPushButton#navButton:hover {{
    background: {SIDEBAR_HOVER};
    color: #FFFFFF;
}}
QPushButton#navButton:checked {{
    background: {SIDEBAR_ACTIVE};
    color: #FFFFFF;
    border-left: 3px solid {PRIMARY_LIGHT};
    font-weight: 600;
}}
QPushButton#tabButton {{
    background: transparent;
    border: none;
    border-bottom: 2px solid transparent;
    border-radius: 0;
    padding: 10px 6px;
    color: {TEXT_SECONDARY};
    font-weight: 600;
}}
QPushButton#tabButton:hover {{
    color: {TEXT};
}}
QPushButton#tabButton:checked {{
    color: {PRIMARY};
    border-bottom: 2px solid {PRIMARY};
}}
QPushButton#eyeButton {{
    background: #FFFFFF;
    border: 1px solid {BORDER};
    border-radius: 8px;
    padding: 0;
    font-size: 15px;
    color: {TEXT_SECONDARY};
}}
QPushButton#eyeButton:hover {{
    background: #F7F9FB;
}}
QSlider::groove:horizontal {{
    height: 4px;
    background: #E4E9EF;
    border-radius: 2px;
}}
QSlider::sub-page:horizontal {{
    background: {PRIMARY};
    border-radius: 2px;
}}
QSlider[signed="true"]::sub-page:horizontal {{
    background: transparent;
}}
QSlider::add-page:horizontal {{
    background: transparent;
}}
QSlider::handle:horizontal {{
    background: #FFFFFF;
    border: 2px solid {PRIMARY};
    width: 14px;
    margin: -7px 0;
    border-radius: 9px;
}}
QSlider::handle:horizontal:hover {{
    border-color: {PRIMARY_HOVER};
}}
QFrame#card {{
    background: {CARD};
    border: 1px solid {BORDER};
    border-radius: 14px;
}}
QFrame#headerBar {{
    background: #FFFFFF;
    border: none;
    border-bottom: 1px solid {BORDER};
}}
QFrame#dropZone {{
    background: #FFFBF7;
    border: 2px dashed #E8C6AC;
    border-radius: 14px;
}}
QFrame#dropZone:hover {{
    background: #FFF6EE;
    border-color: {PRIMARY_LIGHT};
}}
QFrame#hLine {{
    background: {BORDER};
    border: none;
    max-height: 1px;
}}
QTableWidget {{
    background: #FFFFFF;
    border: 1px solid {BORDER};
    border-radius: 10px;
    gridline-color: transparent;
    selection-background-color: {PRIMARY_SOFT};
    selection-color: {TEXT};
    alternate-background-color: #FBFCFD;
    font-size: 12px;
}}
QTableWidget::item {{
    border-bottom: 1px solid #F0F3F6;
    padding: 6px 8px;
}}
QHeaderView::section {{
    background: #F7F9FB;
    color: {TEXT_SECONDARY};
    border: none;
    border-bottom: 1px solid {BORDER};
    padding: 10px 8px;
    font-weight: 600;
    font-size: 12px;
}}
QScrollBar:vertical {{
    background: transparent;
    width: 10px;
    margin: 4px 2px;
}}
QScrollBar::handle:vertical {{
    background: #C9D1DB;
    border-radius: 5px;
    min-height: 30px;
}}
QScrollBar::handle:vertical:hover {{
    background: #AEB8C4;
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0;
}}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
    background: transparent;
}}
QScrollBar:horizontal {{
    background: transparent;
    height: 10px;
    margin: 2px 4px;
}}
QScrollBar::handle:horizontal {{
    background: #C9D1DB;
    border-radius: 5px;
    min-width: 30px;
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
    width: 0;
}}
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {{
    background: transparent;
}}
QComboBox {{
    background: #FFFFFF;
    border: 1px solid {BORDER};
    border-radius: 8px;
    padding: 8px 12px;
}}
QMessageBox {{
    background: {CARD};
}}
"""


def apply_theme(app):
    """给 QApplication 应用全局主题。"""
    from PyQt5.QtGui import QFont

    app.setFont(QFont(FONT_FAMILY, 10))
    app.setStyleSheet(APP_QSS)
