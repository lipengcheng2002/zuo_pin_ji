# ui/toast.py
# 职责：轻量级操作反馈（成功/失败提示，不打断操作）

from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtWidgets import QLabel

from ui import theme

_KINDS = {
    "success": ("✓", theme.SUCCESS),
    "error": ("!", theme.DANGER),
    "info": ("i", theme.INFO),
}


class Toast(QLabel):
    def __init__(self, window, text, kind="success", duration=2600):
        super().__init__(window)
        icon, color = _KINDS.get(kind, _KINDS["info"])
        self.setTextFormat(Qt.PlainText)
        self.setText(f"  {icon}  {text}  ")
        self.setStyleSheet(
            f"background:#1F2933; color:#FFFFFF; border:1px solid rgba(255,255,255,0.12); "
            f"border-left:4px solid {color}; border-radius:8px; "
            "padding:10px 14px; font-size:12px;"
        )
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.adjustSize()
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._dismiss)
        self._timer.start(duration)
        self._place()

    def _place(self):
        window = self.parentWidget()
        if window is None:
            return
        x = max(12, (window.width() - self.width()) // 2)
        y = max(12, window.height() - self.height() - 40)
        self.move(x, y)
        self.raise_()

    def _dismiss(self):
        self.hide()
        self.deleteLater()


def show_toast(parent, text, kind="success", duration=2600):
    """在父窗口底部居中显示一条轻提示。"""
    if parent is None:
        return
    window = parent.window() if hasattr(parent, "window") else parent
    if window is None:
        return
    old = getattr(window, "_jtkc_toast", None)
    if old is not None:
        try:
            old.deleteLater()
        except RuntimeError:
            pass
    toast = Toast(window, text, kind, duration)
    window._jtkc_toast = toast
    toast.show()
