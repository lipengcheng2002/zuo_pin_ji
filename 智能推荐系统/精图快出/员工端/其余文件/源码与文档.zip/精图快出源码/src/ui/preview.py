# ui/preview.py
# 职责：全屏图片预览（长按对比原图）与图片下载

import os
import shutil

from PyQt5.QtCore import QRect, Qt, QTimer, QStandardPaths
from PyQt5.QtWidgets import (
    QApplication, QDialog, QFileDialog, QHBoxLayout, QLabel,
    QMessageBox, QPushButton, QVBoxLayout, QWidget
)

from ui.imageutils import image_info, preview_pixmap
from ui.toast import show_toast


def _default_download_dir(source_path):
    desktop = QStandardPaths.writableLocation(QStandardPaths.DesktopLocation)
    if desktop and os.path.isdir(desktop):
        return os.path.join(desktop, os.path.basename(source_path))
    return os.path.join(os.path.dirname(source_path), os.path.basename(source_path))


def save_image_as(parent, source_path, title="下载图片"):
    """另存图片到用户选择的位置。"""
    if not source_path or not os.path.isfile(source_path):
        QMessageBox.warning(parent, "图片不存在", "图片文件已被移动或删除，无法下载。")
        return False

    dest, _ = QFileDialog.getSaveFileName(
        parent, title, _default_download_dir(source_path), "PNG 图片 (*.png)"
    )
    if not dest:
        return False
    if not os.path.splitext(dest)[1]:
        dest += ".png"

    try:
        shutil.copy2(source_path, dest)
    except OSError as exc:
        QMessageBox.critical(parent, "下载失败", f"保存图片失败：{exc}")
        return False

    show_toast(parent, f"已下载：{os.path.basename(dest)}")
    return True


class ImagePreviewDialog(QDialog):
    """全屏预览：默认显示效果图，长按查看原图。"""

    def __init__(self, result_path, original_path=None, parent=None, allow_download=True):
        super().__init__(parent)
        self._result_path = result_path
        self._original_path = original_path
        self._is_long_press = False

        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setStyleSheet("background:#0B0D10;")
        self.setCursor(Qt.ArrowCursor)
        self._press_timer = QTimer(self)
        self._press_timer.setSingleShot(True)
        self._press_timer.setInterval(320)
        self._press_timer.timeout.connect(self._show_original)

        if parent is not None:
            geo = parent.window().geometry()
        else:
            geo = QApplication.primaryScreen().availableGeometry()
        self.setGeometry(geo)
        self._dpr = max(1.0, float(self.devicePixelRatioF()))

        self._result_pixmap = preview_pixmap(
            result_path, geo.width() - 48, geo.height() - 150, self._dpr
        )
        if self._result_pixmap is None or self._result_pixmap.isNull():
            QMessageBox.warning(parent, "无法预览", "无法加载该图片，请检查文件是否损坏。")
            QTimer.singleShot(0, self.reject)
            return
        self._original_pixmap = (
            preview_pixmap(original_path, geo.width() - 48, geo.height() - 150, self._dpr)
            if original_path else None
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 18)
        layout.setSpacing(12)

        top = QHBoxLayout()
        title = QLabel("效果图预览")
        title.setStyleSheet("color:#FFFFFF; font-size:18px; font-weight:700;")
        top.addWidget(title)
        top.addStretch()
        self.hint = QLabel("长按图片查看原图")
        self.hint.setStyleSheet("color:rgba(255,255,255,0.65); font-size:12px;")
        top.addWidget(self.hint)
        layout.addLayout(top)

        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setStyleSheet("background: transparent;")
        layout.addWidget(self.image_label, 1)

        bar = QWidget()
        bar.setStyleSheet(
            "QWidget{background:rgba(255,255,255,0.06); border-radius:12px;}"
        )
        bar_layout = QHBoxLayout(bar)
        bar_layout.setContentsMargins(18, 12, 18, 12)
        bar_layout.setSpacing(10)

        info = image_info(result_path)
        meta = os.path.basename(result_path)
        if info:
            meta += f" · {info['width']}×{info['height']}"
        self.path_label = QLabel(meta)
        self.path_label.setTextFormat(Qt.PlainText)
        self.path_label.setStyleSheet(
            "color:rgba(255,255,255,0.55); font-size:12px; background:transparent;"
        )
        bar_layout.addWidget(self.path_label)
        bar_layout.addStretch()

        if allow_download:
            download_btn = QPushButton("下载图片")
            download_btn.setCursor(Qt.PointingHandCursor)
            download_btn.setFixedHeight(38)
            download_btn.setStyleSheet(
                "QPushButton{background:#C55A11; color:#FFFFFF; border:none; "
                "border-radius:8px; padding:0 20px; font-weight:700;}"
                "QPushButton:hover{background:#D96A1E;}"
            )
            download_btn.clicked.connect(self._download)
            bar_layout.addWidget(download_btn)

        close_btn = QPushButton("关闭")
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.setFixedHeight(38)
        close_btn.setStyleSheet(
            "QPushButton{background:transparent; color:#FFFFFF; border:1px solid "
            "rgba(255,255,255,0.35); border-radius:8px; padding:0 20px; font-weight:600;}"
            "QPushButton:hover{background:rgba(255,255,255,0.12);}"
        )
        close_btn.clicked.connect(self.accept)
        bar_layout.addWidget(close_btn)
        layout.addWidget(bar)

        self._update_pixmap(self._result_pixmap)

    def _update_pixmap(self, pixmap):
        if pixmap is None:
            return
        area = self.image_label.size()
        if area.width() < 10 or area.height() < 10:
            area = self.size()
        dpr = self._dpr
        target = QRect(0, 0, int(area.width() * dpr), int(area.height() * dpr))
        scaled = pixmap.scaled(
            target.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation
        )
        scaled.setDevicePixelRatio(dpr)
        self.image_label.setPixmap(scaled)

    def showEvent(self, event):
        super().showEvent(event)
        QTimer.singleShot(0, lambda: self._update_pixmap(self._result_pixmap))

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "image_label"):
            current = (
                self._original_pixmap if self._is_long_press else self._result_pixmap
            )
            self._update_pixmap(current)

    def _show_original(self):
        if not self._original_pixmap or self._original_pixmap.isNull():
            self.hint.setText("未记录原图")
            return
        self._is_long_press = True
        self.hint.setText("正在查看原图 · 松开返回效果图")
        self._update_pixmap(self._original_pixmap)

    def _restore_result(self):
        self._is_long_press = False
        self.hint.setText("长按图片查看原图")
        self._update_pixmap(self._result_pixmap)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._press_timer.start()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._press_timer.stop()
            if self._is_long_press:
                self._restore_result()
        super().mouseReleaseEvent(event)

    def _download(self):
        save_image_as(self, self._result_path, "下载效果图")
