# ui/render_dialog.py
# 职责：渲染参数面板（全图/局部、区域框选、实时预览、参数持久化）

import io
import os

from PIL import Image, ImageDraw, ImageOps
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QRectF
from PyQt5.QtGui import QColor, QPainter, QPen, QPixmap
from PyQt5.QtWidgets import (
    QComboBox, QDialog, QFileDialog, QFrame, QHBoxLayout, QLabel,
    QScrollArea, QSizePolicy, QSlider, QVBoxLayout, QWidget
)

from core import render_params
from core.config import MAX_IMAGE_PIXELS, SUPPORTED_IMAGE_FILTER, scaled
from ui import theme
from ui.widgets import (
    Card, SectionTitle, center_on_parent, fit_scaled, make_button
)
from utils import engine


def _pil_to_pixmap(img):
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    pix = QPixmap()
    pix.loadFromData(buffer.getvalue(), "PNG")
    return pix


def make_demo_image():
    """无预览图时使用一张本地生成的示例图。"""
    width, height = 1100, 720
    img = Image.new("RGB", (width, height))
    draw = ImageDraw.Draw(img)
    top = (250, 198, 138)
    bottom = (38, 50, 76)
    for y in range(height):
        t = (y / (height - 1)) ** 0.9
        color = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
        draw.line([(0, y), (width, y)], fill=color)

    draw.ellipse(
        [width * 0.64, height * 0.16, width * 0.64 + 160, height * 0.16 + 160],
        fill=(255, 231, 178),
    )
    draw.polygon(
        [(0, height * 0.72), (width * 0.28, height * 0.48),
         (width * 0.56, height * 0.82), (0, height)],
        fill=(36, 42, 58),
    )
    draw.polygon(
        [(width * 0.34, height * 0.88), (width * 0.7, height * 0.56),
         (width, height * 0.74), (width, height), (width * 0.34, height)],
        fill=(26, 31, 44),
    )
    draw.rectangle([0, height * 0.88, width, height], fill=(20, 24, 34))
    for x, y, r in [(0.1, 0.2, 16), (0.18, 0.28, 9), (0.82, 0.22, 12), (0.9, 0.32, 7)]:
        draw.ellipse(
            [width * x, height * y, width * x + r, height * y + r],
            fill=(255, 245, 220),
        )
    return img


class SliderRow(QWidget):
    valueChanged = pyqtSignal()

    def __init__(self, label, minimum, maximum, value, default=0,
                 signed=False, parent=None):
        super().__init__(parent)
        self.default = default
        self.signed = signed
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)

        name = QLabel(label)
        name.setFixedWidth(76)
        name.setStyleSheet(f"color:{theme.TEXT_SECONDARY}; font-size:12px;")
        layout.addWidget(name)

        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(minimum, maximum)
        self.slider.setSingleStep(1)
        self.slider.setPageStep(5)
        self.slider.setValue(value)
        self.slider.setProperty("signed", "true" if signed else "false")
        layout.addWidget(self.slider, 1)

        self.value_label = QLabel()
        self.value_label.setFixedWidth(48)
        self.value_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        layout.addWidget(self.value_label)

        self.slider.valueChanged.connect(self._on_change)
        self._refresh_label()

    def _format(self, value):
        if self.signed:
            return f"{value:+d}" if value else "0"
        return str(value)

    def _refresh_label(self):
        value = self.slider.value()
        self.value_label.setText(self._format(value))
        color = theme.PRIMARY if value != self.default else theme.TEXT_MUTED
        self.value_label.setStyleSheet(
            f"color:{color}; font-size:12px; font-weight:600;"
        )

    def _on_change(self, value):
        self._refresh_label()
        self.valueChanged.emit()

    def value(self):
        return self.slider.value()

    def set_value(self, value):
        self.slider.setValue(value)

    def reset(self):
        self.slider.setValue(self.default)


class RegionPreview(QWidget):
    """在渲染结果上显示局部区域，并支持拖动框选。"""

    regionsChanged = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._pixmap = None
        self._source_size = (0, 0)
        self.regions = []
        self.local = False
        self.editable = False
        self._drag_start = None
        self._drag_current = None
        self._content = QRectF()
        self._display = QRectF()
        self.setMinimumSize(scaled(440), scaled(320))
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMouseTracking(True)
        self.setCursor(Qt.ArrowCursor)

    def set_data(self, pixmap, source_size, regions, local, editable):
        self._pixmap = pixmap
        self._source_size = source_size
        self.regions = list(regions or [])
        self.local = local
        self.editable = editable
        self._drag_start = None
        self._drag_current = None
        self.setCursor(Qt.CrossCursor if (local and editable) else Qt.ArrowCursor)
        self.update()

    def set_mode(self, local, editable):
        self.local = local
        self.editable = editable
        self.setCursor(Qt.CrossCursor if (local and editable) else Qt.ArrowCursor)
        self.update()

    def undo_region(self):
        if self.regions:
            self.regions.pop()
            self.update()
            self.regionsChanged.emit()

    def clear_regions(self):
        if self.regions:
            self.regions = []
            self.update()
            self.regionsChanged.emit()

    def _compute_rects(self):
        if self._pixmap is None or self._pixmap.isNull():
            return
        avail = self.size()
        scaled = self._pixmap.scaled(
            avail, Qt.KeepAspectRatio, Qt.SmoothTransformation
        )
        x = (avail.width() - scaled.width()) / 2.0
        y = (avail.height() - scaled.height()) / 2.0
        self._display = QRectF(x, y, scaled.width(), scaled.height())

        source_w, source_h = self._source_size
        pix_w, pix_h = self._pixmap.width(), self._pixmap.height()
        pad_x = max(0.0, (pix_w - source_w) / 2.0)
        pad_y = max(0.0, (pix_h - source_h) / 2.0)
        scale_x = scaled.width() / max(1, pix_w)
        scale_y = scaled.height() / max(1, pix_h)
        self._content = QRectF(
            x + pad_x * scale_x,
            y + pad_y * scale_y,
            source_w * scale_x,
            source_h * scale_y,
        )

    def _norm_pos(self, pos):
        self._compute_rects()
        if not self._content.contains(pos):
            return None
        nx = (pos.x() - self._content.x()) / max(1.0, self._content.width())
        ny = (pos.y() - self._content.y()) / max(1.0, self._content.height())
        return max(0.0, min(1.0, nx)), max(0.0, min(1.0, ny))

    def _region_rect(self, region):
        return QRectF(
            self._content.x() + region["x"] * self._content.width(),
            self._content.y() + region["y"] * self._content.height(),
            region["w"] * self._content.width(),
            region["h"] * self._content.height(),
        )

    def _drag_rect(self):
        if not self._drag_start or not self._drag_current:
            return None
        x0 = min(self._drag_start[0], self._drag_current[0])
        y0 = min(self._drag_start[1], self._drag_current[1])
        w = abs(self._drag_start[0] - self._drag_current[0])
        h = abs(self._drag_start[1] - self._drag_current[1])
        return QRectF(
            self._content.x() + x0 * self._content.width(),
            self._content.y() + y0 * self._content.height(),
            w * self._content.width(),
            h * self._content.height(),
        )

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setRenderHint(QPainter.SmoothPixmapTransform, True)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor("#E7EBF0"))
        painter.drawRoundedRect(
            QRectF(self.rect()).adjusted(0, 0, -1, -1), 8, 8
        )

        if self._pixmap is None or self._pixmap.isNull():
            painter.setPen(QColor(theme.TEXT_MUTED))
            painter.drawText(self.rect(), Qt.AlignCenter, "选择图片后可预览")
            return

        self._compute_rects()
        painter.drawPixmap(self._display.toRect(), self._pixmap)

        if not self.local:
            return

        painter.save()
        painter.setClipRect(self._content)
        for index, region in enumerate(self.regions):
            rect = self._region_rect(region)
            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(197, 90, 17, 45))
            painter.drawRect(rect)
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(QColor(255, 255, 255, 220), 3))
            painter.drawRect(rect)
            painter.setPen(QPen(QColor(theme.PRIMARY), 2, Qt.DashLine))
            painter.drawRect(rect)

            if rect.width() > 26 and rect.height() > 26:
                badge = QRectF(rect.x() + 5, rect.y() + 5, 18, 18)
                painter.setPen(Qt.NoPen)
                painter.setBrush(QColor(theme.PRIMARY))
                painter.drawEllipse(badge)
                painter.setPen(QColor("#FFFFFF"))
                font = painter.font()
                font.setPixelSize(10)
                font.setBold(True)
                painter.setFont(font)
                painter.drawText(badge, Qt.AlignCenter, str(index + 1))

        drag_rect = self._drag_rect()
        if drag_rect is not None:
            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(197, 90, 17, 40))
            painter.drawRect(drag_rect)
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(QColor(255, 255, 255, 230), 3))
            painter.drawRect(drag_rect)
            painter.setPen(QPen(QColor(theme.PRIMARY), 2, Qt.DashLine))
            painter.drawRect(drag_rect)
        painter.restore()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and self.local and self.editable:
            pos = self._norm_pos(event.pos())
            if pos is not None:
                self._drag_start = pos
                self._drag_current = pos
                self.update()
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._drag_start is not None:
            pos = self._norm_pos(event.pos())
            if pos is not None:
                self._drag_current = pos
                self.update()
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._drag_start is not None and event.button() == Qt.LeftButton:
            pos = self._norm_pos(event.pos()) or self._drag_current
            if pos is not None:
                x0 = min(self._drag_start[0], pos[0])
                y0 = min(self._drag_start[1], pos[1])
                width = abs(self._drag_start[0] - pos[0])
                height = abs(self._drag_start[1] - pos[1])
                if width >= 0.01 and height >= 0.01:
                    if len(self.regions) < render_params.MAX_REGIONS:
                        self.regions.append({
                            "x": round(x0, 4),
                            "y": round(y0, 4),
                            "w": round(width, 4),
                            "h": round(height, 4),
                        })
                        self.regionsChanged.emit()
            self._drag_start = None
            self._drag_current = None
            self.update()
            event.accept()
            return
        super().mouseReleaseEvent(event)


class RenderDialog(QDialog):
    """光影 / 色彩 / 细节 / 投影 / 局部区域参数配置，带实时预览。"""

    def __init__(self, params, preview_path=None, parent=None,
                 allow_change_preview=True):
        super().__init__(parent)
        self.params = render_params.normalize(params)
        self._preview_path = preview_path
        self._allow_change_preview = allow_change_preview
        self._source_img = None
        self._is_demo = False
        self.rows = {}

        self.setWindowTitle("渲染参数 - 精图快出")
        self.setModal(True)
        fit_scaled(self, 1080, 840, 980, 700)
        self._preview_timer = QTimer(self)
        self._preview_timer.setSingleShot(True)
        self._preview_timer.setInterval(160)
        self._preview_timer.timeout.connect(self._render_preview)

        self._build_ui()
        center_on_parent(self)
        self._load_source(self._preview_path)

    # ---------- 界面 ----------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 14)
        layout.setSpacing(10)

        header = QHBoxLayout()
        title_box = QVBoxLayout()
        title_box.setSpacing(1)
        title = QLabel("渲染参数")
        title.setStyleSheet(f"font-size:20px; font-weight:700; color:{theme.TEXT};")
        subtitle = QLabel("光影 · 色彩 · 细节 · 投影 · 局部区域，全部在本机完成")
        subtitle.setStyleSheet(f"color:{theme.TEXT_SECONDARY}; font-size:11px;")
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        header.addLayout(title_box)
        header.addStretch()
        badge = QLabel("精图渲染引擎")
        badge.setStyleSheet(
            f"background:{theme.PRIMARY_SOFT}; color:{theme.PRIMARY}; "
            "border-radius:8px; padding:3px 8px; font-size:10px; font-weight:700;"
        )
        header.addWidget(badge)
        layout.addLayout(header)

        body = QHBoxLayout()
        body.setSpacing(16)

        scroll = QScrollArea()
        scroll.setFixedWidth(scaled(470))
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet(
            "QScrollArea{background:transparent; border:none;} "
            "QScrollArea > QWidget > QWidget{background:transparent;}"
        )
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout(scroll_content)
        scroll_layout.setContentsMargins(0, 0, 6, 0)
        scroll_layout.setSpacing(12)

        scroll_layout.addWidget(self._group(
            "光影",
            [
                ("brightness", "亮度", -100, 100, 0, True),
                ("contrast", "对比度", -100, 100, 0, True),
                ("shadows", "阴影", -100, 100, 0, True),
                ("highlights", "高光", -100, 100, 0, True),
            ],
        ))
        scroll_layout.addWidget(self._group(
            "色彩",
            [
                ("saturation", "饱和度", -100, 100, 0, True),
                ("temperature", "色温", -100, 100, 0, True),
            ],
        ))
        scroll_layout.addWidget(self._group(
            "效果与输出",
            [
                ("projection", "投影", 0, 100, 0, False),
                ("feather", "局部羽化", 0, 100, 10, False),
            ],
            with_range=True,
            with_scale=True,
        ))
        scroll_layout.addWidget(self._group(
            "细节",
            [
                ("sharpen", "锐化", 0, 100, 0, False),
                ("denoise", "降噪", 0, 100, 0, False),
                ("vignette", "暗角", 0, 100, 0, False),
            ],
        ))
        scroll_layout.addStretch()
        scroll.setWidget(scroll_content)
        body.addWidget(scroll)

        preview_card = Card(padding=14, spacing=8)
        preview_head = QHBoxLayout()
        preview_head.addWidget(SectionTitle("实时预览", 16))
        preview_head.addStretch()
        self.source_label = QLabel("")
        self.source_label.setTextFormat(Qt.PlainText)
        self.source_label.setStyleSheet(
            f"color:{theme.TEXT_MUTED}; font-size:11px;"
        )
        preview_head.addWidget(self.source_label)
        change_btn = make_button("更换预览图", "ghost", height=30)
        change_btn.clicked.connect(self._change_preview)
        change_btn.setVisible(self._allow_change_preview)
        preview_head.addWidget(change_btn)
        preview_card.body.addLayout(preview_head)

        self.preview_widget = RegionPreview()
        self.preview_widget.regions = list(self.params.get("regions", []))
        self.preview_widget.regionsChanged.connect(self._on_regions_changed)
        preview_card.body.addWidget(self.preview_widget, 1)

        region_row = QHBoxLayout()
        region_row.setSpacing(8)
        self.region_info = QLabel("全图渲染")
        self.region_info.setStyleSheet(
            f"color:{theme.TEXT_SECONDARY}; font-size:12px; font-weight:600;"
        )
        region_row.addWidget(self.region_info)
        region_row.addStretch()
        self.undo_btn = make_button("撤销区域", "ghost", height=26)
        self.undo_btn.setFixedWidth(90)
        self.undo_btn.clicked.connect(self._undo_region)
        region_row.addWidget(self.undo_btn)
        self.clear_btn = make_button("清除区域", "ghost", height=26)
        self.clear_btn.setFixedWidth(90)
        self.clear_btn.clicked.connect(self._clear_regions)
        region_row.addWidget(self.clear_btn)
        preview_card.body.addLayout(region_row)

        self.region_hint = QLabel("")
        self.region_hint.setWordWrap(True)
        self.region_hint.setStyleSheet(
            f"color:{theme.TEXT_MUTED}; font-size:10px;"
        )
        preview_card.body.addWidget(self.region_hint)

        self.region_error = QLabel("")
        self.region_error.setWordWrap(True)
        self.region_error.setStyleSheet(
            f"color:{theme.DANGER}; font-size:10px;"
        )
        self.region_error.setVisible(False)
        preview_card.body.addWidget(self.region_error)

        note = QLabel("预览为缩小版，生成时按原图分辨率与参数处理；投影会增加白色留白。")
        note.setWordWrap(True)
        note.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:10px;")
        preview_card.body.addWidget(note)
        body.addWidget(preview_card, 1)
        layout.addLayout(body, 1)

        footer = QHBoxLayout()
        reset_btn = make_button("恢复默认", "ghost", height=32)
        reset_btn.clicked.connect(self._reset)
        footer.addWidget(reset_btn)
        footer.addStretch()
        cancel_btn = make_button("取消", "ghost", height=34)
        cancel_btn.clicked.connect(self.reject)
        footer.addWidget(cancel_btn)
        apply_btn = make_button("应用参数", "primary", height=34, min_width=110)
        apply_btn.clicked.connect(self._apply)
        footer.addWidget(apply_btn)
        layout.addLayout(footer)

        self._update_region_controls()

    def _group(self, title, items, with_scale=False, with_range=False):
        card = Card(padding=14, spacing=7)
        card.body.addWidget(SectionTitle(title, 15))

        if with_range:
            row = QWidget()
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.setSpacing(10)
            name = QLabel("渲染范围")
            name.setFixedWidth(76)
            name.setStyleSheet(f"color:{theme.TEXT_SECONDARY}; font-size:12px;")
            row_layout.addWidget(name)
            self.range_combo = QComboBox()
            self.range_combo.addItems(["全图渲染", "局部渲染"])
            self.range_combo.setCurrentIndex(1 if self.params["local"] else 0)
            self.range_combo.currentIndexChanged.connect(self._on_mode_changed)
            row_layout.addWidget(self.range_combo, 1)
            card.body.addWidget(row)

        for key, label, minimum, maximum, default, signed in items:
            row = SliderRow(
                label, minimum, maximum, self.params[key], default, signed
            )
            row.valueChanged.connect(self._schedule_preview)
            self.rows[key] = row
            card.body.addWidget(row)

        if with_scale:
            row = QWidget()
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.setSpacing(10)
            name = QLabel("放大倍数")
            name.setFixedWidth(76)
            name.setStyleSheet(f"color:{theme.TEXT_SECONDARY}; font-size:12px;")
            row_layout.addWidget(name)
            self.scale_combo = QComboBox()
            self.scale_combo.addItems(["1x 原尺寸", "2x 清晰度增强"])
            self.scale_combo.setCurrentIndex(1 if self.params["scale"] >= 2 else 0)
            self.scale_combo.currentIndexChanged.connect(self._schedule_preview)
            row_layout.addWidget(self.scale_combo, 1)
            card.body.addWidget(row)
        return card

    # ---------- 预览 ----------
    def _load_source(self, path):
        img = None
        if path and os.path.isfile(path):
            try:
                with Image.open(path) as source:
                    if source.width * source.height > MAX_IMAGE_PIXELS:
                        raise ValueError("图片像素超过预览上限")
                    # 先缩略再复制，避免大图同时占用两份内存
                    source.thumbnail((1400, 1000), Image.LANCZOS)
                    img = source.copy()
                img = ImageOps.exif_transpose(img)
                if img.mode == "P" and "transparency" in img.info:
                    img = img.convert("RGBA")
                elif img.mode not in ("RGB", "RGBA", "L", "LA", "CMYK"):
                    img = img.convert("RGB")
                self._is_demo = False
                self.source_label.setText(os.path.basename(path))
            except Exception:
                img = None

        if img is None:
            img = make_demo_image()
            self._is_demo = True
            self.source_label.setText(
                "图片无法读取或过大，使用示例图" if path else "示例图（可更换）"
            )

        self._source_img = img
        self._schedule_preview()

    def _change_preview(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "选择预览图片", "", SUPPORTED_IMAGE_FILTER
        )
        if path:
            self._load_source(path)

    def _schedule_preview(self):
        if self._source_img is not None:
            self._preview_timer.start()

    def _is_local(self):
        return self.range_combo.currentIndex() == 1

    def _collect(self):
        params = {key: row.value() for key, row in self.rows.items()}
        params["scale"] = 2 if self.scale_combo.currentIndex() == 1 else 1
        params["local"] = self._is_local()
        params["regions"] = list(self.preview_widget.regions)
        return render_params.normalize(params)

    def _render_preview(self):
        if self._source_img is None:
            return
        params = self._collect()
        try:
            result = engine.apply_adjustments(
                self._source_img, params, upscale=False
            )
            pix = _pil_to_pixmap(result)
        except Exception:
            self.source_label.setText("预览失败")
            return

        self.preview_widget.set_data(
            pix,
            self._source_img.size,
            params["regions"],
            params["local"],
            params["local"],
        )
        self._update_region_controls()

    def showEvent(self, event):
        super().showEvent(event)
        QTimer.singleShot(0, self._render_preview)

    # ---------- 局部区域 ----------
    def _on_mode_changed(self, index):
        local = index == 1
        self.preview_widget.set_mode(local, local)
        self.region_error.setVisible(False)
        self._update_region_controls()
        self._schedule_preview()

    def _on_regions_changed(self):
        self.region_error.setVisible(False)
        self._update_region_controls()
        self._schedule_preview()

    def _update_region_controls(self):
        local = self.range_combo.currentIndex() == 1
        count = len(self.preview_widget.regions)
        if local:
            self.region_info.setText(
                f"局部区域：{count} 个" if count else "局部区域：尚未框选"
            )
            self.region_hint.setText(
                "在预览图上拖动框选区域，可框选多个；框选后可继续调整参数。"
            )
        else:
            self.region_info.setText("全图渲染")
            self.region_hint.setText("当前为全图渲染；切换到“局部渲染”后可框选区域。")
        self.undo_btn.setEnabled(local and count > 0)
        self.clear_btn.setEnabled(local and count > 0)

    def _undo_region(self):
        self.preview_widget.undo_region()
        self._update_region_controls()
        self._schedule_preview()

    def _clear_regions(self):
        self.preview_widget.clear_regions()
        self.region_error.setVisible(False)
        self._update_region_controls()
        self._schedule_preview()

    def _set_region_error(self, message):
        self.region_error.setText(message)
        self.region_error.setVisible(bool(message))

    # ---------- 操作 ----------
    def _reset(self):
        for row in self.rows.values():
            row.reset()
        self.scale_combo.setCurrentIndex(1)
        self.range_combo.setCurrentIndex(0)
        self.preview_widget.clear_regions()
        self.preview_widget.set_mode(False, False)
        self.region_error.setVisible(False)
        self._update_region_controls()
        self._schedule_preview()

    def _apply(self):
        params = self._collect()
        if params["local"] and not params["regions"]:
            self._set_region_error("局部渲染请先在预览图上框选至少一个区域。")
            return
        self.params = params
        self.accept()
