# ui/imageutils.py
# 职责：图片按需缩放读取（避免大图占满内存）、缩略图、图片元信息

import os

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QImageReader, QPixmap


def _read_scaled(path, target_w, target_h, mode):
    reader = QImageReader(path)
    reader.setAutoTransform(True)
    if not reader.canRead():
        return None
    size = reader.size()
    if size.isValid() and size.width() > 0 and size.height() > 0:
        target = size.scaled(
            max(1, int(target_w)), max(1, int(target_h)), mode
        )
        reader.setScaledSize(target)
    image = reader.read()
    if image.isNull():
        return None
    return QPixmap.fromImage(image)


def thumbnail_pixmap(path, width, height):
    """按 2 倍像素解码后居中裁剪，适配高分屏显示。"""
    if not path or not os.path.isfile(path):
        return None
    target_w, target_h = width * 2, height * 2
    pix = _read_scaled(path, target_w, target_h, Qt.KeepAspectRatioByExpanding)
    if pix is None or pix.isNull():
        return None
    if pix.width() < target_w or pix.height() < target_h:
        pix = pix.scaled(
            target_w, target_h,
            Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation
        )
    x = max(0, (pix.width() - target_w) // 2)
    y = max(0, (pix.height() - target_h) // 2)
    cropped = pix.copy(x, y, target_w, target_h)
    cropped.setDevicePixelRatio(2.0)
    return cropped


def preview_pixmap(path, max_width, max_height, dpr=1.0):
    """按屏幕尺寸解码预览图，避免加载超大原图。"""
    if not path or not os.path.isfile(path):
        return None
    return _read_scaled(
        path,
        int(max_width * max(1.0, dpr)),
        int(max_height * max(1.0, dpr)),
        Qt.KeepAspectRatio,
    )


def image_info(path):
    """读取图片尺寸、文件大小与格式，不加载完整像素。"""
    if not path or not os.path.isfile(path):
        return None
    reader = QImageReader(path)
    reader.setAutoTransform(True)
    size = reader.size()
    if not size.isValid() or size.width() <= 0 or size.height() <= 0:
        return None
    try:
        byte_size = os.path.getsize(path)
    except OSError:
        byte_size = 0
    try:
        fmt = bytes(reader.format()).decode("ascii", "ignore").upper()
    except Exception:
        fmt = ""
    return {
        "width": size.width(),
        "height": size.height(),
        "bytes": byte_size,
        "format": fmt,
    }


def is_readable_image(path):
    if not path or not os.path.isfile(path):
        return False
    reader = QImageReader(path)
    reader.setAutoTransform(True)
    return reader.canRead()


def human_size(byte_size):
    value = float(byte_size or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024
    return f"{value:.1f} GB"


def info_text(info):
    if not info:
        return ""
    return f"{info['width']}×{info['height']} · {human_size(info['bytes'])}"
