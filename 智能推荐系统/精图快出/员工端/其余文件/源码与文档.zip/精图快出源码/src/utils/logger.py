# utils/logger.py
# 职责：兼容旧调用的日志封装（实际输出到数据目录 logs 下）

import logging

from core.logging_setup import get_logger


def log_event(message, level="INFO", module=""):
    text = f"[{module}] {message}" if module else str(message)
    get_logger().log(getattr(logging, level, logging.INFO), text)
