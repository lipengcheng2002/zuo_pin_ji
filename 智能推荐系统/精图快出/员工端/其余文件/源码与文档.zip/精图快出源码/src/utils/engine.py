# utils/engine.py
# 职责：企业级图片渲染引擎（Pillow + NumPy）
# sRGB 色彩管理 / 透明通道 / 光影色彩 / 连续降噪 / 局部蒙版 / 投影 / 2x 放大 / 原子写入

import io
import os
import time
import uuid

import numpy as np
from PIL import Image, ImageCms, ImageDraw, ImageEnhance, ImageFilter, ImageOps

from core.render_params import DEFAULTS, normalize

MAX_OUTPUT_SIDE = 6000
MAX_INPUT_SIDE = 6000
MAX_INPUT_PIXELS = 80_000_000

_srgb_cache = None


def _srgb_profile_bytes():
    global _srgb_cache
    if _srgb_cache is None:
        try:
            profile = ImageCms.ImageCmsProfile(ImageCms.createProfile("sRGB"))
            _srgb_cache = profile.tobytes()
        except Exception:
            _srgb_cache = b""
    return _srgb_cache


def _to_srgb(img, icc_bytes):
    if not icc_bytes:
        return img
    try:
        source = ImageCms.ImageCmsProfile(io.BytesIO(icc_bytes))
        target = ImageCms.createProfile("sRGB")
        return ImageCms.profileToProfile(
            img, source, target, outputMode="RGB"
        )
    except Exception:
        return img


def _prepare(img):
    """
    统一色彩空间为 sRGB，提取透明通道与 DPI。
    透明图在处理时铺白底，输出时再还原 alpha（开启投影时输出白底）。
    """
    img = ImageOps.exif_transpose(img)
    dpi = img.info.get("dpi")
    icc_bytes = img.info.get("icc_profile")
    alpha = None
    converted = False

    if icc_bytes and img.mode == "CMYK":
        try:
            source = ImageCms.ImageCmsProfile(io.BytesIO(icc_bytes))
            target = ImageCms.createProfile("sRGB")
            rgb = ImageCms.profileToProfile(
                img, source, target, outputMode="RGB"
            )
            converted = True
        except Exception:
            rgb = img.convert("RGB")
    elif img.mode in ("RGBA", "LA") or (
        img.mode == "P" and "transparency" in img.info
    ):
        rgba = img.convert("RGBA")
        alpha = rgba.getchannel("A")
        rgb = Image.new("RGB", rgba.size, (255, 255, 255))
        rgb.paste(rgba, mask=alpha)
    else:
        rgb = img.convert("RGB")

    if not converted:
        rgb = _to_srgb(rgb, icc_bytes)
    return rgb, alpha, dpi


def _fit_longest(img, max_side):
    width, height = img.size
    longest = max(width, height)
    if longest <= max_side:
        return img
    factor = max_side / float(longest)
    return img.resize(
        (max(1, int(width * factor)), max(1, int(height * factor))),
        Image.LANCZOS,
    )


def _apply_tone(img, params):
    """亮度、对比度、阴影、高光、饱和度、色温。"""
    brightness = params["brightness"]
    if brightness:
        img = ImageEnhance.Brightness(img).enhance(1.0 + brightness / 100.0)

    contrast = params["contrast"]
    if contrast:
        img = ImageEnhance.Contrast(img).enhance(1.0 + contrast / 100.0)

    shadows = params["shadows"]
    highlights = params["highlights"]
    if shadows or highlights:
        array = np.asarray(img).astype(np.float32)
        luminance = (
            array[..., 0] * 0.299
            + array[..., 1] * 0.587
            + array[..., 2] * 0.114
        ) / 255.0
        shadow_mask = np.clip(1.0 - luminance, 0.0, 1.0) ** 2
        highlight_mask = np.clip(luminance, 0.0, 1.0) ** 2
        delta = (
            (shadows / 100.0) * 70.0 * shadow_mask
            + (highlights / 100.0) * 55.0 * highlight_mask
        )
        array = array + delta[..., None]
        img = Image.fromarray(np.clip(array, 0, 255).astype(np.uint8))

    saturation = params["saturation"]
    if saturation:
        img = ImageEnhance.Color(img).enhance(1.0 + saturation / 100.0)

    temperature = params["temperature"]
    if temperature:
        shift = int(temperature / 100.0 * 35)
        array = np.asarray(img).astype(np.int16)
        array[..., 0] = np.clip(array[..., 0] + shift, 0, 255)
        array[..., 1] = np.clip(array[..., 1] + int(shift * 0.4), 0, 255)
        array[..., 2] = np.clip(array[..., 2] - shift, 0, 255)
        img = Image.fromarray(array.astype(np.uint8))

    return img


def _apply_denoise(img, level):
    """中值滤波 + 按强度混合，避免 1 和 100 只有两档效果。"""
    if level <= 0:
        return img
    size = 3 if level <= 50 else 5
    filtered = img.filter(ImageFilter.MedianFilter(size))
    strength = 0.15 + 0.75 * (level / 100.0)
    return Image.blend(img, filtered, strength)


def _apply_sharpen(img, level):
    """细部 + 微对比两段锐化，降低高数值时的硬边光晕。"""
    if level <= 0:
        return img
    ratio = level / 100.0
    img = img.filter(
        ImageFilter.UnsharpMask(
            radius=1.2, percent=int(70 * ratio), threshold=2
        )
    )
    if ratio > 0.4:
        extra = (ratio - 0.4) / 0.6
        img = img.filter(
            ImageFilter.UnsharpMask(
                radius=3.0, percent=int(35 * extra), threshold=3
            )
        )
    return img


def _apply_vignette(img, strength):
    array = np.asarray(img).astype(np.float32)
    height, width = array.shape[:2]
    yy, xx = np.mgrid[0:height, 0:width]
    cx, cy = (width - 1) / 2.0, (height - 1) / 2.0
    dx = (xx - cx) / max(cx, 1.0)
    dy = (yy - cy) / max(cy, 1.0)
    distance = np.sqrt(dx * dx + dy * dy) / np.sqrt(2.0)
    mask = 1.0 - (strength / 100.0) * np.clip(distance, 0.0, 1.0) ** 2 * 0.85
    array = array * mask[..., None]
    return Image.fromarray(np.clip(array, 0, 255).astype(np.uint8))


def _region_mask(size, regions, feather):
    """按归一化区域生成局部蒙版，支持羽化。"""
    width, height = size
    mask = Image.new("L", (width, height), 0)
    draw = ImageDraw.Draw(mask)
    for region in regions:
        x0 = int(region["x"] * width)
        y0 = int(region["y"] * height)
        x1 = int((region["x"] + region["w"]) * width)
        y1 = int((region["y"] + region["h"]) * height)
        if x1 <= x0 or y1 <= y0:
            continue
        draw.rectangle(
            [x0, y0, max(x0, x1 - 1), max(y0, y1 - 1)],
            fill=255,
        )
    radius = int((feather / 100.0) * min(width, height) * 0.04)
    if radius > 0:
        mask = mask.filter(ImageFilter.GaussianBlur(radius))
    return mask


def _apply_projection(img, strength):
    """在白色画布上生成柔和投影，输出带留白的展示图。"""
    ratio = max(0, min(100, strength)) / 100.0
    width, height = img.size
    base = max(width, height)
    pad = max(12, int(base * (0.03 + 0.05 * ratio)))
    offset = max(2, int(pad * (0.25 + 0.35 * ratio)))
    blur = max(2.0, base * (0.004 + 0.012 * ratio))
    opacity = int(30 + 120 * ratio)
    radius = max(6, int(base * 0.008))

    canvas = Image.new("RGB", (width + 2 * pad, height + 2 * pad), (255, 255, 255))
    shadow = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(shadow)
    draw.rounded_rectangle(
        [pad + offset, pad + offset, pad + offset + width, pad + offset + height],
        radius=radius,
        fill=(0, 0, 0, opacity),
    )
    shadow = shadow.filter(ImageFilter.GaussianBlur(blur))
    canvas = Image.alpha_composite(canvas.convert("RGBA"), shadow)
    canvas.paste(img, (pad, pad))
    return canvas.convert("RGB")


def apply_adjustments(img, params, upscale=False, progress=None):
    """
    对 PIL 图片执行完整参数管线，返回新的 PIL 图片。
    upscale=False 用于对话框实时预览（不放大，限制尺寸）。
    """
    params = normalize(params)

    def report(percent, stage):
        if progress is not None:
            progress(int(percent), stage)

    report(4, "载入")
    rgb, alpha, dpi = _prepare(img)
    rgb = _fit_longest(rgb, MAX_INPUT_SIDE if upscale else 2000)

    local = bool(params["local"] and params["regions"])
    base = rgb.copy() if local else None

    report(12, "光影与色彩")
    rgb = _apply_tone(rgb, params)

    report(28, "降噪")
    if params["denoise"]:
        rgb = _apply_denoise(rgb, params["denoise"])

    if params["vignette"]:
        report(38, "暗角")
        rgb = _apply_vignette(rgb, params["vignette"])

    report(46, "放大")
    if upscale and params["scale"] >= 2:
        width, height = rgb.size
        factor = 2.0
        if max(width, height) * factor > MAX_OUTPUT_SIDE:
            factor = MAX_OUTPUT_SIDE / float(max(width, height))
        if factor > 1.0:
            new_size = (
                max(1, int(width * factor)), max(1, int(height * factor))
            )
            rgb = rgb.resize(new_size, Image.LANCZOS)
            if base is not None:
                base = base.resize(new_size, Image.LANCZOS)

    report(64, "锐化")
    if params["sharpen"]:
        rgb = _apply_sharpen(rgb, params["sharpen"])

    if local:
        report(76, "局部合成")
        mask = _region_mask(rgb.size, params["regions"], params["feather"])
        rgb = Image.composite(rgb, base, mask)

    if params["projection"]:
        report(86, "投影")
        rgb = _apply_projection(rgb, params["projection"])
        # 投影会增加留白，统一在此保证输出长边不超过上限
        rgb = _fit_longest(rgb, MAX_OUTPUT_SIDE)

    if alpha is not None and not params["projection"]:
        if alpha.size != rgb.size:
            alpha = alpha.resize(rgb.size, Image.LANCZOS)
        rgb = rgb.convert("RGBA")
        rgb.putalpha(alpha)

    report(95, "输出")
    return rgb


def render_image(input_path, output_path, params=None, progress=None):
    """按参数渲染并原子写入 PNG（sRGB、保留 DPI 与透明通道）。"""
    # 临时文件带进程号与随机后缀，避免两个实例/线程写同一输出时互相覆盖
    temp_path = f"{output_path}.{os.getpid()}.{uuid.uuid4().hex}.tmp"
    try:
        with Image.open(input_path) as img:
            if img.width * img.height > MAX_INPUT_PIXELS:
                return False
            dpi = img.info.get("dpi")
            result = apply_adjustments(
                img, params or DEFAULTS, upscale=True, progress=progress
            )
            if progress is not None:
                progress(97, "保存")
            save_kwargs = {"format": "PNG"}
            profile = _srgb_profile_bytes()
            if profile:
                save_kwargs["icc_profile"] = profile
            if isinstance(dpi, tuple) and len(dpi) == 2 and dpi[0] and dpi[1]:
                save_kwargs["dpi"] = dpi
            result.save(temp_path, **save_kwargs)
        # Windows 下两个实例同时替换同一目标会偶发共享冲突，短暂重试
        for attempt in range(5):
            try:
                os.replace(temp_path, output_path)
                break
            except PermissionError:
                if attempt >= 4:
                    raise
                time.sleep(0.05 * (attempt + 1))
        if progress is not None:
            progress(100, "完成")
        return True
    except Exception:
        try:
            if os.path.exists(temp_path):
                os.remove(temp_path)
        except OSError:
            pass
        return False


# 兼容旧调用
def enhance_image(input_path, output_path, scale=2):
    params = dict(DEFAULTS)
    params["scale"] = scale
    return render_image(input_path, output_path, params)
