# admin_main.py
# 精图快出 · 管理员智能体入口

import os
import sys

from PyQt5.QtCore import Qt, QSettings
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import (
    QApplication, QButtonGroup, QFrame, QHBoxLayout, QLabel, QMainWindow,
    QMessageBox, QPushButton, QScrollArea, QStackedWidget, QVBoxLayout, QWidget
)

from core.config import ADMIN_TITLE, APP_NAME, ORG_NAME, VERSION, scaled
from core.logging_setup import install_excepthook, setup_logging
from core.models import init_db
from pages.admin_accounts import AccountsPage
from pages.admin_audit import AuditPage
from pages.admin_dashboard import DashboardPage
from pages.admin_employees import EmployeesPage
from pages.admin_register import RegisterPage
from ui import theme
from ui.widgets import center_on_screen, fit_scaled


def _resource_path(relative):
    if getattr(sys, "_MEIPASS", False):
        base = sys._MEIPASS
    else:
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, relative)


class AdminWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.settings = QSettings(ORG_NAME, f"{APP_NAME}-管理员")
        self.setWindowTitle(ADMIN_TITLE)
        fit_scaled(self, 1280, 820, 1120, 700)
        self._build_ui()
        self._restore_geometry()
        center_on_screen(self)
        self.set_page(0)

    def _build_ui(self):
        central = QWidget()
        central.setObjectName("page")
        self.setCentralWidget(central)
        layout = QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        layout.addWidget(self._build_sidebar())

        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        self.pages = QStackedWidget()

        self.dashboard_page = DashboardPage(
            on_open_employees=lambda: self.set_page(2),
            on_open_employee=self._open_employee,
        )
        self.register_page = RegisterPage(on_data_changed=self.refresh_all)
        self.employees_page = EmployeesPage()
        self.accounts_page = AccountsPage(on_data_changed=self.refresh_all)
        self.audit_page = AuditPage()

        self.page_widgets = []
        for page in (
            self.dashboard_page, self.register_page,
            self.employees_page, self.accounts_page, self.audit_page,
        ):
            self.page_widgets.append(page)
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QFrame.NoFrame)
            scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            scroll.setStyleSheet(
                "QScrollArea{background:transparent; border:none;} "
                "QScrollArea > QWidget > QWidget{background:transparent;}"
            )
            scroll.setWidget(page)
            self.pages.addWidget(scroll)
        content_layout.addWidget(self.pages)
        layout.addWidget(content, 1)

    def _build_sidebar(self):
        sidebar = QFrame()
        sidebar.setFixedWidth(scaled(236))
        sidebar.setStyleSheet(
            f"QFrame{{background:{theme.SIDEBAR}; border:none;}}"
            f"QLabel{{background:transparent;}}"
        )
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        brand = QWidget()
        brand.setFixedHeight(72)
        brand_layout = QHBoxLayout(brand)
        brand_layout.setContentsMargins(12, 0, 12, 0)
        brand_layout.setSpacing(8)

        logo = QLabel("精")
        logo.setFixedSize(30, 30)
        logo.setAlignment(Qt.AlignCenter)
        logo.setStyleSheet(
            f"background:{theme.PRIMARY}; color:#FFFFFF; border-radius:8px; "
            "font-size:16px; font-weight:700;"
        )
        brand_layout.addWidget(logo)

        text = QVBoxLayout()
        text.setSpacing(0)
        name = QLabel(APP_NAME)
        name.setStyleSheet("color:#FFFFFF; font-size:15px; font-weight:700;")
        sub = QLabel("管理员智能体")
        sub.setStyleSheet(f"color:{theme.SIDEBAR_MUTED}; font-size:10px;")
        text.addWidget(name)
        text.addWidget(sub)
        brand_layout.addLayout(text)
        brand_layout.addStretch()
        layout.addWidget(brand)

        nav_holder = QWidget()
        nav_layout = QVBoxLayout(nav_holder)
        nav_layout.setContentsMargins(0, 6, 0, 6)
        nav_layout.setSpacing(0)

        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        items = [
            ("运营概览", "账号与修改数据总览"),
            ("注册账号", "为员工开通主程序账号"),
            ("员工管理", "查看员工修改明细"),
            ("账号管理", "停用或删除账号"),
            ("操作日志", "审计关键操作记录"),
        ]
        for index, (title, tooltip) in enumerate(items):
            btn = QPushButton(title)
            btn.setObjectName("navButton")
            btn.setCheckable(True)
            btn.setFixedHeight(40)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setToolTip(tooltip)
            self.nav_group.addButton(btn, index)
            nav_layout.addWidget(btn)
        self.nav_group.buttonClicked[int].connect(self.set_page)
        layout.addWidget(nav_holder)
        layout.addStretch()

        footer = QFrame()
        footer_layout = QVBoxLayout(footer)
        footer_layout.setContentsMargins(12, 12, 12, 14)
        footer_layout.setSpacing(4)

        status = QHBoxLayout()
        status.setSpacing(5)
        dot = QLabel("●")
        dot.setStyleSheet(f"color:{theme.SUCCESS}; font-size:9px;")
        status.addWidget(dot)
        status_text = QLabel("数据服务已连接")
        status_text.setStyleSheet(
            f"color:{theme.SIDEBAR_TEXT}; font-size:10px;"
        )
        status.addWidget(status_text)
        status.addStretch()
        footer_layout.addLayout(status)

        sync = QLabel(f"v{VERSION} · 双端实时同步")
        sync.setStyleSheet(f"color:{theme.SIDEBAR_MUTED}; font-size:9px;")
        sync.setWordWrap(True)
        footer_layout.addWidget(sync)
        layout.addWidget(footer)
        return sidebar

    def _open_employee(self, user_id):
        self.set_page(2)
        self.employees_page.open_detail(user_id)

    def set_page(self, index):
        if index < 0 or index >= self.pages.count():
            return
        self.stack_index = index
        self.pages.setCurrentIndex(index)
        for i, button in enumerate(self.nav_group.buttons()):
            button.setChecked(i == index)
        page = self.page_widgets[index]
        # 点击侧边栏「员工管理」时回到列表，而不是停留在上一次的详情页
        if index == 2 and hasattr(page, "show_list") and page.stack.currentIndex() == 1:
            page.show_list()
        if hasattr(page, "refresh"):
            page.refresh()

    def refresh_all(self):
        for page in self.page_widgets:
            if hasattr(page, "refresh"):
                page.refresh()

    def _restore_geometry(self):
        geometry = self.settings.value("admin/geometry_v24")
        if geometry:
            self.restoreGeometry(geometry)

    def closeEvent(self, event):
        self.settings.setValue("admin/geometry_v24", self.saveGeometry())
        super().closeEvent(event)


def main():
    setup_logging("admin")
    install_excepthook(ADMIN_TITLE)

    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    app = QApplication(sys.argv)
    theme.apply_theme(app)
    icon_path = _resource_path(os.path.join("assets", "app.ico"))
    if os.path.exists(icon_path):
        app.setWindowIcon(QIcon(icon_path))

    if not init_db():
        QMessageBox.critical(
            None, "启动失败",
            "无法初始化本地数据库，请检查数据目录权限后重试。"
        )
        return 1

    window = AdminWindow()
    window.show()
    return app.exec_()


if __name__ == "__main__":
    sys.exit(main())
