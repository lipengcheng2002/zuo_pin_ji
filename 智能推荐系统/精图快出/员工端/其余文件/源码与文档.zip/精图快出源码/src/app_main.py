﻿# app_main.py
# 精图快出 · 主程序入口

import os
import sys

from PyQt5.QtCore import Qt, QThread, QTimer, pyqtSignal, QSettings, QUrl
from PyQt5.QtGui import QDesktopServices, QIcon
from PyQt5.QtWidgets import (
    QApplication, QDialog, QFileDialog, QFrame, QHBoxLayout, QLabel,
    QLineEdit, QMainWindow, QMessageBox, QProgressBar, QPushButton,
    QScrollArea, QVBoxLayout, QWidget
)

from core import audit, auth, render_params, repo
from core.config import (
    APP_NAME, MAX_IMAGE_MB, MAX_IMAGE_PIXELS, ORG_NAME, scaled,
    SUPPORTED_IMAGE_EXTS, SUPPORTED_IMAGE_FILTER, VERSION
)
from core.logging_setup import get_logger, install_excepthook, setup_logging
from core.models import init_db
from core.session import Session
from pages.profile_page import ProfilePage
from ui import theme
from ui.imageutils import human_size, image_info, is_readable_image
from ui.preview import ImagePreviewDialog
from ui.render_dialog import RenderDialog
from ui.toast import show_toast
from ui.widgets import (
    Card, ClickableFrame, HLine, PasswordStrengthBar, SectionTitle,
    center_on_parent, center_on_screen, fit_scaled, make_button
)
from utils.engine import render_image


def _resource_path(relative):
    if getattr(sys, "_MEIPASS", False):
        base = sys._MEIPASS
    else:
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, relative)


def _account_state(user_id):
    """读取账号状态；数据库暂时不可用时返回 unknown，不阻断渲染。"""
    try:
        return auth.get_account_state(user_id)
    except Exception:
        get_logger().exception("读取账号状态失败")
        return "unknown"


# ================== 批量异步处理 ==================
class BatchRenderWorker(QThread):
    job_started = pyqtSignal(int, int, str)
    job_progress = pyqtSignal(int, str)
    job_finished = pyqtSignal(int, bool, str, str)
    account_lost = pyqtSignal(str)
    all_done = pyqtSignal(bool)

    def __init__(self, jobs, params, user_id, parent=None):
        super().__init__(parent)
        self.jobs = jobs
        self.params = params
        self.user_id = user_id
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def run(self):
        total = len(self.jobs)
        for index, (source, output) in enumerate(self.jobs):
            if self._cancel:
                break
            if self.user_id is not None:
                state = _account_state(self.user_id)
                if state in ("disabled", "deleted"):
                    self.account_lost.emit(state)
                    break
            self.job_started.emit(index, total, os.path.basename(source))

            def report(percent, stage):
                self.job_progress.emit(int(percent), stage)

            try:
                ok = render_image(source, output, self.params, progress=report)
            except Exception:
                get_logger().exception("批量渲染异常")
                ok = False
            self.job_finished.emit(index, ok, source, output)
        self.all_done.emit(self._cancel)


class BatchProgressDialog(QDialog):
    """批量处理进度：逐张进度、阶段进度与取消。"""

    cancelRequested = pyqtSignal()

    def __init__(self, total, parent=None):
        super().__init__(parent)
        self._total = max(1, total)
        self._index = 0
        self._name = ""
        self._finished = False
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setModal(True)
        self.setFixedSize(scaled(470), scaled(220))
        self.setStyleSheet(f"QDialog{{background:{theme.CARD}; border-radius:12px;}}")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 14)
        layout.setSpacing(5)

        title = QLabel("批量处理中" if total > 1 else "正在生成效果图")
        title.setStyleSheet(f"font-size:15px; font-weight:700; color:{theme.TEXT};")
        layout.addWidget(title)

        self.detail = QLabel("准备中…")
        self.detail.setWordWrap(True)
        self.detail.setTextFormat(Qt.PlainText)
        self.detail.setMinimumHeight(26)
        self.detail.setStyleSheet(
            f"color:{theme.TEXT_SECONDARY}; font-size:10px;"
        )
        layout.addWidget(self.detail)

        self.bar = QProgressBar()
        self.bar.setRange(0, self._total * 100)
        self.bar.setValue(0)
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(5)
        self.bar.setStyleSheet(
            f"QProgressBar{{background:#F1F3F6; border:none; border-radius:3px;}}"
            f"QProgressBar::chunk{{background:{theme.PRIMARY}; border-radius:3px;}}"
        )
        layout.addWidget(self.bar)

        row = QHBoxLayout()
        self.hint = QLabel("可取消，当前图片完成后停止")
        self.hint.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:9px;")
        row.addWidget(self.hint)
        row.addStretch()
        self.cancel_btn = make_button("取消处理", "ghost", height=28)
        self.cancel_btn.setFixedWidth(80)
        self.cancel_btn.clicked.connect(self._request_cancel)
        row.addWidget(self.cancel_btn)
        layout.addLayout(row)
        center_on_parent(self)

    def set_current(self, index, total, name):
        self._index = index
        self._total = max(1, total)
        self._name = name
        self.bar.setValue(index * 100)
        self.detail.setText(
            f"正在处理 {index + 1}/{self._total} · {name} · 准备"
        )

    def set_stage(self, percent, stage):
        percent = max(0, min(100, int(percent)))
        self.bar.setValue(self._index * 100 + percent)
        self.detail.setText(
            f"正在处理 {self._index + 1}/{self._total} · {self._name}"
            f" · {stage} {percent}%"
        )

    def _request_cancel(self):
        self.cancel_btn.setEnabled(False)
        self.hint.setText("正在取消…（当前图片完成后停止）")
        self.cancelRequested.emit()

    def closeEvent(self, event):
        if self._finished:
            super().closeEvent(event)
        else:
            self._request_cancel()
            event.ignore()

    def finish(self):
        self._finished = True
        self.close()


# ================== 首次登录改密 ==================
class ResetPasswordDialog(QDialog):
    def __init__(self, user, parent=None):
        super().__init__(parent)
        self.user = user
        self.setWindowTitle("设置新密码 - 精图快出")
        self.setModal(True)
        self.setFixedSize(scaled(480), scaled(650) + 24)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        card = Card(padding=16, spacing=3)
        layout.addWidget(card)

        title = QLabel("设置新密码")
        title.setStyleSheet(f"font-size:18px; font-weight:700; color:{theme.TEXT};")
        card.body.addWidget(title)
        subtitle = QLabel("首次登录，请先重置初始密码")
        subtitle.setStyleSheet(f"color:{theme.TEXT_SECONDARY}; font-size:10px;")
        card.body.addWidget(subtitle)

        info = QFrame()
        info.setStyleSheet(
            f"background:{theme.PRIMARY_SOFT}; border:1px solid #F0D6C2; border-radius:8px;"
        )
        info_layout = QVBoxLayout(info)
        info_layout.setContentsMargins(8, 6, 8, 6)
        info_text = QLabel(
            f"当前账号：{user['name']} · 初始密码 {auth.DEFAULT_PASSWORD} "
            "仅用于首次登录，请设置新的字母+数字密码。"
        )
        info_text.setTextFormat(Qt.PlainText)
        info_text.setWordWrap(True)
        info_text.setStyleSheet(f"color:{theme.PRIMARY_PRESSED}; font-size:9px;")
        info_layout.addWidget(info_text)
        card.body.addWidget(info)

        card.body.addWidget(self._field_label("新密码"))
        self.new_edit = QLineEdit()
        self.new_edit.setEchoMode(QLineEdit.Password)
        self.new_edit.setPlaceholderText("至少 8 位，同时包含字母和数字")
        self.new_edit.setFixedHeight(30)
        self.new_edit.textChanged.connect(self._on_password_changed)
        card.body.addWidget(self.new_edit)

        self.strength = PasswordStrengthBar()
        card.body.addWidget(self.strength)

        card.body.addWidget(self._field_label("确认新密码"))
        self.confirm_edit = QLineEdit()
        self.confirm_edit.setEchoMode(QLineEdit.Password)
        self.confirm_edit.setPlaceholderText("请再次输入新密码")
        self.confirm_edit.setFixedHeight(30)
        self.confirm_edit.returnPressed.connect(self._submit)
        card.body.addWidget(self.confirm_edit)

        self.error_label = QLabel("")
        self.error_label.setWordWrap(True)
        self.error_label.setStyleSheet(f"color:{theme.DANGER}; font-size:10px;")
        self.error_label.setVisible(False)
        card.body.addWidget(self.error_label)

        submit_btn = make_button("确认并进入", "primary", height=32)
        submit_btn.clicked.connect(self._submit)
        card.body.addWidget(submit_btn)

        quit_btn = make_button("退出登录", "ghost", height=26)
        quit_btn.clicked.connect(self.reject)
        card.body.addWidget(quit_btn)

        card.body.addStretch()
        center_on_parent(self)

    @staticmethod
    def _field_label(text):
        label = QLabel(text)
        label.setStyleSheet(
            f"color:{theme.TEXT_SECONDARY}; font-size:10px; font-weight:600;"
        )
        return label

    def _on_password_changed(self, text):
        self.strength.set_password(text)
        self._set_error("")

    def _set_error(self, message):
        self.error_label.setText(message)
        self.error_label.setVisible(bool(message))

    def _submit(self):
        self._set_error("")
        new_pw = self.new_edit.text()
        confirm = self.confirm_edit.text()
        if not new_pw or not confirm:
            self._set_error("请输入新密码并确认。")
            return
        if new_pw != confirm:
            self._set_error("两次输入的新密码不一致。")
            return
        ok, msg = auth.reset_password(self.user["id"], new_pw)
        if not ok:
            self._set_error(msg)
            return
        self.user["must_reset"] = False
        self.accept()


# ================== 登录 ==================
class LoginDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.user = None
        self.setWindowTitle("登录 - 精图快出")
        self.setModal(True)
        self.setFixedSize(scaled(460), scaled(660))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        card = Card(padding=22, spacing=5)
        layout.addWidget(card)

        brand = QHBoxLayout()
        brand.setSpacing(8)
        logo = QLabel("精")
        logo.setFixedSize(32, 32)
        logo.setAlignment(Qt.AlignCenter)
        logo.setStyleSheet(
            f"background:{theme.PRIMARY}; color:#FFFFFF; border-radius:8px; "
            "font-size:16px; font-weight:700;"
        )
        brand.addWidget(logo)
        brand_text = QVBoxLayout()
        brand_text.setSpacing(0)
        name = QLabel(APP_NAME)
        name.setStyleSheet(f"font-size:17px; font-weight:700; color:{theme.TEXT};")
        sub = QLabel(f"图片精修工作台 · v{VERSION}")
        sub.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:9px;")
        brand_text.addWidget(name)
        brand_text.addWidget(sub)
        brand.addLayout(brand_text)
        brand.addStretch()
        card.body.addLayout(brand)
        card.body.addSpacing(4)

        title = QLabel("登录")
        title.setStyleSheet(f"font-size:20px; font-weight:700; color:{theme.TEXT};")
        card.body.addWidget(title)
        hint = QLabel("使用管理员开通的姓名与密码登录")
        hint.setStyleSheet(f"color:{theme.TEXT_SECONDARY}; font-size:11px;")
        card.body.addWidget(hint)

        card.body.addSpacing(3)
        card.body.addWidget(self._field_label("姓名"))
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("请输入姓名")
        self.name_edit.setFixedHeight(34)
        self.name_edit.textChanged.connect(lambda _: self._set_error(""))
        card.body.addWidget(self.name_edit)

        card.body.addWidget(self._field_label("密码"))
        pwd_row = QHBoxLayout()
        pwd_row.setSpacing(6)
        self.pwd_edit = QLineEdit()
        self.pwd_edit.setEchoMode(QLineEdit.Password)
        self.pwd_edit.setPlaceholderText("请输入密码")
        self.pwd_edit.setFixedHeight(34)
        self.pwd_edit.returnPressed.connect(self._submit)
        self.pwd_edit.textChanged.connect(lambda _: self._set_error(""))
        self.eye_btn = QPushButton("👁")
        self.eye_btn.setObjectName("eyeButton")
        self.eye_btn.setFixedSize(38, 34)
        self.eye_btn.setCursor(Qt.PointingHandCursor)
        self.eye_btn.clicked.connect(self._toggle_password)
        pwd_row.addWidget(self.pwd_edit, 1)
        pwd_row.addWidget(self.eye_btn)
        card.body.addLayout(pwd_row)

        self.error_label = QLabel("")
        self.error_label.setWordWrap(True)
        self.error_label.setStyleSheet(f"color:{theme.DANGER}; font-size:11px;")
        self.error_label.setVisible(False)
        card.body.addWidget(self.error_label)

        card.body.addSpacing(3)
        login_btn = make_button("登录", "primary", height=38)
        login_btn.clicked.connect(self._submit)
        card.body.addWidget(login_btn)

        tip = QLabel("账号由管理员统一开通；如无法登录请联系管理员")
        tip.setWordWrap(True)
        tip.setAlignment(Qt.AlignCenter)
        tip.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:10px;")
        card.body.addWidget(tip)

        card.body.addStretch()
        footer = QLabel(f"{APP_NAME} v{VERSION} · 本地图片精修")
        footer.setAlignment(Qt.AlignCenter)
        footer.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:9px;")
        card.body.addWidget(footer)

        center_on_parent(self)
        self.name_edit.setFocus()

    @staticmethod
    def _field_label(text):
        label = QLabel(text)
        label.setStyleSheet(
            f"color:{theme.TEXT_SECONDARY}; font-size:11px; font-weight:600;"
        )
        return label

    def _set_error(self, message):
        self.error_label.setText(message)
        self.error_label.setVisible(bool(message))

    def _toggle_password(self):
        if self.pwd_edit.echoMode() == QLineEdit.Password:
            self.pwd_edit.setEchoMode(QLineEdit.Normal)
            self.eye_btn.setText("🙈")
        else:
            self.pwd_edit.setEchoMode(QLineEdit.Password)
            self.eye_btn.setText("👁")

    def _submit(self):
        self._set_error("")
        name = self.name_edit.text().strip()
        password = self.pwd_edit.text()
        if not name or not password:
            self._set_error("请输入姓名和密码。")
            return

        user, error = auth.authenticate(name, password)
        if not user:
            self._set_error(error)
            return

        if user["must_reset"]:
            reset = ResetPasswordDialog(user, self)
            if reset.exec_() != QDialog.Accepted:
                self._set_error("首次登录必须重置初始密码后才能进入主程序。")
                return

        self.user = user
        self.accept()


# ================== 主窗口 ==================
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.session = Session()
        self.settings = QSettings(ORG_NAME, APP_NAME)
        self.render_settings = render_params.load_json(
            self.settings.value("render/params")
        )
        self.worker = None
        self.progress_dialog = None
        self._last_input = None
        self._batch_total = 0
        self._batch_results = []
        self._batch_skipped = 0
        self._batch_params = None
        self._batch_account_lost = None

        self.setWindowTitle(APP_NAME)
        self.setStyleSheet(f"QMainWindow{{background:{theme.BG};}}")
        fit_scaled(self, 1200, 800, 1040, 720)
        self.setAcceptDrops(True)
        self._build_ui()
        self._apply_logged_out()
        self._restore_geometry()
        center_on_screen(self)

        # 管理员停用/删除账号后，最长 15 秒内自动退出，无需等用户下一次操作
        self._state_timer = QTimer(self)
        self._state_timer.setInterval(15000)
        self._state_timer.timeout.connect(self._periodic_state_check)
        self._state_timer.start()

    # ---------- 界面 ----------
    def _build_ui(self):
        central = QWidget()
        central.setObjectName("page")
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_header())
        body = QWidget()
        body_layout = QHBoxLayout(body)
        body_layout.setContentsMargins(24, 14, 24, 16)
        body_layout.setSpacing(16)
        body_layout.addWidget(self._build_upload_card(), 3)
        body_layout.addLayout(self._build_side_column(), 2)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setStyleSheet(
            "QScrollArea{background:transparent; border:none;} "
            "QScrollArea > QWidget > QWidget{background:transparent;}"
        )
        scroll.setWidget(body)
        root.addWidget(scroll, 1)

    def _build_header(self):
        header = QFrame()
        header.setObjectName("headerBar")
        header.setFixedHeight(64)
        layout = QHBoxLayout(header)
        layout.setContentsMargins(24, 0, 24, 0)
        layout.setSpacing(10)

        logo = QLabel("精")
        logo.setFixedSize(36, 36)
        logo.setAlignment(Qt.AlignCenter)
        logo.setStyleSheet(
            f"background:{theme.PRIMARY}; color:#FFFFFF; border-radius:9px; "
            "font-size:18px; font-weight:700;"
        )
        layout.addWidget(logo)

        brand = QVBoxLayout()
        brand.setSpacing(0)
        name = QLabel(APP_NAME)
        name.setStyleSheet(f"font-size:20px; font-weight:700; color:{theme.TEXT};")
        sub = QLabel(f"图片精修工作台 · v{VERSION}")
        sub.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:10px;")
        brand.addWidget(name)
        brand.addWidget(sub)
        layout.addLayout(brand)
        layout.addStretch()

        self.welcome_label = QLabel("")
        self.welcome_label.setTextFormat(Qt.PlainText)
        self.welcome_label.setStyleSheet(
            f"color:{theme.TEXT}; font-size:13px; font-weight:600;"
        )
        self.welcome_label.setVisible(False)
        layout.addWidget(self.welcome_label)

        self.profile_btn = make_button("个人中心", "ghost", height=32)
        self.profile_btn.clicked.connect(self._open_profile)
        self.profile_btn.setVisible(False)
        layout.addWidget(self.profile_btn)

        self.logout_btn = make_button("退出登录", "ghost", height=32)
        self.logout_btn.clicked.connect(self._logout)
        self.logout_btn.setVisible(False)
        layout.addWidget(self.logout_btn)

        self.login_btn = make_button("登录", "primary", height=32, min_width=76)
        self.login_btn.clicked.connect(self._open_login)
        layout.addWidget(self.login_btn)
        return header

    def _build_upload_card(self):
        card = Card(padding=24, spacing=0)
        body = card.body

        eyebrow = QLabel("专业渲染 · 本地处理")
        eyebrow.setStyleSheet(
            f"color:{theme.PRIMARY}; font-size:11px; font-weight:700;"
        )
        body.addWidget(eyebrow)
        body.addSpacing(6)

        title = QLabel("上传图片，按参数生成精修效果图")
        title.setStyleSheet(f"color:{theme.TEXT}; font-size:22px; font-weight:700;")
        title.setWordWrap(True)
        body.addWidget(title)
        body.addSpacing(4)

        subtitle = QLabel(
            "可调节光影、色彩、细节、投影与局部区域；支持单张精修与多张批量处理，全程本地完成。"
        )
        subtitle.setStyleSheet(f"color:{theme.TEXT_SECONDARY}; font-size:12px;")
        subtitle.setWordWrap(True)
        body.addWidget(subtitle)
        body.addSpacing(12)

        self.drop_zone = ClickableFrame()
        self.drop_zone.setObjectName("dropZone")
        self.drop_zone.setFixedHeight(150)
        self.drop_zone.setCursor(Qt.PointingHandCursor)
        self.drop_zone.clicked.connect(self._on_generate)
        zone_layout = QVBoxLayout(self.drop_zone)
        zone_layout.setContentsMargins(16, 14, 16, 14)
        zone_layout.setSpacing(6)
        zone_layout.setAlignment(Qt.AlignCenter)

        plus = QLabel("＋")
        plus.setFixedSize(44, 44)
        plus.setAlignment(Qt.AlignCenter)
        plus.setStyleSheet(
            f"background:#FBE3D3; color:{theme.PRIMARY}; border-radius:22px; "
            "font-size:22px; font-weight:700;"
        )
        zone_layout.addWidget(plus, 0, Qt.AlignHCenter)

        self.zone_title = QLabel("点击选择或拖拽图片（可多张）")
        self.zone_title.setStyleSheet(
            f"color:{theme.TEXT}; font-size:15px; font-weight:600;"
        )
        zone_layout.addWidget(self.zone_title, 0, Qt.AlignHCenter)

        zone_hint = QLabel(
            f"支持 JPG / PNG / BMP / WEBP · 可多选/拖拽多张 · 单张≤{MAX_IMAGE_MB}MB"
        )
        zone_hint.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:11px;")
        zone_layout.addWidget(zone_hint, 0, Qt.AlignHCenter)
        body.addWidget(self.drop_zone)
        body.addSpacing(12)

        self.generate_btn = make_button("选择图片并生成", "primary", height=42)
        self.generate_btn.setToolTip("支持多选，批量应用当前渲染参数")
        self.generate_btn.clicked.connect(self._on_generate)
        generate_row = QHBoxLayout()
        generate_row.setSpacing(8)
        generate_row.addWidget(self.generate_btn, 1)

        self.params_btn = make_button("渲染参数", "ghost", height=42)
        self.params_btn.setFixedWidth(100)
        self.params_btn.setToolTip(
            "调整亮度、对比度、阴影、高光、饱和度、色温、锐化、"
            "降噪、暗角、投影与放大倍数"
        )
        self.params_btn.clicked.connect(self._open_render_settings)
        generate_row.addWidget(self.params_btn)
        body.addLayout(generate_row)
        body.addSpacing(5)

        self.params_summary_label = QLabel("")
        self.params_summary_label.setStyleSheet(
            f"color:{theme.TEXT_SECONDARY}; font-size:10px;"
        )
        self.params_summary_label.setWordWrap(True)
        body.addWidget(self.params_summary_label)
        self._update_params_summary()
        body.addSpacing(3)

        self.status_label = QLabel("请先登录，账号由管理员统一开通")
        self.status_label.setTextFormat(Qt.PlainText)
        self.status_label.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:11px;")
        self.status_label.setWordWrap(True)
        body.addWidget(self.status_label)
        body.addStretch()
        body.addSpacing(8)
        body.addWidget(HLine())
        body.addSpacing(3)

        features = QHBoxLayout()
        features.setSpacing(14)
        for title_text, desc in (
            ("本地处理", "图片不外传"),
            ("专业渲染", "参数可调"),
            ("一键下载", "效果图保存"),
        ):
            block = QVBoxLayout()
            block.setSpacing(1)
            title_label = QLabel(title_text)
            title_label.setStyleSheet(
                f"color:{theme.TEXT}; font-size:11px; font-weight:600;"
            )
            desc_label = QLabel(desc)
            desc_label.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:10px;")
            block.addWidget(title_label)
            block.addWidget(desc_label)
            features.addLayout(block, 1)
        body.addLayout(features)
        return card

    def _build_side_column(self):
        column = QVBoxLayout()
        column.setSpacing(12)

        usage = Card(padding=18, spacing=6)
        usage.setMinimumHeight(130)
        usage.body.addWidget(SectionTitle("我的使用", 15))
        self.usage_name = QLabel("未登录")
        self.usage_name.setTextFormat(Qt.PlainText)
        self.usage_name.setStyleSheet(
            f"color:{theme.TEXT}; font-size:17px; font-weight:700;"
        )
        usage.body.addWidget(self.usage_name)
        self.usage_count = QLabel("累计修改 0 次")
        self.usage_count.setStyleSheet(
            f"color:{theme.TEXT_SECONDARY}; font-size:12px;"
        )
        usage.body.addWidget(self.usage_count)
        self.usage_hint = QLabel("登录后可查看个人修改记录")
        self.usage_hint.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:11px;")
        self.usage_hint.setWordWrap(True)
        usage.body.addWidget(self.usage_hint)
        usage.body.addStretch()
        self.records_btn = make_button("查看修改记录", "subtle", height=30)
        self.records_btn.clicked.connect(self._open_profile)
        self.records_btn.setVisible(False)
        usage.body.addWidget(self.records_btn)
        column.addWidget(usage)

        workflow = Card(padding=18, spacing=10)
        workflow.body.addWidget(SectionTitle("工作流程", 15))
        steps = [
            ("1", "选择图片", "点击选择或拖拽图片，支持多张批量"),
            ("2", "参数渲染", "光影、色彩、细节、投影与局部区域可调"),
            ("3", "预览下载", "单张预览；批量完成后查看汇总"),
        ]
        for number, title_text, desc in steps:
            row = QHBoxLayout()
            row.setSpacing(10)
            badge = QLabel(number)
            badge.setFixedSize(24, 24)
            badge.setAlignment(Qt.AlignCenter)
            badge.setStyleSheet(
                f"background:{theme.PRIMARY_SOFT}; color:{theme.PRIMARY}; "
                "border-radius:12px; font-size:11px; font-weight:700;"
            )
            row.addWidget(badge, 0, Qt.AlignTop)
            text = QVBoxLayout()
            text.setSpacing(0)
            step_title = QLabel(title_text)
            step_title.setStyleSheet(
                f"color:{theme.TEXT}; font-size:13px; font-weight:600;"
            )
            step_desc = QLabel(desc)
            step_desc.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:11px;")
            step_desc.setWordWrap(True)
            text.addWidget(step_title)
            text.addWidget(step_desc)
            row.addLayout(text, 1)
            workflow.body.addLayout(row)
        workflow.body.addSpacing(2)
        workflow.body.addWidget(HLine())
        note = QLabel("图片只在本机处理，不会上传到服务器")
        note.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:10px;")
        workflow.body.addWidget(note)
        workflow.body.addStretch()
        column.addWidget(workflow, 1)
        return column

    # ---------- 登录状态 ----------
    def _apply_logged_out(self):
        self.login_btn.setVisible(True)
        self.welcome_label.setVisible(False)
        self.profile_btn.setVisible(False)
        self.logout_btn.setVisible(False)
        self.records_btn.setVisible(False)
        self.usage_name.setText("未登录")
        self.usage_count.setText("累计修改 0 次")
        self.usage_hint.setText("登录后可查看个人修改记录")
        self.status_label.setText("请先登录，账号由管理员统一开通")

    def _apply_logged_in(self):
        self.login_btn.setVisible(False)
        self.welcome_label.setText(f"欢迎，{self.session.user_name}")
        self.welcome_label.setVisible(True)
        self.profile_btn.setVisible(True)
        self.logout_btn.setVisible(True)
        self.records_btn.setVisible(True)
        self._refresh_usage()
        self.status_label.setText(
            f"已登录：{self.session.user_name}，选择图片开始精修（支持批量）"
        )
        show_toast(self, f"欢迎回来，{self.session.user_name}", "success")

    def _refresh_usage(self):
        if not self.session.is_logged_in():
            return
        state = _account_state(self.session.user_id)
        if state == "deleted":
            self._force_logout("账号已被删除，请联系管理员")
            return
        if state == "disabled":
            self._force_logout("账号已停用，请联系管理员")
            return
        summary = repo.get_user_summary(self.session.user_id)
        if not summary:
            self._force_logout("账号已被删除，请联系管理员")
            return
        self.usage_name.setText(summary["name"])
        self.usage_count.setText(f"累计修改 {summary['modify_count']} 次")
        self.usage_hint.setText(
            f"最近修改：{summary['last_modified_at'] or '暂无记录'}"
            f" · 开通于 {(summary['created_at'] or '')[:10]}"
        )

    def _force_logout(self, message):
        for dialog in self.findChildren(QDialog):
            if dialog.isVisible():
                try:
                    dialog.close()
                except RuntimeError:
                    pass
        self.session.logout()
        self._apply_logged_out()
        QMessageBox.warning(self, "账号状态变更", message)

    # ---------- 渲染参数 ----------
    def _update_params_summary(self):
        text = render_params.summary(self.render_settings)
        self.params_summary_label.setText(f"当前参数：{text}")
        self.params_summary_label.setToolTip(text)

    def _preview_source(self):
        if self._last_input and os.path.isfile(self._last_input):
            return self._last_input
        if self.session.is_logged_in():
            rows, _ = repo.page_user_modifications(
                self.session.user_id, "", 1, 1
            )
            if rows and os.path.isfile(rows[0]["image_path"]):
                return rows[0]["image_path"]
        return None

    def _open_render_settings(self):
        dialog = RenderDialog(
            self.render_settings, self._preview_source(), self
        )
        if dialog.exec_() == QDialog.Accepted:
            self.render_settings = dialog.params
            self.settings.setValue(
                "render/params", render_params.dump_json(self.render_settings)
            )
            self._update_params_summary()
            show_toast(self, "渲染参数已更新")

    # ---------- 登录 / 个人中心 ----------
    def _open_login(self):
        if self.session.is_logged_in():
            return
        dialog = LoginDialog(self)
        if dialog.exec_() == QDialog.Accepted and dialog.user:
            self.session.set_user(dialog.user)
            self._apply_logged_in()

    def _require_login(self):
        if self.session.is_logged_in():
            return True
        self._open_login()
        return self.session.is_logged_in()

    def _check_account(self):
        if not self.session.is_logged_in():
            return False
        state = _account_state(self.session.user_id)
        if state == "deleted":
            self._force_logout("账号已被删除，请联系管理员")
            return False
        if state == "disabled":
            self._force_logout("账号已停用，请联系管理员")
            return False
        return True

    def _periodic_state_check(self):
        if not self.session.is_logged_in():
            return
        if self.worker is not None and self.worker.isRunning():
            return
        state = _account_state(self.session.user_id)
        if state == "deleted":
            self._force_logout("账号已被删除，请联系管理员")
        elif state == "disabled":
            self._force_logout("账号已停用，请联系管理员")

    def _open_profile(self):
        if not self._require_login():
            return
        if not self._check_account():
            return

        dialog = QDialog(self)
        dialog.setWindowTitle(f"个人中心 - {APP_NAME}")
        fit_scaled(dialog, 1000, 760, 900, 660)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(0, 0, 0, 0)
        page = ProfilePage(
            self.session.user_id,
            on_close=dialog.close,
            on_logout=lambda: self._logout(confirm=False),
        )
        layout.addWidget(page)
        center_on_parent(dialog)
        dialog.exec_()
        if self.session.is_logged_in():
            self._refresh_usage()

    def _logout(self, confirm=True):
        if not self.session.is_logged_in():
            return
        if confirm:
            reply = QMessageBox.question(
                self, "退出登录", "确定要退出当前账号吗？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
        audit.record("退出登录", self.session.user_name, "user", self.session.user_name)
        self.session.logout()
        self._apply_logged_out()
        show_toast(self, "已退出登录", "info")

    # ---------- 图片校验与生成 ----------
    @staticmethod
    def _validate_image(path):
        ext = os.path.splitext(path)[1].lower()
        if ext not in SUPPORTED_IMAGE_EXTS:
            return "仅支持 JPG / PNG / BMP / WEBP 格式的图片。"
        try:
            size = os.path.getsize(path)
        except OSError:
            return "无法读取该文件，请检查文件是否存在。"
        if size > MAX_IMAGE_MB * 1024 * 1024:
            return f"图片大小超过 {MAX_IMAGE_MB}MB，请压缩后再试。"
        if not is_readable_image(path):
            return "无法识别该图片，文件可能已损坏。"
        info = image_info(path)
        if not info:
            return "无法读取图片信息，请更换图片后重试。"
        if info["width"] * info["height"] > MAX_IMAGE_PIXELS:
            return (
                f"图片像素超过 {MAX_IMAGE_PIXELS // 1_000_000}MP，"
                "请压缩或缩小后再试。"
            )
        return None

    def _on_generate(self):
        if not self._require_login():
            return
        if not self._check_account():
            return
        paths, _ = QFileDialog.getOpenFileNames(
            self, "选择图片（可多选）", "", SUPPORTED_IMAGE_FILTER
        )
        if paths:
            self._start_batch(paths)

    def _start_batch(self, paths):
        if not self._require_login() or not self._check_account():
            return
        if self.worker is not None and self.worker.isRunning():
            show_toast(self, "正在处理图片，请稍候", "info")
            return

        unique = []
        seen = set()
        for path in paths:
            absolute = os.path.abspath(path)
            if absolute not in seen:
                seen.add(absolute)
                unique.append(absolute)

        valid = []
        skipped = 0
        first_error = ""
        for path in unique:
            error = self._validate_image(path)
            if error:
                skipped += 1
                if not first_error:
                    first_error = f"{os.path.basename(path)}：{error}"
            else:
                valid.append(path)
        if not valid:
            QMessageBox.warning(
                self, "图片不可用", first_error or "没有可处理的图片。"
            )
            return

        params = dict(self.render_settings)
        if params.get("local") and params.get("regions"):
            dialog = RenderDialog(
                params, valid[0], self, allow_change_preview=False
            )
            if dialog.exec_() != QDialog.Accepted:
                return
            params = dict(dialog.params)
            self.render_settings = params
            self.settings.setValue(
                "render/params", render_params.dump_json(params)
            )
            self._update_params_summary()
            if not self._check_account():
                return

        reserved = set()
        jobs = []
        for path in valid:
            output = self._output_path(path, reserved)
            reserved.add(output)
            jobs.append((path, output))

        self._batch_total = len(jobs)
        self._batch_results = []
        self._batch_skipped = skipped
        self._batch_params = params
        self._batch_account_lost = None

        self.progress_dialog = BatchProgressDialog(len(jobs), self)
        self.progress_dialog.cancelRequested.connect(self._cancel_batch)
        self.progress_dialog.show()

        self.worker = BatchRenderWorker(
            jobs, params, self.session.user_id, self
        )
        self.worker.job_started.connect(self._on_job_started)
        self.worker.job_progress.connect(self._on_job_progress)
        self.worker.job_finished.connect(self._on_job_finished)
        self.worker.account_lost.connect(self._on_account_lost)
        self.worker.all_done.connect(self._on_all_done)
        self.worker.finished.connect(self._on_worker_finished)
        self.worker.start()

        if skipped:
            show_toast(self, f"已跳过 {skipped} 张不可用图片", "info")
        if len(jobs) > 1:
            self.status_label.setText(f"正在批量处理 {len(jobs)} 张图片…")
        else:
            self.status_label.setText("正在生成效果图…")

    def _on_job_started(self, index, total, name):
        if self.progress_dialog is not None:
            self.progress_dialog.set_current(index, total, name)

    def _on_job_progress(self, percent, stage):
        if self.progress_dialog is not None:
            self.progress_dialog.set_stage(percent, stage)

    def _on_account_lost(self, state):
        self._batch_account_lost = state
        if self.progress_dialog is not None:
            self.progress_dialog.hint.setText("账号状态已变更，正在停止处理…")

    def _on_job_finished(self, index, success, input_path, output_path):
        if success:
            state = (
                _account_state(self.session.user_id)
                if self.session.is_logged_in() else "deleted"
            )
            failure_reason = None
            if state == "deleted":
                failure_reason = "账号已删除，修改记录未保存"
            else:
                try:
                    repo.add_modification(
                        self.session.user_id, input_path, output_path,
                        render_params.dump_json(self._batch_params),
                    )
                except Exception:
                    get_logger().exception("保存修改记录失败")
                    failure_reason = "修改记录保存失败"

            if failure_reason:
                success = False
                get_logger().warning(
                    "渲染成功但记录未保存：%s（%s）", input_path, failure_reason
                )
                audit.record(
                    "生成失败", self.session.user_name or "未知", "user",
                    os.path.basename(input_path), failure_reason,
                )
            else:
                info = image_info(input_path)
                detail = render_params.summary(self._batch_params)
                if info:
                    detail = (
                        f"{info['width']}×{info['height']} · "
                        f"{human_size(info['bytes'])} · {detail}"
                    )
                audit.record(
                    "生成图片", self.session.user_name, "user",
                    os.path.basename(output_path), detail,
                )
                self._last_input = input_path
        else:
            get_logger().warning("渲染失败：%s", input_path)
            audit.record(
                "生成失败", self.session.user_name or "未知", "user",
                os.path.basename(input_path), "图片处理失败",
            )
        self._batch_results.append({
            "success": success,
            "input": input_path,
            "output": output_path,
            "name": os.path.basename(input_path),
        })
        if self.progress_dialog is not None:
            self.progress_dialog.bar.setValue((index + 1) * 100)

    def _on_all_done(self, canceled):
        if self.progress_dialog is not None:
            self.progress_dialog.finish()
            self.progress_dialog.deleteLater()
            self.progress_dialog = None

        results = list(self._batch_results)
        success = [r for r in results if r["success"]]
        failed = [r for r in results if not r["success"]]
        processed = len(results)
        total = self._batch_total
        skipped = self._batch_skipped

        state = self._batch_account_lost
        if state not in ("disabled", "deleted") and self.session.is_logged_in():
            state = _account_state(self.session.user_id)
        if state == "ok":
            state = None
        lost = state in ("disabled", "deleted")

        if not lost:
            self._refresh_usage()

        if (total == 1 and skipped == 0 and not canceled and not lost
                and len(success) == 1):
            output = success[0]["output"]
            input_path = success[0]["input"]
            self.status_label.setText(f"已生成：{os.path.basename(output)}")
            show_toast(self, f"已生成：{os.path.basename(output)}")
            preview = ImagePreviewDialog(output, input_path, self)
            preview.exec_()
            self._batch_results = []
            self._batch_account_lost = None
            return

        if total > 1 or skipped or canceled or lost:
            detail = (
                f"成功 {len(success)} / 失败 {len(failed)} / 跳过 {skipped}"
            )
            if canceled:
                detail += " / 已取消"
            if state == "disabled":
                detail += " / 账号已停用，处理已停止"
            elif state == "deleted":
                detail += " / 账号已删除，处理已停止"
            audit.record(
                "批量处理", self.session.user_name or "未知", "user",
                f"{total} 张", detail,
            )

        if lost:
            title = "处理已停止"
            action = "停用" if state == "disabled" else "删除"
            text = (
                f"账号已{action}，批量处理已停止。"
                f"已完成 {processed}/{total} 张。"
            )
            if success:
                if state == "deleted":
                    text += (
                        f"\n已生成 {len(success)} 张效果图文件，"
                        "账号删除后修改记录已清除。"
                    )
                else:
                    text += f"\n已保存 {len(success)} 张效果图记录。"
            if failed:
                text += f"\n未保存 {len(failed)} 张（效果图文件可能已生成）。"
        elif canceled:
            title = "已取消"
            text = f"已取消批量处理，完成 {processed}/{total} 张。"
        elif failed:
            title = "处理完成（部分失败）"
            text = f"批量处理完成：成功 {len(success)} 张，失败 {len(failed)} 张。"
        else:
            title = "处理完成"
            text = f"批量处理完成：成功 {len(success)} 张。"
        if skipped:
            text += f"\n跳过 {skipped} 张不可用图片。"
        if failed:
            text += "\n失败文件：" + "、".join(r["name"] for r in failed[:5])
            if len(failed) > 5:
                text += " 等"

        box = QMessageBox(self)
        box.setTextFormat(Qt.PlainText)
        box.setIcon(QMessageBox.Warning if failed else QMessageBox.Information)
        box.setWindowTitle(title)
        box.setText(text)
        box.setInformativeText(
            "账号状态已变更，将退出登录。" if lost
            else "输出已保存在各自原图所在目录。"
        )
        open_btn = None
        if success and not lost:
            open_btn = box.addButton("打开输出文件夹", QMessageBox.ActionRole)
        box.addButton("关闭", QMessageBox.AcceptRole)
        box.exec_()
        if open_btn is not None and box.clickedButton() is open_btn:
            QDesktopServices.openUrl(
                QUrl.fromLocalFile(os.path.dirname(success[0]["output"]))
            )
        if lost:
            action = "停用" if state == "disabled" else "删除"
            self.session.logout()
            self._apply_logged_out()
            self.status_label.setText(f"账号已{action}，已退出登录")
        elif canceled:
            self.status_label.setText(
                f"已取消批量处理，完成 {len(success)}/{total} 张"
            )
        elif success:
            show_toast(self, f"批量处理完成：成功 {len(success)} 张")
            self.status_label.setText(
                f"批量处理完成：成功 {len(success)} 张，失败 {len(failed)} 张"
            )
        else:
            self.status_label.setText("处理失败，请检查图片或稍后重试")
        self._batch_results = []
        self._batch_account_lost = None

    def _cancel_batch(self):
        if self.worker is not None:
            self.worker.cancel()

    def _on_worker_finished(self):
        if self.worker is not None:
            self.worker.deleteLater()
            self.worker = None

    @staticmethod
    def _output_path(input_path, reserved=None):
        reserved = reserved or set()
        directory = os.path.dirname(input_path)
        base = os.path.splitext(os.path.basename(input_path))[0]
        output = os.path.join(directory, f"{base}_精修.png")
        if not os.path.exists(output) and output not in reserved:
            return output
        index = 1
        while True:
            output = os.path.join(directory, f"{base}_精修_{index}.png")
            if not os.path.exists(output) and output not in reserved:
                return output
            index += 1

    # ---------- 拖拽 ----------
    @staticmethod
    def _is_supported_file(path):
        if not path or not os.path.isfile(path):
            return False
        return os.path.splitext(path)[1].lower() in SUPPORTED_IMAGE_EXTS

    def _set_drag_active(self, active, count=1):
        if active:
            self.drop_zone.setStyleSheet(
                "QFrame#dropZone{background:#FFF3E8; border:2px solid #C55A11; "
                "border-radius:14px;}"
            )
            if count > 1:
                self.zone_title.setText(f"松开鼠标，批量处理 {count} 张图片")
            else:
                self.zone_title.setText("松开鼠标，开始生成")
        else:
            self.drop_zone.setStyleSheet("")
            self.zone_title.setText("点击选择或拖拽图片（可多张）")

    def dragEnterEvent(self, event):
        paths = [
            url.toLocalFile() for url in event.mimeData().urls()
            if self._is_supported_file(url.toLocalFile())
        ]
        if paths:
            event.acceptProposedAction()
            self._set_drag_active(True, len(paths))
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dragLeaveEvent(self, event):
        self._set_drag_active(False)
        super().dragLeaveEvent(event)

    def dropEvent(self, event):
        self._set_drag_active(False)
        paths = [
            url.toLocalFile() for url in event.mimeData().urls()
            if self._is_supported_file(url.toLocalFile())
        ]
        if paths:
            event.acceptProposedAction()
            self._start_batch(paths)
        else:
            event.ignore()

    # ---------- 窗口状态 ----------
    def _restore_geometry(self):
        geometry = self.settings.value("main/geometry_v24")
        if geometry:
            self.restoreGeometry(geometry)

    def closeEvent(self, event):
        if self.worker is not None and self.worker.isRunning():
            show_toast(self, "正在生成效果图，请稍候", "info")
            event.ignore()
            return
        self._state_timer.stop()
        self.settings.setValue("main/geometry_v24", self.saveGeometry())
        super().closeEvent(event)


def main():
    setup_logging("main")
    install_excepthook(APP_NAME)

    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    app = QApplication(sys.argv)
    theme.apply_theme(app)
    icon_path = _resource_path(os.path.join("assets", "app.ico"))
    if os.path.exists(icon_path):
        app.setWindowIcon(QIcon(icon_path))

    if not init_db():
        QMessageBox.critical(
            None, "启动失败",
            "无法初始化本地数据库，请检查数据目录权限后重试。"
        )
        return 1

    window = MainWindow()
    window.show()
    return app.exec_()


if __name__ == "__main__":
    sys.exit(main())
