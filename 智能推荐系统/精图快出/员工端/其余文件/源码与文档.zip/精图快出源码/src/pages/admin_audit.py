﻿# pages/admin_audit.py
# 职责：管理员端操作日志（查询/筛选/导出）

import os
from datetime import datetime
from math import ceil

from PyQt5.QtWidgets import (
    QComboBox, QHBoxLayout, QLabel, QLineEdit, QStackedWidget,
    QTableWidgetItem, QVBoxLayout, QWidget
)

from core import audit
from core.config import PAGE_SIZE
from ui import theme
from ui.export import export_csv
from ui.widgets import (
    DataTable, EmptyState, PageHeader, PaginationBar, make_button
)


class AuditPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.search = ""
        self.action = ""
        self.page = 1
        self.total = 0
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 14, 18, 14)
        root.setSpacing(14)

        header = PageHeader(
            "操作日志", "记录账号、修改、导出与备份等关键操作，只读不可删除"
        )
        export_btn = make_button("导出日志", "ghost", height=36)
        export_btn.clicked.connect(self._export)
        header.add_action(export_btn)
        refresh_btn = make_button("刷新", "primary", height=36)
        refresh_btn.clicked.connect(self.refresh)
        header.add_action(refresh_btn)
        root.addWidget(header)

        toolbar = QHBoxLayout()
        toolbar.setSpacing(10)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("搜索操作人 / 对象 / 详情")
        self.search_edit.setFixedWidth(190)
        self.search_edit.textChanged.connect(self._on_search)
        toolbar.addWidget(self.search_edit)

        self.action_combo = QComboBox()
        self.action_combo.setFixedWidth(120)
        self.action_combo.currentIndexChanged.connect(self._on_action)
        toolbar.addWidget(self.action_combo)

        self.count_label = QLabel("共 0 条日志")
        self.count_label.setStyleSheet(
            f"color:{theme.TEXT_MUTED}; font-size:12px;"
        )
        toolbar.addWidget(self.count_label)
        toolbar.addStretch()
        layout_hint = QLabel("审计日志仅追加，不提供删除入口")
        layout_hint.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:11px;")
        toolbar.addWidget(layout_hint)
        root.addLayout(toolbar)

        self.stack = QStackedWidget()
        self.table = DataTable(
            ["时间", "操作人", "角色", "操作", "对象", "详情"], row_height=40
        )
        self.table.set_widths({0: 150, 1: 70, 2: 65, 3: 80, 4: 110})
        self.stack.addWidget(self.table)
        self.stack.addWidget(
            EmptyState("暂无操作日志", "管理员和员工的账号操作会记录在这里。", "▢")
        )
        root.addWidget(self.stack, 1)

        self.pagination = PaginationBar()
        self.pagination.page_changed.connect(self._on_page_changed)
        root.addWidget(self.pagination)

    def _on_search(self):
        self.search = self.search_edit.text().strip()
        self.page = 1
        self._load()

    def _on_action(self, index):
        self.action = "" if index <= 0 else self.action_combo.currentText()
        self.page = 1
        self._load()

    def _on_page_changed(self, page):
        self.page = page
        self._load()

    def _reload_actions(self):
        current = self.action
        actions = audit.distinct_actions()
        self.action_combo.blockSignals(True)
        self.action_combo.clear()
        self.action_combo.addItem("全部操作")
        for action in actions:
            self.action_combo.addItem(action)
        if current:
            index = self.action_combo.findText(current)
            if index >= 0:
                self.action_combo.setCurrentIndex(index)
            else:
                self.action = ""
                self.action_combo.setCurrentIndex(0)
        else:
            self.action_combo.setCurrentIndex(0)
        self.action_combo.blockSignals(False)

    def refresh(self):
        self._reload_actions()
        self._load()

    def _load(self):
        rows, total = audit.page_logs(self.search, self.action, self.page, PAGE_SIZE)
        pages = max(1, ceil(total / PAGE_SIZE))
        if self.page > pages:
            self.page = pages
            rows, total = audit.page_logs(
                self.search, self.action, self.page, PAGE_SIZE
            )
        self.total = total
        self.count_label.setText(f"共 {total} 条日志")
        self.pagination.set_state(self.page, total, PAGE_SIZE)
        self.table.setRowCount(0)
        if not rows:
            self.stack.setCurrentIndex(1)
            return

        self.stack.setCurrentIndex(0)
        for row_data in rows:
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(
                row, 0, QTableWidgetItem(row_data["created_at"] or "—")
            )
            self.table.setItem(
                row, 1, QTableWidgetItem(row_data["actor"] or "—")
            )
            self.table.setItem(
                row, 2, QTableWidgetItem(audit.role_label(row_data["role"]))
            )
            self.table.setItem(
                row, 3, QTableWidgetItem(row_data["action"] or "—")
            )
            self.table.setItem(
                row, 4, QTableWidgetItem(row_data["target"] or "—")
            )
            detail_item = QTableWidgetItem(row_data["detail"] or "")
            detail_item.setToolTip(row_data["detail"] or "")
            self.table.setItem(row, 5, detail_item)

    def _export(self):
        rows = audit.list_logs(self.search, self.action)
        data = [
            (
                item["created_at"],
                item["actor"],
                audit.role_label(item["role"]),
                item["action"],
                item["target"],
                item["detail"],
            )
            for item in rows
        ]
        path = export_csv(
            self,
            f"操作日志_{datetime.now():%Y%m%d}.csv",
            ["时间", "操作人", "角色", "操作", "对象", "详情"],
            data,
        )
        if path:
            audit.record(
                "导出日志", "管理员", "admin",
                os.path.basename(path), f"{len(data)} 条"
            )
