﻿# pages/admin_register.py
# 职责：管理员端注册账号

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import (
    QHBoxLayout, QLabel, QLineEdit, QTableWidgetItem,
    QVBoxLayout, QWidget
)

from core import auth, repo
from ui import theme
from ui.toast import show_toast
from ui.widgets import (
    Card, DataTable, PageHeader, SectionTitle, StatusChip, make_button
)


class RegisterPage(QWidget):
    def __init__(self, on_data_changed=None, parent=None):
        super().__init__(parent)
        self.on_data_changed = on_data_changed
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 14, 18, 14)
        root.setSpacing(16)

        header = PageHeader("注册账号", "为新员工开通主程序登录账号")
        refresh_btn = make_button("刷新", "ghost", height=36)
        refresh_btn.clicked.connect(self.refresh)
        header.add_action(refresh_btn)
        root.addWidget(header)

        top = QHBoxLayout()
        top.setSpacing(16)

        form = Card(padding=24, spacing=10)
        form.setFixedWidth(300)
        form.body.addWidget(SectionTitle("开通新账号", 17))
        sub = QLabel("只需填写姓名，初始密码统一为 12345678")
        sub.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:12px;")
        sub.setWordWrap(True)
        form.body.addWidget(sub)
        form.body.addSpacing(6)

        form.body.addWidget(self._field_label("姓名"))
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("请输入员工姓名")
        self.name_edit.setMaxLength(20)
        self.name_edit.textChanged.connect(lambda _: self._set_error(""))
        self.name_edit.returnPressed.connect(self._register)
        form.body.addWidget(self.name_edit)

        form.body.addWidget(self._field_label("初始密码"))
        pwd_edit = QLineEdit()
        pwd_edit.setText(auth.DEFAULT_PASSWORD)
        pwd_edit.setEnabled(False)
        pwd_edit.setToolTip("初始密码由系统统一设置，首次登录后强制修改")
        form.body.addWidget(pwd_edit)

        form.body.addSpacing(6)
        register_btn = make_button("注册账号", "primary", height=44)
        register_btn.clicked.connect(self._register)
        form.body.addWidget(register_btn)

        self.error_label = QLabel("")
        self.error_label.setTextFormat(Qt.PlainText)
        self.error_label.setWordWrap(True)
        self.error_label.setStyleSheet(f"color:{theme.DANGER}; font-size:12px;")
        self.error_label.setVisible(False)
        form.body.addWidget(self.error_label)

        self.notice = QLabel("")
        self.notice.setTextFormat(Qt.PlainText)
        self.notice.setWordWrap(True)
        self.notice.setStyleSheet(f"color:{theme.SUCCESS}; font-size:12px;")
        self.notice.setVisible(False)
        form.body.addWidget(self.notice)
        form.body.addStretch()
        top.addWidget(form)

        guide = Card(padding=24, spacing=12)
        guide.body.addWidget(SectionTitle("开通说明", 17))
        steps = [
            ("1", "管理员注册姓名", "信息实时写入共享数据库"),
            ("2", "员工首次登录", "使用姓名 + 初始密码 12345678"),
            ("3", "首次登录改密", "必须设置新的字母 + 数字密码"),
        ]
        for number, title, desc in steps:
            row = QHBoxLayout()
            row.setSpacing(12)
            badge = QLabel(number)
            badge.setFixedSize(26, 26)
            badge.setAlignment(Qt.AlignCenter)
            badge.setStyleSheet(
                f"background:{theme.PRIMARY_SOFT}; color:{theme.PRIMARY}; "
                "border-radius:13px; font-size:12px; font-weight:700;"
            )
            row.addWidget(badge, 0, Qt.AlignTop)
            text = QVBoxLayout()
            text.setSpacing(2)
            title_label = QLabel(title)
            title_label.setStyleSheet(
                f"color:{theme.TEXT}; font-size:14px; font-weight:600;"
            )
            desc_label = QLabel(desc)
            desc_label.setStyleSheet(
                f"color:{theme.TEXT_SECONDARY}; font-size:12px;"
            )
            text.addWidget(title_label)
            text.addWidget(desc_label)
            row.addLayout(text, 1)
            guide.body.addLayout(row)

        guide.body.addStretch()
        note = Card(padding=14, spacing=4)
        note.setStyleSheet(
            f"QFrame#card{{background:{theme.WARNING_SOFT}; "
            "border:1px solid #F0DFC0; border-radius:10px;}"
        )
        note_text = QLabel("未在此注册的姓名无法登录主程序，也不会出现在员工管理中。")
        note_text.setWordWrap(True)
        note_text.setStyleSheet(f"color:{theme.WARNING}; font-size:12px;")
        note.body.addWidget(note_text)
        guide.body.addWidget(note)
        top.addWidget(guide, 1)
        root.addLayout(top, 2)

        recent = Card(padding=20, spacing=10)
        recent_head = QHBoxLayout()
        recent_head.addWidget(SectionTitle("最近开通", 16))
        recent_head.addStretch()
        self.recent_count = QLabel("")
        self.recent_count.setStyleSheet(
            f"color:{theme.TEXT_MUTED}; font-size:12px;"
        )
        recent_head.addWidget(self.recent_count)
        recent.body.addLayout(recent_head)

        self.table = DataTable(["姓名", "状态", "密码状态", "开通时间"], row_height=44)
        self.table.set_widths({1: 110, 2: 130})
        recent.body.addWidget(self.table, 1)
        root.addWidget(recent, 3)

    @staticmethod
    def _field_label(text):
        label = QLabel(text)
        label.setStyleSheet(
            f"color:{theme.TEXT_SECONDARY}; font-size:12px; font-weight:600;"
        )
        return label

    # ---------- 交互 ----------
    def _set_error(self, message):
        self.error_label.setText(message)
        self.error_label.setVisible(bool(message))

    def _register(self):
        self._set_error("")
        self.notice.setVisible(False)
        name = self.name_edit.text().strip()
        if not name:
            self._set_error("请填写要开通的员工姓名。")
            return
        ok, msg = auth.create_account(name)
        if not ok:
            self._set_error(msg)
            return
        self.name_edit.clear()
        self.name_edit.setFocus()
        self.notice.setText(
            f"已开通「{name}」，初始密码 {auth.DEFAULT_PASSWORD}，"
            "请通知员工首次登录后重置密码。"
        )
        self.notice.setVisible(True)
        show_toast(self, f"已开通「{name}」")
        self.refresh()
        if self.on_data_changed:
            self.on_data_changed()

    def refresh(self):
        rows = repo.list_recent_users(10)
        self.table.setRowCount(0)
        for row_data in rows:
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(row_data["name"]))

            status_cell = QWidget()
            status_layout = QHBoxLayout(status_cell)
            status_layout.setContentsMargins(4, 0, 4, 0)
            chip = StatusChip(
                "success" if row_data["is_active"] else "danger",
                "正常" if row_data["is_active"] else "已停用",
            )
            status_layout.addWidget(chip)
            status_layout.addStretch()
            self.table.setCellWidget(row, 1, status_cell)

            pwd_text = "待首次改密" if row_data["must_reset"] else "已改密"
            pwd_item = QTableWidgetItem(pwd_text)
            pwd_item.setForeground(
                QColor(theme.WARNING if row_data["must_reset"] else theme.SUCCESS)
            )
            self.table.setItem(row, 2, pwd_item)
            self.table.setItem(row, 3, QTableWidgetItem(row_data["created_at"] or "—"))

        self.recent_count.setText(f"共 {len(rows)} 条")
