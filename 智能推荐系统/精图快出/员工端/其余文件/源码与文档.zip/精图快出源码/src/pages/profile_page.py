# pages/profile_page.py
# 职责：个人中心（修改记录分页/搜索/导出 + 账号设置）

import os
from datetime import datetime
from math import ceil

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFontMetrics
from PyQt5.QtWidgets import (
    QAbstractItemView, QButtonGroup, QFrame, QHBoxLayout, QHeaderView,
    QLabel, QLineEdit, QMessageBox, QPushButton, QScrollArea, QStackedWidget,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget
)

from core import audit, auth, render_params, repo
from core.config import PAGE_SIZE
from ui import theme
from ui.export import export_csv
from ui.imageutils import image_info, info_text, thumbnail_pixmap
from ui.preview import ImagePreviewDialog, save_image_as
from ui.toast import show_toast
from ui.widgets import (
    Avatar, Card, ClickableLabel, EmptyState, HLine, PaginationBar,
    PasswordStrengthBar, SectionTitle, StatusChip, make_button
)


class ProfilePage(QWidget):
    """个人中心：修改记录、账号设置。"""

    def __init__(self, user_id, on_close=None, on_logout=None, parent=None):
        super().__init__(parent)
        self.user_id = user_id
        self.on_close = on_close
        self.on_logout = on_logout
        self.summary = None
        self.records_page = 1
        self.records_search = ""
        self.records_total = 0
        self._build_ui()
        self.refresh()

    # ---------- 界面 ----------
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        header = QFrame()
        header.setObjectName("headerBar")
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(18, 12, 18, 12)
        header_layout.setSpacing(14)

        self.avatar = Avatar("?", 46)
        header_layout.addWidget(self.avatar)

        info = QVBoxLayout()
        info.setSpacing(2)
        name_row = QHBoxLayout()
        name_row.setSpacing(10)
        self.name_label = QLabel("—")
        self.name_label.setTextFormat(Qt.PlainText)
        self.name_label.setStyleSheet(
            f"font-size:16px; font-weight:700; color:{theme.TEXT};"
        )
        name_row.addWidget(self.name_label)
        self.status_chip = StatusChip("success")
        name_row.addWidget(self.status_chip)
        name_row.addStretch()
        info.addLayout(name_row)
        self.meta_label = QLabel("")
        self.meta_label.setStyleSheet(
            f"color:{theme.TEXT_SECONDARY}; font-size:10px;"
        )
        info.addWidget(self.meta_label)
        header_layout.addLayout(info, 1)

        close_btn = make_button("关闭", "ghost", height=30)
        close_btn.clicked.connect(self._close)
        header_layout.addWidget(close_btn)
        root.addWidget(header)

        tab_bar = QFrame()
        tab_bar.setStyleSheet(
            f"QFrame{{background:#FFFFFF; border:none; "
            f"border-bottom:1px solid {theme.BORDER};}}"
        )
        tab_layout = QHBoxLayout(tab_bar)
        tab_layout.setContentsMargins(18, 0, 18, 0)
        tab_layout.setSpacing(26)
        self.tab_records = QPushButton("修改记录")
        self.tab_records.setObjectName("tabButton")
        self.tab_records.setCheckable(True)
        self.tab_records.setChecked(True)
        self.tab_settings = QPushButton("账号设置")
        self.tab_settings.setObjectName("tabButton")
        self.tab_settings.setCheckable(True)
        group = QButtonGroup(self)
        group.setExclusive(True)
        group.addButton(self.tab_records, 0)
        group.addButton(self.tab_settings, 1)
        group.buttonClicked[int].connect(self._switch_tab)
        tab_layout.addWidget(self.tab_records)
        tab_layout.addWidget(self.tab_settings)
        tab_layout.addStretch()
        root.addWidget(tab_bar)

        self.stack = QStackedWidget()
        self.stack.addWidget(self._build_records_page())
        self.stack.addWidget(self._build_settings_page())
        root.addWidget(self.stack, 1)

    def _build_records_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(8)

        toolbar = QHBoxLayout()
        toolbar.setSpacing(10)
        self.count_label = QLabel("共 0 条修改记录")
        self.count_label.setStyleSheet(
            f"color:{theme.TEXT}; font-size:14px; font-weight:600;"
        )
        toolbar.addWidget(self.count_label)
        hint = QLabel("点击缩略图可预览")
        hint.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:10px;")
        toolbar.addWidget(hint)
        toolbar.addStretch()

        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("搜索文件名")
        self.search_edit.setFixedWidth(130)
        self.search_edit.textChanged.connect(self._on_search)
        toolbar.addWidget(self.search_edit)

        export_btn = make_button("导出记录", "ghost", height=28)
        export_btn.clicked.connect(self._export_records)
        toolbar.addWidget(export_btn)

        refresh_btn = make_button("刷新", "ghost", height=28)
        refresh_btn.clicked.connect(self.refresh)
        toolbar.addWidget(refresh_btn)
        layout.addLayout(toolbar)

        self.records_stack = QStackedWidget()

        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["修改时间", "修改图片", "操作"])
        self.table.setShowGrid(False)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionMode(QAbstractItemView.NoSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setFocusPolicy(Qt.NoFocus)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(82)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        header.setSectionResizeMode(1, QHeaderView.Fixed)
        header.setSectionResizeMode(2, QHeaderView.Fixed)
        header.setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.table.setColumnWidth(1, 280)
        self.table.setColumnWidth(2, 150)
        self.records_stack.addWidget(self.table)

        empty = EmptyState(
            "还没有修改记录", "选择图片并生成效果图后，记录会显示在这里。", "▢"
        )
        self.records_stack.addWidget(empty)
        layout.addWidget(self.records_stack, 1)

        self.pagination = PaginationBar()
        self.pagination.page_changed.connect(self._on_page_changed)
        layout.addWidget(self.pagination)
        return page

    def _build_settings_page(self):
        page = QWidget()
        layout = QHBoxLayout(page)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(14)

        account = Card(padding=18, spacing=8)
        account.setFixedWidth(240)
        account.body.addWidget(SectionTitle("账号信息", 15))

        top = QHBoxLayout()
        top.setSpacing(12)
        self.settings_avatar = Avatar("?", 42)
        top.addWidget(self.settings_avatar, 0, Qt.AlignTop)
        name_box = QVBoxLayout()
        name_box.setSpacing(2)
        self.settings_name = QLabel("—")
        self.settings_name.setTextFormat(Qt.PlainText)
        self.settings_name.setStyleSheet(
            f"font-size:16px; font-weight:700; color:{theme.TEXT};"
        )
        name_box.addWidget(self.settings_name)
        self.settings_chip = StatusChip("success")
        name_box.addWidget(self.settings_chip)
        top.addLayout(name_box)
        top.addStretch()
        account.body.addLayout(top)
        account.body.addWidget(HLine())
        self.info_created = self._info_row("开通时间")
        self.info_count = self._info_row("累计修改")
        self.info_last = self._info_row("最近修改")
        account.body.addWidget(self.info_created)
        account.body.addWidget(self.info_count)
        account.body.addWidget(self.info_last)
        account.body.addStretch()

        logout_btn = make_button("退出登录", "danger", height=32)
        logout_btn.clicked.connect(self._logout)
        account.body.addWidget(logout_btn)
        layout.addWidget(account)

        password = Card(padding=18, spacing=6)
        password.body.addWidget(SectionTitle("修改密码", 15))
        sub = QLabel("新密码需至少 8 位，并同时包含字母和数字")
        sub.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:11px;")
        password.body.addWidget(sub)
        password.body.addSpacing(2)

        password.body.addWidget(self._field_label("当前密码"))
        self.old_pwd = QLineEdit()
        self.old_pwd.setEchoMode(QLineEdit.Password)
        self.old_pwd.setPlaceholderText("请输入当前密码")
        password.body.addWidget(self.old_pwd)

        password.body.addWidget(self._field_label("新密码"))
        self.new_pwd = QLineEdit()
        self.new_pwd.setEchoMode(QLineEdit.Password)
        self.new_pwd.setPlaceholderText("字母 + 数字，至少 8 位")
        self.new_pwd.textChanged.connect(self._on_new_password_changed)
        password.body.addWidget(self.new_pwd)

        self.pwd_strength = PasswordStrengthBar()
        password.body.addWidget(self.pwd_strength)

        password.body.addWidget(self._field_label("确认新密码"))
        self.confirm_pwd = QLineEdit()
        self.confirm_pwd.setEchoMode(QLineEdit.Password)
        self.confirm_pwd.setPlaceholderText("请再次输入新密码")
        self.confirm_pwd.returnPressed.connect(self._change_password)
        password.body.addWidget(self.confirm_pwd)

        self.pwd_error = QLabel("")
        self.pwd_error.setWordWrap(True)
        self.pwd_error.setStyleSheet(f"color:{theme.DANGER}; font-size:12px;")
        self.pwd_error.setVisible(False)
        password.body.addWidget(self.pwd_error)

        password.body.addSpacing(4)
        submit = make_button("确认修改", "primary", height=38)
        submit.clicked.connect(self._change_password)
        password.body.addWidget(submit)
        password.body.addStretch()
        layout.addWidget(password, 1)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet(
            "QScrollArea{background:transparent; border:none;} "
            "QScrollArea > QWidget > QWidget{background:transparent;}"
        )
        scroll.setWidget(page)
        return scroll

    @staticmethod
    def _field_label(text):
        label = QLabel(text)
        label.setStyleSheet(
            f"color:{theme.TEXT_SECONDARY}; font-size:11px; font-weight:600;"
        )
        return label

    @staticmethod
    def _info_row(title):
        row = QWidget()
        layout = QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        key = QLabel(title)
        key.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:11px;")
        value = QLabel("—")
        value.setStyleSheet(f"color:{theme.TEXT}; font-size:12px; font-weight:600;")
        value.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        layout.addWidget(key)
        layout.addStretch()
        layout.addWidget(value)
        return row

    @staticmethod
    def _set_info_value(row, text):
        labels = row.findChildren(QLabel)
        if labels:
            labels[-1].setText(text)

    # ---------- 数据 ----------
    def _switch_tab(self, index):
        self.stack.setCurrentIndex(index)
        self.tab_records.setChecked(index == 0)
        self.tab_settings.setChecked(index == 1)

    def refresh(self):
        self.summary = repo.get_user_summary(self.user_id)
        if not self.summary:
            self.name_label.setText("账号不存在")
            self.meta_label.setText("该账号可能已被管理员删除")
            self.status_chip.setVisible(False)
            self._fill_account_info()
            self._render_records([], 0)
            return

        name = self.summary["name"]
        self.name_label.setText(name)
        self.avatar.setText(name[:1] if name else "?")
        self.settings_avatar.setText(name[:1] if name else "?")
        self.settings_name.setText(name)
        self.meta_label.setText(
            f"累计修改 {self.summary['modify_count']} 次 · "
            f"开通于 {(self.summary['created_at'] or '')[:10]}"
        )
        active = bool(self.summary["is_active"])
        for chip in (self.status_chip, self.settings_chip):
            chip.setText("正常" if active else "已停用")
            chip.setStyleSheet(
                f"background:{theme.SUCCESS_SOFT if active else theme.DANGER_SOFT}; "
                f"color:{theme.SUCCESS if active else theme.DANGER}; border-radius:9px; "
                "padding:3px 10px; font-size:12px; font-weight:600;"
            )
        self._fill_account_info()
        self._load_records()

    def _fill_account_info(self):
        if not self.summary:
            self._set_info_value(self.info_created, "—")
            self._set_info_value(self.info_count, "0 次")
            self._set_info_value(self.info_last, "—")
            return
        self._set_info_value(
            self.info_created, (self.summary["created_at"] or "—")[:10]
        )
        self._set_info_value(self.info_count, f"{self.summary['modify_count']} 次")
        self._set_info_value(
            self.info_last, self.summary["last_modified_at"] or "暂无记录"
        )

    def _load_records(self):
        rows, total = repo.page_user_modifications(
            self.user_id, self.records_search, self.records_page, PAGE_SIZE
        )
        pages = max(1, ceil(total / PAGE_SIZE))
        if self.records_page > pages:
            self.records_page = pages
            rows, total = repo.page_user_modifications(
                self.user_id, self.records_search, self.records_page, PAGE_SIZE
            )
        self._render_records(rows, total)

    def _render_records(self, rows, total):
        self.records_total = total
        self.count_label.setText(f"共 {total} 条修改记录")
        self.table.setRowCount(0)
        self.pagination.set_state(self.records_page, total, PAGE_SIZE)
        if not rows:
            self.records_stack.setCurrentIndex(1)
            return

        self.records_stack.setCurrentIndex(0)
        for record in rows:
            row = self.table.rowCount()
            self.table.insertRow(row)

            time_item = QTableWidgetItem(record["created_at"])
            time_item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            self.table.setItem(row, 0, time_item)
            self.table.setCellWidget(
                row, 1,
                self._image_cell(
                    record["image_path"],
                    record["original_path"],
                    render_params.summary(
                        render_params.load_json(record.get("params"))
                    ),
                )
            )
            self.table.setCellWidget(row, 2, self._actions_cell(record))

    def _image_cell(self, image_path, original_path, params_text=""):
        cell = QWidget()
        layout = QHBoxLayout(cell)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(10)

        thumb = ClickableLabel()
        thumb.setFixedSize(116, 66)
        thumb.setCursor(Qt.PointingHandCursor)
        thumb.setStyleSheet(
            f"border:1px solid {theme.BORDER}; border-radius:6px; background:#F3F5F7;"
        )
        pix = thumbnail_pixmap(image_path, 116, 66)
        if pix is not None:
            thumb.setPixmap(pix)
            thumb.setToolTip("点击预览效果图")
            thumb.clicked.connect(
                lambda p=image_path, o=original_path: self._preview(p, o)
            )
        else:
            thumb.setText("图片丢失")
            thumb.setAlignment(Qt.AlignCenter)
            thumb.setStyleSheet(
                f"border:1px solid {theme.BORDER}; border-radius:6px; "
                f"background:#F3F5F7; color:{theme.TEXT_MUTED}; font-size:11px;"
            )
        layout.addWidget(thumb)

        text = QVBoxLayout()
        text.setSpacing(1)
        name_label = QLabel()
        name_label.setTextFormat(Qt.PlainText)
        name_label.setStyleSheet(f"color:{theme.TEXT}; font-size:11px;")
        name = os.path.basename(image_path or "")
        metrics = QFontMetrics(name_label.font())
        name_label.setText(metrics.elidedText(name, Qt.ElideMiddle, 140))
        name_label.setToolTip(image_path)
        text.addWidget(name_label)

        meta_text = info_text(image_info(image_path)) or "—"
        meta = QLabel()
        meta.setTextFormat(Qt.PlainText)
        meta.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:10px;")
        meta.setText(metrics.elidedText(meta_text, Qt.ElideRight, 140))
        meta.setToolTip(meta_text)
        text.addWidget(meta)

        full = f"参数：{params_text or '默认'}"
        params_label = QLabel()
        params_label.setTextFormat(Qt.PlainText)
        params_label.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:10px;")
        params_label.setText(metrics.elidedText(full, Qt.ElideRight, 140))
        params_label.setToolTip(full)
        text.addWidget(params_label)
        layout.addLayout(text)
        layout.addStretch()
        return cell

    def _actions_cell(self, record):
        cell = QWidget()
        layout = QHBoxLayout(cell)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(6)

        preview_btn = make_button("预览", "ghost")
        preview_btn.setFixedSize(66, 30)
        preview_btn.clicked.connect(
            lambda: self._preview(record["image_path"], record["original_path"])
        )
        layout.addWidget(preview_btn)

        download_btn = make_button("下载", "primary")
        download_btn.setFixedSize(66, 30)
        download_btn.clicked.connect(
            lambda: save_image_as(self, record["image_path"], "下载效果图")
        )
        layout.addWidget(download_btn)
        layout.addStretch()
        return cell

    def _on_search(self):
        self.records_search = self.search_edit.text().strip()
        self.records_page = 1
        self._load_records()

    def _on_page_changed(self, page):
        self.records_page = page
        self._load_records()

    def _preview(self, image_path, original_path=None):
        dialog = ImagePreviewDialog(image_path, original_path, self.window())
        dialog.exec_()

    def _export_records(self):
        if not self.summary:
            return
        rows = repo.list_user_modifications(self.user_id, self.records_search)
        data = []
        for record in rows:
            info = image_info(record["image_path"])
            data.append((
                record["created_at"],
                os.path.basename(record["image_path"] or ""),
                record["image_path"] or "",
                info_text(info) or "",
                render_params.summary(
                    render_params.load_json(record.get("params"))
                ),
                record["original_path"] or "",
            ))
        safe_name = self.summary["name"].replace("/", "_").replace("\\", "_")
        default_name = f"{safe_name}_修改记录_{datetime.now():%Y%m%d}.csv"
        path = export_csv(
            self, default_name,
            ["修改时间", "效果图", "效果图路径", "图片信息", "渲染参数", "原图路径"],
            data,
        )
        if path:
            audit.record(
                "导出记录", self.summary["name"], "user",
                os.path.basename(path), f"{len(data)} 条"
            )

    # ---------- 账号设置 ----------
    def _on_new_password_changed(self, text):
        self.pwd_strength.set_password(text)
        self._set_pwd_error("")

    def _set_pwd_error(self, message):
        self.pwd_error.setText(message)
        self.pwd_error.setVisible(bool(message))

    def _change_password(self):
        self._set_pwd_error("")
        old = self.old_pwd.text()
        new = self.new_pwd.text()
        confirm = self.confirm_pwd.text()
        if not old or not new or not confirm:
            self._set_pwd_error("请填写当前密码、新密码并确认。")
            return
        if new != confirm:
            self._set_pwd_error("两次输入的新密码不一致。")
            return
        ok, msg = auth.change_password(self.user_id, old, new)
        if not ok:
            self._set_pwd_error(msg)
            return
        self.old_pwd.clear()
        self.new_pwd.clear()
        self.confirm_pwd.clear()
        self.pwd_strength.set_password("")
        show_toast(self, "密码已修改，下次登录请使用新密码")

    def _logout(self):
        reply = QMessageBox.question(
            self, "退出登录", "确定要退出当前账号吗？",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return
        if self.on_close:
            self.on_close()
        if self.on_logout:
            self.on_logout()

    def _close(self):
        if self.on_close:
            self.on_close()
        else:
            self.close()
