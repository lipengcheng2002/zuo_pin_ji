# pages/admin_dashboard.py
# 职责：管理员端运营概览（数据看板 + 智能运营提示 + 数据备份）

import os

from PyQt5.QtCore import Qt, QUrl
from PyQt5.QtGui import QDesktopServices, QFontMetrics
from PyQt5.QtWidgets import (
    QComboBox, QHBoxLayout, QLabel, QMessageBox, QStackedWidget,
    QTableWidgetItem, QVBoxLayout, QWidget
)

from core import audit, backup, repo
from core.config import BACKUP_DIR
from ui import theme
from ui.imageutils import thumbnail_pixmap
from ui.widgets import (
    Card, DataTable, EmptyState, MiniBarChart, PageHeader, SectionTitle,
    StatCard, clear_layout, make_button
)


class DashboardPage(QWidget):
    def __init__(self, on_open_employees=None, on_open_employee=None, parent=None):
        super().__init__(parent)
        self.on_open_employees = on_open_employees
        self.on_open_employee = on_open_employee
        self.chart_days = 7
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 14, 18, 14)
        root.setSpacing(16)

        header = PageHeader("运营概览", "账号与图片修改数据实时汇总")
        backup_btn = make_button("备份数据", "ghost", height=36)
        backup_btn.clicked.connect(self._backup)
        header.add_action(backup_btn)
        refresh_btn = make_button("刷新数据", "primary", height=36)
        refresh_btn.clicked.connect(self.refresh)
        header.add_action(refresh_btn)
        root.addWidget(header)

        stats = QHBoxLayout()
        stats.setSpacing(14)
        self.card_users = StatCard("员工总数", "0", "今日新增 0", theme.PRIMARY)
        self.card_active = StatCard("正常账号", "0", "停用 0", theme.SUCCESS)
        self.card_total = StatCard("累计修改", "0", "全部历史记录", theme.INFO)
        self.card_today = StatCard("今日修改", "0", "昨日 0", theme.WARNING)
        for card in (self.card_users, self.card_active, self.card_total, self.card_today):
            stats.addWidget(card, 1)
        root.addLayout(stats)

        middle = QHBoxLayout()
        middle.setSpacing(16)

        chart_card = Card(padding=20, spacing=8)
        chart_head = QHBoxLayout()
        chart_head.addWidget(SectionTitle("修改趋势", 16))
        chart_head.addStretch()
        self.range_combo = QComboBox()
        self.range_combo.addItems(["近 7 天", "近 30 天"])
        self.range_combo.setFixedWidth(108)
        self.range_combo.currentIndexChanged.connect(self._on_range_changed)
        chart_head.addWidget(self.range_combo)
        chart_card.body.addLayout(chart_head)
        self.chart = MiniBarChart()
        chart_card.body.addWidget(self.chart, 1)
        middle.addWidget(chart_card, 3)

        insight_card = Card(padding=20, spacing=10)
        insight_head = QHBoxLayout()
        insight_head.addWidget(SectionTitle("智能运营提示", 16))
        insight_head.addStretch()
        spark = QLabel("智能")
        spark.setStyleSheet(
            f"background:{theme.PRIMARY_SOFT}; color:{theme.PRIMARY}; border-radius:8px; "
            "padding:2px 8px; font-size:11px; font-weight:700;"
        )
        insight_head.addWidget(spark)
        insight_card.body.addLayout(insight_head)
        insight_sub = QLabel("根据当前账号与修改数据自动生成")
        insight_sub.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:12px;")
        insight_card.body.addWidget(insight_sub)
        self.insights_layout = QVBoxLayout()
        self.insights_layout.setSpacing(8)
        insight_card.body.addLayout(self.insights_layout)
        insight_card.body.addStretch()
        middle.addWidget(insight_card, 2)

        root.addLayout(middle, 3)

        recent_card = Card(padding=20, spacing=10)
        recent_head = QHBoxLayout()
        recent_head.addWidget(SectionTitle("最近修改", 16))
        recent_head.addStretch()
        hint = QLabel("双击记录查看员工详情")
        hint.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:11px;")
        recent_head.addWidget(hint)
        if self.on_open_employees:
            view_btn = make_button("员工管理 →", "subtle", height=30)
            view_btn.clicked.connect(self.on_open_employees)
            recent_head.addWidget(view_btn)
        recent_card.body.addLayout(recent_head)

        self.recent_stack = QStackedWidget()
        self.recent_table = DataTable(["员工", "修改图片", "修改时间"], row_height=50)
        self.recent_table.set_widths({1: 280})
        self.recent_table.cellDoubleClicked.connect(self._on_recent_double_click)
        self.recent_stack.addWidget(self.recent_table)
        self.recent_stack.addWidget(
            EmptyState("暂无修改记录", "员工生成效果图后会显示在这里。", "▢")
        )
        recent_card.body.addWidget(self.recent_stack, 1)
        root.addWidget(recent_card, 4)

    # ---------- 数据刷新 ----------
    def refresh(self):
        stats = repo.dashboard_stats()
        self.card_users.set_value(
            stats["total_users"], f"今日新增 {stats['today_new_users']}"
        )
        self.card_active.set_value(
            stats["active_users"], f"停用 {stats['disabled_users']}"
        )
        self.card_total.set_value(stats["total_mods"], "全部历史记录")
        self.card_today.set_value(
            stats["today_mods"], f"昨日 {stats['yesterday_mods']}"
        )

        self.chart.set_data(repo.daily_counts(self.chart_days))
        self._render_insights(repo.build_insights())
        self._load_recent(repo.list_recent_modifications(6))

    def _on_range_changed(self, index):
        self.chart_days = 30 if index == 1 else 7
        self.chart.set_data(repo.daily_counts(self.chart_days))

    def _render_insights(self, lines):
        clear_layout(self.insights_layout)
        for line in lines:
            row = QHBoxLayout()
            row.setSpacing(8)
            dot = QLabel("•")
            dot.setStyleSheet(
                f"color:{theme.PRIMARY}; font-size:16px; font-weight:700;"
            )
            dot.setAlignment(Qt.AlignTop)
            row.addWidget(dot)
            label = QLabel(line)
            label.setTextFormat(Qt.PlainText)
            label.setWordWrap(True)
            label.setStyleSheet(f"color:{theme.TEXT_SECONDARY}; font-size:12px;")
            row.addWidget(label, 1)
            self.insights_layout.addLayout(row)

    def _load_recent(self, rows):
        self.recent_table.setRowCount(0)
        if not rows:
            self.recent_stack.setCurrentIndex(1)
            return
        self.recent_stack.setCurrentIndex(0)
        for row_data in rows:
            row = self.recent_table.rowCount()
            self.recent_table.insertRow(row)
            name_item = QTableWidgetItem(row_data["name"])
            name_item.setData(Qt.UserRole, row_data["user_id"])
            self.recent_table.setItem(row, 0, name_item)
            self.recent_table.setCellWidget(
                row, 1, self._image_cell(row_data["image_path"])
            )
            self.recent_table.setItem(
                row, 2, QTableWidgetItem(row_data["created_at"] or "—")
            )

    def _on_recent_double_click(self, row, column):
        item = self.recent_table.item(row, 0)
        if item is None or not self.on_open_employee:
            return
        user_id = item.data(Qt.UserRole)
        if user_id:
            self.on_open_employee(user_id)

    @staticmethod
    def _image_cell(image_path):
        cell = QWidget()
        layout = QHBoxLayout(cell)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(8)

        thumb = QLabel()
        thumb.setFixedSize(72, 40)
        thumb.setStyleSheet(
            f"border:1px solid {theme.BORDER}; border-radius:4px; background:#F3F5F7;"
        )
        pix = thumbnail_pixmap(image_path, 84, 48)
        if pix is not None:
            thumb.setPixmap(pix)
        else:
            thumb.setText("丢失")
            thumb.setAlignment(Qt.AlignCenter)
            thumb.setStyleSheet(
                f"border:1px solid {theme.BORDER}; border-radius:4px; "
                f"background:#F3F5F7; color:{theme.TEXT_MUTED}; font-size:11px;"
            )
        layout.addWidget(thumb)

        name = QLabel()
        name.setTextFormat(Qt.PlainText)
        name.setStyleSheet(f"color:{theme.TEXT_SECONDARY}; font-size:12px;")
        text = os.path.basename(image_path or "")
        metrics = QFontMetrics(name.font())
        name.setText(metrics.elidedText(text, Qt.ElideMiddle, 150))
        name.setToolTip(image_path or "")
        layout.addWidget(name)
        layout.addStretch()
        return cell

    # ---------- 备份 ----------
    def _backup(self):
        try:
            path = backup.create_backup()
        except Exception as exc:
            QMessageBox.critical(self, "备份失败", f"生成备份失败：{exc}")
            return
        audit.record(
            "备份数据", "管理员", "admin",
            os.path.basename(path), BACKUP_DIR
        )
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Information)
        box.setWindowTitle("备份完成")
        box.setText("数据已成功备份")
        box.setInformativeText(path)
        open_btn = box.addButton("打开备份文件夹", QMessageBox.ActionRole)
        box.addButton("关闭", QMessageBox.AcceptRole)
        box.exec_()
        if box.clickedButton() is open_btn:
            QDesktopServices.openUrl(QUrl.fromLocalFile(BACKUP_DIR))
