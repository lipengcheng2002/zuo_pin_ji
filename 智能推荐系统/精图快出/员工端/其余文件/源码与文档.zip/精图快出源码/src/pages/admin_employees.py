# pages/admin_employees.py
# 职责：管理员端员工管理（列表分页/筛选 + 员工修改明细）

import os
from datetime import datetime
from math import ceil

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFontMetrics
from PyQt5.QtWidgets import (
    QComboBox, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
    QStackedWidget, QTableWidgetItem, QVBoxLayout, QWidget
)

from core import audit, auth, render_params, repo
from core.config import PAGE_SIZE
from ui import theme
from ui.export import export_csv
from ui.imageutils import image_info, info_text, thumbnail_pixmap
from ui.preview import ImagePreviewDialog
from ui.toast import show_toast
from ui.widgets import (
    Avatar, Card, DataTable, EmptyState, PageHeader, PaginationBar,
    SectionTitle, StatCard, StatusChip, make_button
)


class EmployeesPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_user_id = None
        self.list_page = 1
        self.list_search = ""
        self.list_status = "all"
        self.list_total = 0
        self.detail_page = 1
        self.detail_total = 0
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        self.stack = QStackedWidget()
        self.stack.addWidget(self._build_list_page())
        self.stack.addWidget(self._build_detail_page())
        root.addWidget(self.stack)

    # ================== 列表 ==================
    def _build_list_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(14)

        header = PageHeader("员工管理", "点击员工查看图片修改次数与明细")
        export_btn = make_button("导出名单", "ghost", height=36)
        export_btn.clicked.connect(self._export_list)
        header.add_action(export_btn)
        refresh_btn = make_button("刷新", "primary", height=36)
        refresh_btn.clicked.connect(self.refresh)
        header.add_action(refresh_btn)
        layout.addWidget(header)

        toolbar = QHBoxLayout()
        toolbar.setSpacing(10)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("搜索姓名")
        self.search_edit.setFixedWidth(170)
        self.search_edit.textChanged.connect(self._on_search)
        toolbar.addWidget(self.search_edit)

        self.status_combo = QComboBox()
        self.status_combo.addItems(["全部状态", "正常", "已停用"])
        self.status_combo.setFixedWidth(100)
        self.status_combo.currentIndexChanged.connect(self._on_status)
        toolbar.addWidget(self.status_combo)

        self.count_label = QLabel("共 0 位员工")
        self.count_label.setStyleSheet(
            f"color:{theme.TEXT_MUTED}; font-size:12px;"
        )
        toolbar.addWidget(self.count_label)
        toolbar.addStretch()
        hint = QLabel("点击任意一行进入员工详情")
        hint.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:11px;")
        toolbar.addWidget(hint)
        layout.addLayout(toolbar)

        self.list_stack = QStackedWidget()
        self.table = DataTable(
            ["姓名", "修改图片次数", "最后修改时间", "状态", "操作"], row_height=46
        )
        self.table.set_widths({1: 100, 3: 80, 4: 80})
        self.table.cellClicked.connect(self._on_cell_clicked)
        self.list_stack.addWidget(self.table)
        self.list_stack.addWidget(
            EmptyState(
                "还没有员工账号",
                "请先在「注册账号」页面开通员工账号。",
                "▢",
            )
        )
        layout.addWidget(self.list_stack, 1)

        self.pagination = PaginationBar()
        self.pagination.page_changed.connect(self._on_page_changed)
        layout.addWidget(self.pagination)
        return page

    def _on_cell_clicked(self, row, column):
        item = self.table.item(row, 0)
        if item is None:
            return
        user_id = item.data(Qt.UserRole)
        if user_id:
            self.open_detail(user_id)

    def _on_search(self):
        self.list_search = self.search_edit.text().strip()
        self.list_page = 1
        self._load_list()

    def _on_status(self, index):
        self.list_status = {0: "all", 1: "active", 2: "disabled"}.get(index, "all")
        self.list_page = 1
        self._load_list()

    def _on_page_changed(self, page):
        self.list_page = page
        self._load_list()

    @staticmethod
    def _is_locked(data):
        value = data.get("locked_until")
        if not value:
            return False
        try:
            return datetime.fromisoformat(value) > datetime.now()
        except ValueError:
            return False

    def _load_list(self):
        rows, total = repo.page_employees(
            self.list_search, self.list_status, self.list_page, PAGE_SIZE
        )
        pages = max(1, ceil(total / PAGE_SIZE))
        if self.list_page > pages:
            self.list_page = pages
            rows, total = repo.page_employees(
                self.list_search, self.list_status, self.list_page, PAGE_SIZE
            )
        self.list_total = total
        self.table.setRowCount(0)
        self.pagination.set_state(self.list_page, total, PAGE_SIZE)
        self.count_label.setText(f"共 {total} 位员工")
        if not rows:
            self.list_stack.setCurrentIndex(1)
            return

        self.list_stack.setCurrentIndex(0)
        for data in rows:
            row = self.table.rowCount()
            self.table.insertRow(row)

            name_item = QTableWidgetItem(data["name"])
            name_item.setData(Qt.UserRole, data["id"])
            self.table.setItem(row, 0, name_item)
            self.table.setItem(
                row, 1, QTableWidgetItem(f"{data['modify_count']} 次")
            )
            self.table.setItem(
                row, 2, QTableWidgetItem(data["last_modified_at"] or "—")
            )

            status_cell = QWidget()
            status_layout = QHBoxLayout(status_cell)
            status_layout.setContentsMargins(4, 0, 4, 0)
            active = bool(data["is_active"])
            locked = self._is_locked(data)
            if not active:
                chip = StatusChip("danger", "已停用")
            elif locked:
                chip = StatusChip("warning", "登录锁定")
            else:
                chip = StatusChip("success", "正常")
            status_layout.addWidget(chip)
            status_layout.addStretch()
            self.table.setCellWidget(row, 3, status_cell)

            action_cell = QWidget()
            action_layout = QHBoxLayout(action_cell)
            action_layout.setContentsMargins(4, 0, 4, 0)
            view_btn = make_button("查看", "subtle")
            view_btn.setFixedSize(66, 30)
            view_btn.clicked.connect(
                lambda _=False, uid=data["id"]: self.open_detail(uid)
            )
            action_layout.addWidget(view_btn)
            action_layout.addStretch()
            self.table.setCellWidget(row, 4, action_cell)

    def _export_list(self):
        rows = repo.list_employees(self.list_search, self.list_status)
        data = [
            (
                item["name"],
                item["modify_count"],
                item["last_modified_at"] or "—",
                "正常" if item["is_active"] else "已停用",
                item["created_at"] or "—",
                item["last_login_at"] or "从未登录",
            )
            for item in rows
        ]
        path = export_csv(
            self,
            f"员工名单_{datetime.now():%Y%m%d}.csv",
            ["姓名", "修改图片次数", "最后修改时间", "状态", "开通时间", "最后登录"],
            data,
        )
        if path:
            audit.record(
                "导出员工", "管理员", "admin",
                os.path.basename(path), f"{len(data)} 位"
            )

    # ================== 详情 ==================
    def _build_detail_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(14)

        top_bar = QHBoxLayout()
        back_btn = make_button("← 返回员工列表", "ghost", height=34)
        back_btn.clicked.connect(self.show_list)
        top_bar.addWidget(back_btn)
        self.unlock_btn = make_button("解除登录锁定", "ghost", height=34)
        self.unlock_btn.clicked.connect(self._unlock)
        self.unlock_btn.setVisible(False)
        top_bar.addWidget(self.unlock_btn)
        self.reset_pwd_btn = make_button("重置密码", "ghost", height=34)
        self.reset_pwd_btn.clicked.connect(self._reset_password)
        top_bar.addWidget(self.reset_pwd_btn)
        top_bar.addStretch()
        export_btn = make_button("导出明细", "ghost", height=34)
        export_btn.clicked.connect(self._export_detail)
        top_bar.addWidget(export_btn)
        refresh_btn = make_button("刷新明细", "primary", height=34)
        refresh_btn.clicked.connect(self._refresh_detail)
        top_bar.addWidget(refresh_btn)
        layout.addLayout(top_bar)

        identity = Card(padding=22, spacing=0)
        identity_layout = QHBoxLayout()
        identity_layout.setSpacing(14)
        self.detail_avatar = Avatar("?", 56)
        identity_layout.addWidget(self.detail_avatar)
        info = QVBoxLayout()
        info.setSpacing(3)
        name_row = QHBoxLayout()
        name_row.setSpacing(10)
        self.detail_name = QLabel("—")
        self.detail_name.setTextFormat(Qt.PlainText)
        self.detail_name.setStyleSheet(
            f"font-size:22px; font-weight:700; color:{theme.TEXT};"
        )
        name_row.addWidget(self.detail_name)
        self.detail_chip = StatusChip("success")
        name_row.addWidget(self.detail_chip)
        name_row.addStretch()
        info.addLayout(name_row)
        self.detail_meta = QLabel("")
        self.detail_meta.setTextFormat(Qt.PlainText)
        self.detail_meta.setStyleSheet(
            f"color:{theme.TEXT_SECONDARY}; font-size:12px;"
        )
        info.addWidget(self.detail_meta)
        identity_layout.addLayout(info, 1)
        identity.body.addLayout(identity_layout)
        layout.addWidget(identity)

        stats = QHBoxLayout()
        stats.setSpacing(14)
        self.stat_count = StatCard("修改图片次数", "0", "该员工全部修改记录", theme.PRIMARY)
        self.stat_last = StatCard(
            "最后修改时间", "—", "最近一次生成效果图", theme.INFO, value_size=19
        )
        self.stat_created = StatCard(
            "加入时间", "—", "管理员开通账号的时间", theme.SUCCESS, value_size=19
        )
        stats.addWidget(self.stat_count, 1)
        stats.addWidget(self.stat_last, 1)
        stats.addWidget(self.stat_created, 1)
        layout.addLayout(stats)

        records = Card(padding=20, spacing=10)
        records_head = QHBoxLayout()
        records_head.addWidget(SectionTitle("修改明细", 16))
        records_head.addStretch()
        self.detail_count = QLabel("")
        self.detail_count.setStyleSheet(
            f"color:{theme.TEXT_MUTED}; font-size:12px;"
        )
        records_head.addWidget(self.detail_count)
        records.body.addLayout(records_head)

        self.detail_stack = QStackedWidget()
        self.detail_table = DataTable(["修改图片", "修改时间", "操作"], row_height=78)
        self.detail_table.set_widths({1: 160, 2: 80})
        self.detail_stack.addWidget(self.detail_table)
        self.detail_stack.addWidget(
            EmptyState("暂无修改记录", "该员工还没有生成效果图。", "▢")
        )
        records.body.addWidget(self.detail_stack, 1)

        self.detail_pagination = PaginationBar()
        self.detail_pagination.page_changed.connect(self._on_detail_page_changed)
        records.body.addWidget(self.detail_pagination)
        layout.addWidget(records, 1)
        return page

    def _on_detail_page_changed(self, page):
        self.detail_page = page
        self._load_detail()

    def open_detail(self, user_id):
        self.current_user_id = user_id
        self.detail_page = 1
        self.stack.setCurrentIndex(1)
        self._load_detail()

    def _refresh_detail(self):
        if self.current_user_id:
            self._load_detail()

    def _unlock(self):
        if not self.current_user_id:
            return
        employee = repo.get_employee(self.current_user_id)
        if not employee:
            self.show_list()
            return
        if repo.unlock_user(self.current_user_id):
            audit.record("解除锁定", "管理员", "admin", employee["name"])
            show_toast(self, f"已解除「{employee['name']}」的登录锁定")
            self._load_detail()
        else:
            show_toast(self, "该账号当前未被锁定", "info")

    def _reset_password(self):
        if not self.current_user_id:
            return
        employee = repo.get_employee(self.current_user_id)
        if not employee:
            self.show_list()
            return
        reply = QMessageBox.question(
            self, "重置密码",
            f"将「{employee['name']}」的密码重置为 {auth.DEFAULT_PASSWORD}？\n"
            "员工下次登录必须设置新密码，历史修改记录保留。",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        ok, msg = auth.reset_to_default(self.current_user_id)
        if not ok:
            QMessageBox.warning(self, "重置失败", msg)
            return
        show_toast(self, f"已重置「{employee['name']}」的密码")
        self._load_detail()

    def _load_detail(self):
        if not self.current_user_id:
            return
        employee = repo.get_employee(self.current_user_id)
        if not employee:
            self.show_list()
            return

        name = employee["name"]
        self.detail_name.setText(name)
        self.detail_avatar.setText(name[:1] if name else "?")
        active = bool(employee["is_active"])
        locked_until = employee.get("locked_until")
        locked = False
        if locked_until:
            try:
                locked = datetime.fromisoformat(locked_until) > datetime.now()
            except ValueError:
                locked = False
        if not active:
            chip_kind, chip_text = "danger", "已停用"
        elif locked:
            chip_kind, chip_text = "warning", "登录锁定"
        else:
            chip_kind, chip_text = "success", "正常"
        self.detail_chip.setText(chip_text)
        bg, fg = {
            "success": (theme.SUCCESS_SOFT, theme.SUCCESS),
            "danger": (theme.DANGER_SOFT, theme.DANGER),
            "warning": (theme.WARNING_SOFT, theme.WARNING),
        }[chip_kind]
        self.detail_chip.setStyleSheet(
            f"background:{bg}; color:{fg}; border-radius:9px; "
            "padding:3px 10px; font-size:12px; font-weight:600;"
        )
        self.unlock_btn.setVisible(locked)
        self.unlock_btn.setToolTip(
            f"登录已锁定至 {locked_until}" if locked else ""
        )
        meta = (
            f"开通于 {(employee['created_at'] or '')[:10]} · "
            f"最后登录：{employee['last_login_at'] or '从未登录'}"
        )
        if locked:
            meta += f" · 登录锁定至 {locked_until}"
        self.detail_meta.setText(meta)
        self.stat_count.set_value(employee["modify_count"], "该员工全部修改记录")
        self.stat_last.value_label.setText(employee["last_modified_at"] or "—")
        self.stat_created.value_label.setText((employee["created_at"] or "—")[:10])

        rows, total = repo.page_user_modifications(
            self.current_user_id, "", self.detail_page, PAGE_SIZE
        )
        pages = max(1, ceil(total / PAGE_SIZE))
        if self.detail_page > pages:
            self.detail_page = pages
            rows, total = repo.page_user_modifications(
                self.current_user_id, "", self.detail_page, PAGE_SIZE
            )
        self.detail_total = total
        self.detail_count.setText(f"共 {total} 条记录")
        self.detail_pagination.set_state(self.detail_page, total, PAGE_SIZE)
        self.detail_table.setRowCount(0)
        if not rows:
            self.detail_stack.setCurrentIndex(1)
            return

        self.detail_stack.setCurrentIndex(0)
        for record in rows:
            row = self.detail_table.rowCount()
            self.detail_table.insertRow(row)
            self.detail_table.setCellWidget(
                row, 0,
                self._image_cell(
                    record["image_path"],
                    record["original_path"],
                    render_params.summary(
                        render_params.load_json(record.get("params"))
                    ),
                )
            )
            self.detail_table.setItem(
                row, 1, QTableWidgetItem(record["created_at"] or "—")
            )
            action_cell = QWidget()
            action_layout = QHBoxLayout(action_cell)
            action_layout.setContentsMargins(4, 0, 4, 0)
            view_btn = make_button("查看", "subtle")
            view_btn.setFixedSize(66, 30)
            view_btn.clicked.connect(
                lambda _=False, p=record["image_path"],
                o=record["original_path"]: self._preview(p, o)
            )
            action_layout.addWidget(view_btn)
            action_layout.addStretch()
            self.detail_table.setCellWidget(row, 2, action_cell)

    def _image_cell(self, image_path, original_path, params_text=""):
        cell = QWidget()
        layout = QHBoxLayout(cell)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(10)

        thumb = QLabel()
        thumb.setFixedSize(116, 66)
        thumb.setStyleSheet(
            f"border:1px solid {theme.BORDER}; border-radius:6px; background:#F3F5F7;"
        )
        pix = thumbnail_pixmap(image_path, 116, 66)
        if pix is not None:
            thumb.setPixmap(pix)
        else:
            thumb.setText("图片丢失")
            thumb.setAlignment(Qt.AlignCenter)
            thumb.setStyleSheet(
                f"border:1px solid {theme.BORDER}; border-radius:6px; "
                f"background:#F3F5F7; color:{theme.TEXT_MUTED}; font-size:11px;"
            )
        layout.addWidget(thumb)

        text = QVBoxLayout()
        text.setSpacing(1)
        name_label = QLabel()
        name_label.setTextFormat(Qt.PlainText)
        name_label.setStyleSheet(f"color:{theme.TEXT}; font-size:12px;")
        name = os.path.basename(image_path or "")
        metrics = QFontMetrics(name_label.font())
        name_label.setText(metrics.elidedText(name, Qt.ElideMiddle, 200))
        name_label.setToolTip(image_path or "")
        text.addWidget(name_label)

        meta = QLabel(info_text(image_info(image_path)) or "—")
        meta.setTextFormat(Qt.PlainText)
        meta.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:11px;")
        text.addWidget(meta)

        full = f"参数：{params_text or '默认'}"
        params_label = QLabel()
        params_label.setTextFormat(Qt.PlainText)
        params_label.setStyleSheet(f"color:{theme.TEXT_MUTED}; font-size:11px;")
        params_label.setText(metrics.elidedText(full, Qt.ElideRight, 200))
        params_label.setToolTip(full)
        text.addWidget(params_label)
        layout.addLayout(text)
        layout.addStretch()
        return cell

    @staticmethod
    def _preview(image_path, original_path=None):
        dialog = ImagePreviewDialog(image_path, original_path, None)
        dialog.exec_()

    def _export_detail(self):
        if not self.current_user_id:
            return
        employee = repo.get_employee(self.current_user_id)
        if not employee:
            return
        rows = repo.list_user_modifications(self.current_user_id)
        data = []
        for record in rows:
            info = image_info(record["image_path"])
            data.append((
                record["created_at"],
                os.path.basename(record["image_path"] or ""),
                record["image_path"] or "",
                info_text(info) or "",
                render_params.summary(
                    render_params.load_json(record.get("params"))
                ),
                record["original_path"] or "",
            ))
        safe_name = employee["name"].replace("/", "_").replace("\\", "_")
        path = export_csv(
            self,
            f"{safe_name}_修改明细_{datetime.now():%Y%m%d}.csv",
            ["修改时间", "效果图", "效果图路径", "图片信息", "渲染参数", "原图路径"],
            data,
        )
        if path:
            audit.record(
                "导出明细", "管理员", "admin",
                employee["name"], f"{len(data)} 条"
            )

    def show_list(self):
        self.current_user_id = None
        self.stack.setCurrentIndex(0)
        self._load_list()

    def refresh(self):
        self._load_list()
        if self.current_user_id and self.stack.currentIndex() == 1:
            self._load_detail()
