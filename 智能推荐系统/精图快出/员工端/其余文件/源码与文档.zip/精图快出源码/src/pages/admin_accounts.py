# pages/admin_accounts.py
# 职责：管理员端账号管理（分页/筛选、停用/启用、二次确认删除）

import os
from datetime import datetime
from math import ceil

from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtWidgets import (
    QComboBox, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QStackedWidget,
    QTableWidgetItem, QVBoxLayout, QWidget
)

from core import audit, repo
from core.config import PAGE_SIZE
from ui import theme
from ui.export import export_csv
from ui.toast import show_toast
from ui.widgets import (
    DataTable, EmptyState, PageHeader, PaginationBar, StatusChip, make_button
)


class AccountsPage(QWidget):
    def __init__(self, on_data_changed=None, parent=None):
        super().__init__(parent)
        self.on_data_changed = on_data_changed
        self.search = ""
        self.status = "all"
        self.page = 1
        self.total = 0
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 14, 18, 14)
        root.setSpacing(14)

        header = PageHeader(
            "账号管理", "停用后无法登录；删除账号会清空全部历史修改记录"
        )
        export_btn = make_button("导出账号", "ghost", height=36)
        export_btn.clicked.connect(self._export)
        header.add_action(export_btn)
        refresh_btn = make_button("刷新", "primary", height=36)
        refresh_btn.clicked.connect(self.refresh)
        header.add_action(refresh_btn)
        root.addWidget(header)

        toolbar = QHBoxLayout()
        toolbar.setSpacing(10)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("搜索姓名")
        self.search_edit.setFixedWidth(170)
        self.search_edit.textChanged.connect(self._on_search)
        toolbar.addWidget(self.search_edit)

        self.status_combo = QComboBox()
        self.status_combo.addItems(["全部状态", "正常", "已停用"])
        self.status_combo.setFixedWidth(100)
        self.status_combo.currentIndexChanged.connect(self._on_status)
        toolbar.addWidget(self.status_combo)

        self.count_label = QLabel("共 0 个账号")
        self.count_label.setStyleSheet(
            f"color:{theme.TEXT_MUTED}; font-size:12px;"
        )
        toolbar.addWidget(self.count_label)
        toolbar.addStretch()

        self.notice = QLabel("")
        self.notice.setStyleSheet(f"color:{theme.SUCCESS}; font-size:12px;")
        self.notice.setVisible(False)
        toolbar.addWidget(self.notice)
        root.addLayout(toolbar)

        self.table_stack = QStackedWidget()
        self.table = DataTable(
            ["姓名", "状态", "修改图片次数", "开通时间", "最后登录", "操作"],
            row_height=48,
        )
        self.table.set_widths({1: 70, 2: 90, 3: 90, 4: 120, 5: 208})
        self.table_stack.addWidget(self.table)
        self.table_stack.addWidget(
            EmptyState("没有符合条件的账号", "调整筛选条件或先注册账号。", "▢")
        )
        root.addWidget(self.table_stack, 1)

        self.pagination = PaginationBar()
        self.pagination.page_changed.connect(self._on_page_changed)
        root.addWidget(self.pagination)

        self._notice_timer = QTimer(self)
        self._notice_timer.setSingleShot(True)
        self._notice_timer.timeout.connect(lambda: self.notice.setVisible(False))

    def _on_search(self):
        self.search = self.search_edit.text().strip()
        self.page = 1
        self._load()

    def _on_status(self, index):
        self.status = {0: "all", 1: "active", 2: "disabled"}.get(index, "all")
        self.page = 1
        self._load()

    def _on_page_changed(self, page):
        self.page = page
        self._load()

    @staticmethod
    def _is_locked(data):
        value = data.get("locked_until")
        if not value:
            return False
        try:
            return datetime.fromisoformat(value) > datetime.now()
        except ValueError:
            return False

    def _show_notice(self, text, danger=False):
        self.notice.setText(text)
        color = theme.DANGER if danger else theme.SUCCESS
        self.notice.setStyleSheet(f"color:{color}; font-size:12px;")
        self.notice.setVisible(True)
        self._notice_timer.start(4500)

    def refresh(self):
        self._load()

    def _load(self):
        rows, total = repo.page_employees(
            self.search, self.status, self.page, PAGE_SIZE
        )
        pages = max(1, ceil(total / PAGE_SIZE))
        if self.page > pages:
            self.page = pages
            rows, total = repo.page_employees(
                self.search, self.status, self.page, PAGE_SIZE
            )
        self.total = total
        self.count_label.setText(f"共 {total} 个账号")
        self.pagination.set_state(self.page, total, PAGE_SIZE)
        self.table.setRowCount(0)
        if not rows:
            self.table_stack.setCurrentIndex(1)
            return

        self.table_stack.setCurrentIndex(0)
        for data in rows:
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(data["name"]))

            status_cell = QWidget()
            status_layout = QHBoxLayout(status_cell)
            status_layout.setContentsMargins(4, 0, 4, 0)
            active = bool(data["is_active"])
            locked = self._is_locked(data)
            if not active:
                chip = StatusChip("danger", "已停用")
            elif locked:
                chip = StatusChip("warning", "登录锁定")
            else:
                chip = StatusChip("success", "正常")
            status_layout.addWidget(chip)
            status_layout.addStretch()
            self.table.setCellWidget(row, 1, status_cell)

            self.table.setItem(
                row, 2, QTableWidgetItem(f"{data['modify_count']} 次")
            )
            self.table.setItem(
                row, 3, QTableWidgetItem((data["created_at"] or "—")[:10])
            )
            self.table.setItem(
                row, 4, QTableWidgetItem(data["last_login_at"] or "从未登录")
            )

            action_cell = QWidget()
            action_layout = QHBoxLayout(action_cell)
            action_layout.setContentsMargins(4, 0, 4, 0)
            action_layout.setSpacing(8)

            toggle_text = "停用账号" if active else "取消停用"
            toggle_variant = "subtle" if active else "success"
            toggle_btn = make_button(toggle_text, toggle_variant)
            toggle_btn.setFixedSize(96, 32)
            toggle_btn.clicked.connect(
                lambda _=False, uid=data["id"], name=data["name"],
                flag=active: self._toggle(uid, name, flag)
            )
            action_layout.addWidget(toggle_btn)

            delete_btn = make_button("删除账号", "danger")
            delete_btn.setFixedSize(96, 32)
            delete_btn.clicked.connect(
                lambda _=False, uid=data["id"], name=data["name"],
                count=data["modify_count"]: self._delete(uid, name, count)
            )
            action_layout.addWidget(delete_btn)
            action_layout.addStretch()
            self.table.setCellWidget(row, 5, action_cell)

    def _toggle(self, user_id, name, currently_active):
        repo.set_active(user_id, not currently_active)
        action = "停用账号" if currently_active else "启用账号"
        audit.record(action, "管理员", "admin", name)
        if currently_active:
            message = f"已停用「{name}」，该账号将无法登录主程序"
        else:
            message = f"已恢复「{name}」的登录权限"
        self._show_notice(message)
        show_toast(self, message)
        self._load()
        if self.on_data_changed:
            self.on_data_changed()

    def _delete(self, user_id, name, count):
        first = QMessageBox.question(
            self, "删除账号",
            f"确定要删除「{name}」吗？\n删除后该账号无法登录。",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if first != QMessageBox.Yes:
            return

        box = QMessageBox(self)
        box.setTextFormat(Qt.PlainText)
        box.setIcon(QMessageBox.Warning)
        box.setWindowTitle("二次确认")
        box.setText(f"再次确认：永久删除「{name}」？")
        box.setInformativeText(
            f"该账号及 {count} 条历史修改记录将被永久删除，"
            "删除后无法登录、无法找回，也无法恢复历史记录。"
        )
        yes_btn = box.addButton("确认永久删除", QMessageBox.DestructiveRole)
        no_btn = box.addButton("取消", QMessageBox.RejectRole)
        box.setDefaultButton(no_btn)
        box.exec_()
        if box.clickedButton() is not yes_btn:
            return

        result = repo.delete_user(user_id)
        removed_files = repo.remove_image_files(result["image_paths"])
        audit.record(
            "删除账号", "管理员", "admin", result["name"] or name,
            f"清除记录 {result['records']} 条，"
            f"图片文件 {removed_files}/{result['records']} 个"
        )
        message = (
            f"已删除账号「{result['name'] or name}」。\n"
            f"清除修改记录 {result['records']} 条，"
            f"图片文件 {removed_files}/{result['records']} 个。"
        )
        if removed_files < result["records"]:
            message += "\n部分效果图可能被其他程序占用或已被移动，未能删除。"
        QMessageBox.information(self, "删除完成", message)
        self._load()
        if self.on_data_changed:
            self.on_data_changed()

    def _export(self):
        rows = repo.list_employees(self.search, self.status)
        data = [
            (
                item["name"],
                "正常" if item["is_active"] else "已停用",
                item["modify_count"],
                item["created_at"] or "—",
                item["last_login_at"] or "从未登录",
                item["last_modified_at"] or "—",
            )
            for item in rows
        ]
        path = export_csv(
            self,
            f"账号清单_{datetime.now():%Y%m%d}.csv",
            ["姓名", "状态", "修改图片次数", "开通时间", "最后登录", "最后修改时间"],
            data,
        )
        if path:
            audit.record(
                "导出账号", "管理员", "admin",
                os.path.basename(path), f"{len(data)} 个"
            )
