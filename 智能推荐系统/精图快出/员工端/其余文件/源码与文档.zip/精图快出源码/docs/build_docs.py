# -*- coding: utf-8 -*-
"""Build DOCX + PDF deliverables from the Markdown sources."""
import os
import re
import sys

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate, CondPageBreak, Frame, Image, LongTable, NextPageTemplate,
    PageBreak, PageTemplate, Paragraph, Preformatted, Spacer, Table, TableStyle
)
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.pdfgen import canvas as rl_canvas

DOCS = r"C:\Users\李鹏程\Desktop\小组_臭皮匠项目_图片二创系统---项目峰会\精图快出系统\docs"
VERSION = "v2.5.0"
DATE = "2026-10-28"
PRIMARY = "C55A11"
DARK = "1B2430"
GRAY = "5C6675"
LIGHT = "FDF3EC"
BORDER = "E4E9EF"

SPECS = [
    {
        "md": "精图快出_企业级使用问题清单_v2.5.0.md",
        "stem": "精图快出_企业级使用问题清单_v2.5.0",
        "title": "精图快出 · 企业级使用问题清单",
        "subtitle": "企业部署、账号安全、数据治理与运营边界",
        "label": "企业级审查报告",
        "doc_id": "JTKC-ISSUE-2.5.0",
        "break_prefixes": ("A.", "B.", "C.", "D.", "E.", "F.", "G.", "附录", "建议的上线检查表"),
        "force_h2_breaks": True,
        "table_font": 8.3,
        "body_font": 10.2,
    },
    {
        "md": "精图快出_使用手册_v2.5.0.md",
        "stem": "精图快出_使用手册_v2.5.0",
        "title": "精图快出 · 使用手册",
        "subtitle": "双端系统 · 管理员端与员工端",
        "label": "用户手册",
        "doc_id": "JTKC-MANUAL-2.5.0",
        "break_prefixes": ("1.", "2.", "3.", "4.", "5.", "6.", "7.", "8.", "9.", "10.", "附录"),
        "force_h2_breaks": False,
        "table_font": 9.0,
        "body_font": 10.4,
    },
    {
        "md": "精图快出_项目简介_v2.5.0.md",
        "stem": "精图快出_项目简介_v2.5.0",
        "title": "精图快出 · 项目简介",
        "subtitle": "企业级图片精修双端系统",
        "label": "项目简介",
        "doc_id": "JTKC-BRIEF-2.5.0",
        "break_prefixes": (),
        "force_h2_breaks": False,
        "simple": True,
        "table_font": 9.0,
        "body_font": 10.4,
    },
]


# ---------------------------------------------------------------------------
# Markdown parsing
# ---------------------------------------------------------------------------
def _is_cjk(ch):
    return bool(ch) and "\u4e00" <= ch <= "\u9fff"


def _join_lines(a, b):
    if not a:
        return b
    if _is_cjk(a[-1]) and _is_cjk(b[0]):
        return a + b
    return a + " " + b


def parse_table(lines):
    rows = []
    for line in lines:
        text = line.strip()
        if not (text.startswith("|") and text.endswith("|")):
            continue
        cells = [cell.strip() for cell in text.strip("|").split("|")]
        if all(re.fullmatch(r":?-{2,}:?", cell or "") for cell in cells):
            continue
        rows.append(cells)
    if not rows:
        return None
    width = max(len(row) for row in rows)
    rows = [row + [""] * (width - len(row)) for row in rows]
    return rows


def flatten_assets():
    folder = os.path.join(DOCS, "assets")
    if not os.path.isdir(folder):
        return
    for name in os.listdir(folder):
        if not name.lower().endswith(".png"):
            continue
        path = os.path.join(folder, name)
        try:
            with PILImage.open(path) as im:
                if im.mode == "RGB":
                    continue
                rgba = im.convert("RGBA")
                bg = PILImage.new("RGB", rgba.size, "white")
                bg.paste(rgba, mask=rgba.getchannel("A"))
                bg.save(path)
        except Exception:
            pass


def parse_markdown(path):
    text = open(path, encoding="utf-8").read()
    lines = text.splitlines()
    blocks = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        if line.startswith("```"):
            i += 1
            code = []
            while i < len(lines) and not lines[i].startswith("```"):
                code.append(lines[i])
                i += 1
            i += 1
            blocks.append(("code", "\n".join(code)))
            continue
        if line.strip() == "<!-- pagebreak -->":
            blocks.append(("pagebreak", None))
            i += 1
            continue
        if line.startswith("### "):
            blocks.append(("h3", line[4:].strip()))
            i += 1
            continue
        if line.startswith("## "):
            blocks.append(("h2", line[3:].strip()))
            i += 1
            continue
        if line.startswith("# "):
            blocks.append(("h1", line[2:].strip()))
            i += 1
            continue
        if line.startswith("|"):
            table_lines = []
            while i < len(lines) and lines[i].startswith("|"):
                table_lines.append(lines[i])
                i += 1
            table = parse_table(table_lines)
            if table:
                blocks.append(("table", table))
            continue
        image = re.match(r"!\[(.*?)\]\((.*?)\)\s*$", line.strip())
        if image:
            blocks.append(("image", (image.group(1), image.group(2))))
            i += 1
            continue
        if line.startswith("> "):
            quote = []
            while i < len(lines) and lines[i].startswith("> "):
                quote.append(lines[i][2:].strip())
                i += 1
            blocks.append(("quote", _join_lines("", " ".join(quote))))
            continue
        if line.startswith("- "):
            items = []
            while i < len(lines) and lines[i].startswith("- "):
                items.append(lines[i][2:].strip())
                i += 1
            blocks.append(("bullets", items))
            continue
        if re.match(r"^\d+\.\s+", line):
            items = []
            while i < len(lines) and re.match(r"^\d+\.\s+", lines[i]):
                items.append(re.sub(r"^\d+\.\s+", "", lines[i]).strip())
                i += 1
            blocks.append(("numbers", items))
            continue
        paragraph = [line.strip()]
        i += 1
        while i < len(lines):
            nxt = lines[i]
            if (not nxt.strip() or nxt.startswith(("#", "|", "> ", "- ", "```"))
                    or nxt.strip() == "<!-- pagebreak -->"
                    or re.match(r"^\d+\.\s+", nxt)
                    or re.match(r"!\[.*?\]\(.*?\)\s*$", nxt.strip())):
                break
            paragraph.append(nxt.strip())
            i += 1
        text = paragraph[0]
        for part in paragraph[1:]:
            text = _join_lines(text, part)
        blocks.append(("p", text))
    return blocks


def inline_tokens(text):
    pattern = re.compile(r"(\*\*.+?\*\*|`[^`]+`)")
    tokens = []
    for part in pattern.split(text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**") and len(part) > 4:
            tokens.append((part[2:-2], True, False))
        elif part.startswith("`") and part.endswith("`") and len(part) > 2:
            tokens.append((part[1:-1], False, True))
        else:
            tokens.append((part, False, False))
    return tokens


# ---------------------------------------------------------------------------
# DOCX renderer
# ---------------------------------------------------------------------------
def docx_set_run_font(run, font="微软雅黑", size=10.5, bold=False, color=None,
                      east_asia=None):
    run.font.name = font
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    rfonts.set(qn("w:eastAsia"), east_asia or font)


def docx_add_inline(paragraph, text, size=10.5, color=None, bold=False):
    for value, is_bold, is_code in inline_tokens(text):
        run = paragraph.add_run(value)
        if is_code:
            docx_set_run_font(
                run, "Consolas", size - 0.45, bold=bold or is_bold,
                color=color, east_asia="微软雅黑",
            )
        else:
            docx_set_run_font(
                run, "微软雅黑", size, bold=bold or is_bold, color=color
            )


def docx_shade(cell_or_par, fill):
    if hasattr(cell_or_par, "_tc"):
        tcPr = cell_or_par._tc.get_or_add_tcPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), fill)
        tcPr.append(shd)
    else:
        pPr = cell_or_par._p.get_or_add_pPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), fill)
        pPr.append(shd)


def docx_border(paragraph, side="left", color=PRIMARY, size=18):
    pPr = paragraph._p.get_or_add_pPr()
    pBdr = pPr.find(qn("w:pBdr"))
    if pBdr is None:
        pBdr = OxmlElement("w:pBdr")
        pPr.append(pBdr)
    border = OxmlElement(f"w:{side}")
    border.set(qn("w:val"), "single")
    border.set(qn("w:sz"), str(size))
    border.set(qn("w:space"), "6")
    border.set(qn("w:color"), color)
    pBdr.append(border)


def docx_set_cell_margins(table, top=50, start=80, bottom=50, end=80):
    tblPr = table._tbl.tblPr
    mar = OxmlElement("w:tblCellMar")
    for key, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        el = OxmlElement(f"w:{key}")
        el.set(qn("w:w"), str(value))
        el.set(qn("w:type"), "dxa")
        mar.append(el)
    tblPr.append(mar)


def docx_table_borders(table, color=BORDER):
    tblPr = table._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "4")
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), color)
        borders.append(el)
    tblPr.append(borders)


def docx_header_footer(section, spec):
    section.different_first_page_header_footer = not spec.get("simple")
    header = section.header
    header.is_linked_to_previous = False
    p = header.paragraphs[0]
    p.paragraph_format.tab_stops.add_tab_stop(Cm(16.4), 2)  # right tab
    docx_add_inline(p, spec["title"], size=8, color=GRAY)
    p.add_run("\t")
    docx_add_inline(p, f"{VERSION} · {spec['label']}", size=8, color=GRAY)
    docx_border(p, "bottom", BORDER, 4)

    footer = section.footer
    footer.is_linked_to_previous = False
    p = footer.paragraphs[0]
    p.paragraph_format.tab_stops.add_tab_stop(Cm(8.2), 1)  # center
    p.paragraph_format.tab_stops.add_tab_stop(Cm(16.4), 2)  # right
    docx_add_inline(p, "内部资料 · 请按企业数据分级管理", size=7.5, color=GRAY)
    p.add_run("\t第 ")
    docx_add_page_field(p, "PAGE")
    p.add_run(" 页 / 共 ")
    docx_add_page_field(p, "NUMPAGES")
    p.add_run(" 页")
    p.add_run("\t" + DATE)
    for run in p.runs:
        docx_set_run_font(run, size=7.5, color=GRAY)


def docx_add_page_field(paragraph, field):
    run = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = f" {field} "
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.append(begin)
    run._r.append(instr)
    run._r.append(end)


def docx_table_widths(header, rows, total=16.2, min_cm=None):
    if min_cm is None:
        min_cm = 2.2 if len(header) <= 3 else 1.4
    weights = []
    for index in range(len(header)):
        values = [len(header[index])] + [len(row[index]) for row in rows]
        weights.append(max(3, min(55, max(values))))
    minimum = min_cm * len(header)
    remaining = max(0.0, total - minimum)
    return [
        min_cm + remaining * weight / sum(weights) for weight in weights
    ]


def docx_add_table(doc, header, rows, spec):
    widths = docx_table_widths(header, rows)
    table = doc.add_table(rows=1, cols=len(header))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    docx_table_borders(table)
    docx_set_cell_margins(table)
    hdr = table.rows[0]
    trPr = hdr._tr.get_or_add_trPr()
    tblHeader = OxmlElement("w:tblHeader")
    tblHeader.set(qn("w:val"), "true")
    trPr.append(tblHeader)
    for index, text in enumerate(header):
        cell = hdr.cells[index]
        cell.width = Cm(widths[index])
        docx_shade(cell, PRIMARY)
        p = cell.paragraphs[0]
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 1.05
        docx_add_inline(p, text, size=spec["table_font"], color="FFFFFF", bold=True)
    for r_index, row in enumerate(rows):
        cells = table.add_row().cells
        fill = "FFFFFF" if r_index % 2 == 0 else "FDF8F5"
        for c_index, text in enumerate(row):
            cell = cells[c_index]
            cell.width = Cm(widths[c_index])
            docx_shade(cell, fill)
            p = cell.paragraphs[0]
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.12
            color = None
            bold = False
            if text in ("P0", "P1", "P2", "P3"):
                color = {"P0": "C00000", "P1": "C55A11", "P2": "9C6500", "P3": GRAY}[text]
                bold = True
            docx_add_inline(p, text, size=spec["table_font"], color=color, bold=bold)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return table


def docx_cover(doc, spec):
    section = doc.sections[0]
    # orange top band
    band = doc.add_table(rows=1, cols=1)
    band.autofit = False
    cell = band.rows[0].cells[0]
    cell.width = Cm(16.6)
    band.rows[0].height = Cm(0.35)
    docx_shade(cell, PRIMARY)
    docx_set_cell_margins(band, 0, 0, 0, 0)
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    p.add_run(" ")

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(34)
    docx_add_inline(p, "臭皮匠小组  /  企业图片精修系统", size=9, color=GRAY)
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(20)
    docx_add_inline(p, spec["title"], size=25, color=DARK, bold=True)
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    docx_add_inline(p, spec["subtitle"], size=12.5, color=GRAY)
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(18)
    docx_add_inline(p, spec["label"], size=10.5, color=PRIMARY, bold=True)

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(42)
    docx_add_inline(
        p,
        "适用程序：精图快出 v2.5.0（主程序 / 管理员智能体）",
        size=9.5, color=GRAY,
    )

    meta = [
        ("文档版本", VERSION),
        ("发布日期", DATE),
        ("文档编号", spec["doc_id"]),
        ("文档状态", "正式版"),
        ("密级", "内部资料"),
    ]
    table = doc.add_table(rows=0, cols=2)
    table.autofit = False
    docx_table_borders(table)
    docx_set_cell_margins(table, 70, 110, 70, 110)
    for key, value in meta:
        cells = table.add_row().cells
        cells[0].width = Cm(4.0)
        cells[1].width = Cm(9.5)
        for cell in cells:
            p = cell.paragraphs[0]
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
        docx_add_inline(cells[0].paragraphs[0], key, size=9, color=GRAY)
        docx_add_inline(cells[1].paragraphs[0], value, size=9.5, color=DARK, bold=True)
        docx_shade(cells[0], "F7F9FB")

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(54)
    docx_add_inline(
        p,
        "本文件包含企业部署边界、账号安全、数据治理与操作指引，请按内部资料管理。",
        size=8.5, color=GRAY,
    )
    doc.add_page_break()


def docx_contents(doc, blocks, spec):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    docx_add_inline(p, "内容导览", size=19, color=DARK, bold=True)
    docx_border(p, "bottom", PRIMARY, 10)
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(4)
    docx_add_inline(p, "各章节页码见页脚；Word 中可通过导航窗格快速跳转。", size=8.5, color=GRAY)
    count = 0
    for kind, value in blocks:
        if kind == "h2":
            count += 1
            q = doc.add_paragraph()
            q.paragraph_format.space_before = Pt(7 if count > 1 else 3)
            q.paragraph_format.space_after = Pt(1)
            docx_add_inline(q, value, size=10.5, color=DARK, bold=True)
    doc.add_page_break()


def docx_build(spec):
    md_path = os.path.join(DOCS, spec["md"])
    blocks = parse_markdown(md_path)
    doc = Document()
    section = doc.sections[0]
    section.page_height = Cm(29.7)
    section.page_width = Cm(21.0)
    section.top_margin = Cm(2.2)
    section.bottom_margin = Cm(2.0)
    section.left_margin = Cm(2.2)
    section.right_margin = Cm(2.2)

    normal = doc.styles["Normal"]
    normal.font.name = "微软雅黑"
    normal.font.size = Pt(spec["body_font"])
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), "微软雅黑")
    normal.paragraph_format.line_spacing = 1.3
    normal.paragraph_format.space_after = Pt(4)

    for style_name, size, color in (
        ("Heading 1", 16, DARK),
        ("Heading 2", 12, PRIMARY),
    ):
        style = doc.styles[style_name]
        style.font.name = "微软雅黑"
        style.font.size = Pt(size)
        style.font.color.rgb = RGBColor.from_string(color)
        style.font.bold = True
        style.element.rPr.rFonts.set(qn("w:eastAsia"), "微软雅黑")
        style.paragraph_format.keep_with_next = True
        style.paragraph_format.space_before = Pt(8 if style_name == "Heading 2" else 12)
        style.paragraph_format.space_after = Pt(4)

    docx_header_footer(section, spec)
    if spec.get("simple"):
        band = doc.add_table(rows=1, cols=1)
        band.autofit = False
        cell = band.rows[0].cells[0]
        cell.width = Cm(16.6)
        band.rows[0].height = Cm(0.28)
        docx_shade(cell, PRIMARY)
        docx_set_cell_margins(band, 0, 0, 0, 0)
        p = cell.paragraphs[0]
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        p.add_run(" ")
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(18)
        docx_add_inline(p, spec["title"], size=24, color=DARK, bold=True)
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(2)
        docx_add_inline(p, spec["subtitle"], size=12, color=GRAY)
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(2)
        docx_add_inline(
            p, f"{VERSION} · {DATE} · 臭皮匠小组", size=8.5, color=GRAY
        )
        p = doc.add_paragraph()
        docx_border(p, "bottom", "F0D6C2", 8)
    else:
        docx_cover(doc, spec)
        docx_contents(doc, blocks, spec)

    first_h2 = True
    for kind, value in blocks:
        if kind == "h1":
            continue
        if kind == "h2":
            if (spec["force_h2_breaks"] and not first_h2
                    and any(value.startswith(prefix) for prefix in spec["break_prefixes"])):
                doc.add_page_break()
            first_h2 = False
            p = doc.add_paragraph(value, style="Heading 1")
            docx_border(p, "bottom", "F0D6C2", 6)
            continue
        if kind == "pagebreak":
            doc.add_page_break()
            continue
        if kind == "h3":
            doc.add_paragraph(value, style="Heading 2")
            continue
        if kind == "p":
            p = doc.add_paragraph()
            p.paragraph_format.first_line_indent = Cm(0.74)
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            docx_add_inline(p, value, size=spec["body_font"])
            continue
        if kind == "bullets":
            for item in value:
                p = doc.add_paragraph()
                p.paragraph_format.left_indent = Cm(0.62)
                p.paragraph_format.first_line_indent = Cm(-0.35)
                p.paragraph_format.space_after = Pt(2)
                docx_add_inline(p, "•  " + item, size=spec["body_font"])
            continue
        if kind == "numbers":
            for index, item in enumerate(value, 1):
                p = doc.add_paragraph()
                p.paragraph_format.left_indent = Cm(0.72)
                p.paragraph_format.first_line_indent = Cm(-0.45)
                p.paragraph_format.space_after = Pt(2)
                docx_add_inline(p, f"{index}.  " + item, size=spec["body_font"])
            continue
        if kind == "quote":
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.3)
            p.paragraph_format.right_indent = Cm(0.2)
            p.paragraph_format.space_before = Pt(4)
            p.paragraph_format.space_after = Pt(6)
            docx_shade(p, "FFF3E8")
            docx_border(p, "left", PRIMARY, 18)
            docx_add_inline(p, value, size=spec["body_font"] - 0.4)
            continue
        if kind == "code":
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.3)
            p.paragraph_format.space_before = Pt(4)
            p.paragraph_format.space_after = Pt(6)
            docx_shade(p, "F3F5F7")
            lines = value.splitlines()
            for index, line in enumerate(lines):
                run = p.add_run(line)
                docx_set_run_font(
                    run, "Consolas", 8.4, color=DARK, east_asia="微软雅黑"
                )
                if index < len(lines) - 1:
                    run.add_break()
            continue
        if kind == "table":
            header = value[0]
            rows = value[1:]
            docx_add_table(doc, header, rows, spec)
            continue
        if kind == "image":
            caption, rel = value
            path = os.path.normpath(os.path.join(DOCS, rel))
            if not os.path.isfile(path):
                continue
            with PILImage.open(path) as im:
                width, height = im.size
            draw_w = 9.0 if height > width else 15.0
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_before = Pt(4)
            p.paragraph_format.space_after = Pt(2)
            p.add_run().add_picture(path, width=Cm(draw_w))
            cap = doc.add_paragraph()
            cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
            cap.paragraph_format.space_after = Pt(8)
            docx_add_inline(cap, caption, size=8.5, color=GRAY)

    out = os.path.join(DOCS, spec["stem"] + ".docx")
    doc.save(out)
    print("DOCX:", out)
    return out


# ---------------------------------------------------------------------------
# PDF renderer
# ---------------------------------------------------------------------------
def register_fonts():
    candidates = [
        ("SimHei", r"C:\Windows\Fonts\simhei.ttf"),
        ("SimSun", r"C:\Windows\Fonts\simsun.ttc"),
        ("MSYaHei", r"C:\Windows\Fonts\msyh.ttc"),
    ]
    registered = []
    for name, path in candidates:
        if os.path.isfile(path):
            try:
                pdfmetrics.registerFont(TTFont(name, path))
                registered.append(name)
            except Exception:
                pass
    if not registered:
        raise RuntimeError("No Chinese font available")
    pdfmetrics.registerFontFamily(
        registered[0], normal=registered[0], bold=registered[0],
        italic=registered[0], boldItalic=registered[0],
    )
    return registered[0]


FONT = None


def pdf_escape(text):
    return (text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def pdf_inline(text):
    out = []
    for value, bold, code in inline_tokens(text):
        value = pdf_escape(value)
        if code:
            code_font = FONT if any("\u4e00" <= ch <= "\u9fff" for ch in value) else "Courier"
            value = f'<font name="{code_font}">{value}</font>'
        if bold:
            value = f"<b>{value}</b>"
        out.append(value)
    return "".join(out)


def pdf_styles(spec):
    styles = getSampleStyleSheet()
    body_size = spec["body_font"]
    return {
        "body": ParagraphStyle(
            "BodyCN", fontName=FONT, fontSize=body_size, leading=body_size * 1.55,
            firstLineIndent=body_size * 1.9, alignment=TA_JUSTIFY,
            wordWrap="CJK", spaceAfter=4.5, textColor=colors.HexColor("#26313D"),
        ),
        "bullet": ParagraphStyle(
            "BulletCN", fontName=FONT, fontSize=body_size, leading=body_size * 1.5,
            leftIndent=14, bulletIndent=3, wordWrap="CJK", spaceAfter=2.5,
            textColor=colors.HexColor("#26313D"),
        ),
        "h2": ParagraphStyle(
            "H2CN", fontName=FONT, fontSize=16, leading=21, textColor=colors.HexColor("#151E28"),
            spaceBefore=8, spaceAfter=7, keepWithNext=True,
        ),
        "h3": ParagraphStyle(
            "H3CN", fontName=FONT, fontSize=11.8, leading=16, textColor=colors.HexColor("#9C430B"),
            spaceBefore=8, spaceAfter=4, keepWithNext=True,
        ),
        "table": ParagraphStyle(
            "TableCN", fontName=FONT, fontSize=spec["table_font"],
            leading=spec["table_font"] * 1.38, wordWrap="CJK",
            textColor=colors.HexColor("#26313D"),
        ),
        "table_head": ParagraphStyle(
            "TableHeadCN", fontName=FONT, fontSize=spec["table_font"],
            leading=spec["table_font"] * 1.38, wordWrap="CJK",
            textColor=colors.white,
        ),
        "caption": ParagraphStyle(
            "CaptionCN", fontName=FONT, fontSize=8.3, leading=11,
            textColor=colors.HexColor("#5C6675"), alignment=TA_CENTER,
        ),
        "quote": ParagraphStyle(
            "QuoteCN", fontName=FONT, fontSize=body_size - 0.2, leading=body_size * 1.5,
            wordWrap="CJK", textColor=colors.HexColor("#7A3D13"),
        ),
    }


class DocTemplate(BaseDocTemplate):
    def __init__(self, filename, spec, **kwargs):
        self.simple = kwargs.pop("simple", False)
        self.spec = spec
        self.include_cover = not self.simple
        BaseDocTemplate.__init__(self, filename, **kwargs)
        body_frame = Frame(2.05 * cm, 1.95 * cm, A4[0] - 4.1 * cm, A4[1] - 4.0 * cm, id="body")
        if self.simple:
            self.addPageTemplates([
                PageTemplate(id="body", frames=[body_frame], onPage=self.draw_header),
            ])
        else:
            cover_frame = Frame(2.0 * cm, 2.0 * cm, A4[0] - 4.0 * cm, A4[1] - 4.0 * cm, id="cover")
            self.addPageTemplates([
                PageTemplate(id="cover", frames=[cover_frame], onPage=self.draw_cover),
                PageTemplate(id="body", frames=[body_frame], onPage=self.draw_header),
            ])

    def afterFlowable(self, flowable):
        if isinstance(flowable, Paragraph):
            style = flowable.style.name
            if style == "H2CN":
                text = flowable.getPlainText()
                self.notify("TOCEntry", (0, text, self.page))
                key = "h2-%d" % self.page
                self.canv.bookmarkPage(key)
                self.canv.addOutlineEntry(text, key, level=0, closed=False)

    def draw_cover(self, canv, doc):
        spec = self.spec
        w, h = A4
        canv.saveState()
        canv.setFillColor(colors.HexColor("#C55A11"))
        canv.rect(0, h - 2.2 * cm, w, 2.2 * cm, fill=1, stroke=0)
        canv.setFillColor(colors.white)
        canv.setFont(FONT, 11)
        canv.drawString(2.1 * cm, h - 1.35 * cm, "臭皮匠小组  /  企业图片精修系统")

        canv.setFillColor(colors.HexColor("#151E28"))
        canv.setFont(FONT, 25)
        title = spec["title"]
        if len(title) > 22:
            canv.setFont(FONT, 22)
        canv.drawString(2.1 * cm, h - 6.0 * cm, title)
        canv.setFillColor(colors.HexColor("#5C6675"))
        canv.setFont(FONT, 12)
        canv.drawString(2.1 * cm, h - 7.0 * cm, spec["subtitle"])
        canv.setFillColor(colors.HexColor("#C55A11"))
        canv.setFont(FONT, 10.5)
        canv.drawString(2.1 * cm, h - 8.0 * cm, spec["label"])

        canv.setFillColor(colors.HexColor("#EDF0F3"))
        canv.rect(2.1 * cm, h - 9.0 * cm, w - 4.2 * cm, 0.04 * cm, fill=1, stroke=0)

        meta = [
            ("文档版本", VERSION),
            ("发布日期", DATE),
            ("文档编号", spec["doc_id"]),
            ("适用程序", "精图快出 v2.5.0 / 管理员智能体"),
            ("密级", "内部资料 · 正式版"),
        ]
        y = h - 10.5 * cm
        for key, value in meta:
            canv.setFillColor(colors.HexColor("#7A8592"))
            canv.setFont(FONT, 9)
            canv.drawString(2.1 * cm, y, key)
            canv.setFillColor(colors.HexColor("#26313D"))
            canv.setFont(FONT, 9.5)
            canv.drawString(5.4 * cm, y, value)
            y -= 0.78 * cm

        canv.setFillColor(colors.HexColor("#7A8592"))
        canv.setFont(FONT, 8.2)
        canv.drawString(
            2.1 * cm, 2.0 * cm,
            "本文件包含企业部署边界、账号安全、数据治理与操作指引，请按内部资料管理。",
        )
        canv.setFillColor(colors.HexColor("#C55A11"))
        canv.rect(0, 0, w, 0.45 * cm, fill=1, stroke=0)
        canv.restoreState()

    def draw_header(self, canv, doc):
        spec = self.spec
        w, h = A4
        canv.saveState()
        canv.setFillColor(colors.HexColor("#5C6675"))
        canv.setFont(FONT, 7.8)
        canv.drawString(2.05 * cm, h - 1.25 * cm, spec["title"])
        canv.drawRightString(w - 2.05 * cm, h - 1.25 * cm, f"{VERSION} · {spec['label']}")
        canv.setStrokeColor(colors.HexColor("#E4E9EF"))
        canv.setLineWidth(0.5)
        canv.line(2.05 * cm, h - 1.45 * cm, w - 2.05 * cm, h - 1.45 * cm)
        canv.restoreState()


class NumberedCanvas(rl_canvas.Canvas):
    def __init__(self, *args, **kwargs):
        self.simple = kwargs.pop("simple", False)
        rl_canvas.Canvas.__init__(self, *args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        total = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            if self._pageNumber > 1 or self.simple:
                self.draw_footer(total)
            rl_canvas.Canvas.showPage(self)
        rl_canvas.Canvas.save(self)

    def draw_footer(self, total):
        w, h = A4
        self.saveState()
        self.setStrokeColor(colors.HexColor("#E4E9EF"))
        self.setLineWidth(0.5)
        self.line(2.05 * cm, 1.55 * cm, w - 2.05 * cm, 1.55 * cm)
        self.setFillColor(colors.HexColor("#7A8592"))
        self.setFont(FONT, 7.5)
        self.drawString(2.05 * cm, 1.15 * cm, "内部资料 · 请按企业数据分级管理")
        self.drawCentredString(w / 2.0, 1.15 * cm, f"第 {self._pageNumber} 页 / 共 {total} 页")
        self.drawRightString(w - 2.05 * cm, 1.15 * cm, DATE)
        self.restoreState()


def pdf_cell(text, style, header=False):
    if not text:
        return Paragraph("", style)
    return Paragraph(pdf_inline(text), style)


def pdf_add_table(story, header, rows, spec, styles):
    total = 16.4 * cm
    min_cm = 2.2 if len(header) <= 3 else 1.4
    weights = []
    for index in range(len(header)):
        values = [len(header[index])] + [len(row[index]) for row in rows]
        weights.append(max(3, min(55, max(values))))
    minimum = min_cm * cm * len(header)
    remaining = max(0.0, total - minimum)
    widths = [
        min_cm * cm + remaining * weight / sum(weights) for weight in weights
    ]
    data = [[pdf_cell(cell, styles["table_head"], True) for cell in header]]
    for row in rows:
        data.append([pdf_cell(cell, styles["table"]) for cell in row])
    table = LongTable(data, colWidths=widths, repeatRows=1)
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#C55A11")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#E1E6EC")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    for index in range(1, len(data)):
        if index % 2 == 0:
            style.append(("BACKGROUND", (0, index), (-1, index), colors.HexColor("#FDF8F5")))
    table.setStyle(TableStyle(style))
    story.append(table)
    story.append(Spacer(1, 0.22 * cm))


def pdf_build(spec):
    global FONT
    if FONT is None:
        FONT = register_fonts()
    md_path = os.path.join(DOCS, spec["md"])
    blocks = parse_markdown(md_path)
    styles = pdf_styles(spec)
    out = os.path.join(DOCS, spec["stem"] + ".pdf")
    simple = bool(spec.get("simple"))
    doc = DocTemplate(
        out, spec, simple=simple, pagesize=A4,
        title=spec["title"], author="臭皮匠小组",
        subject=spec["subtitle"], creator="精图快出文档生成器",
    )

    if simple:
        story = [
            Paragraph(pdf_escape(spec["title"]), ParagraphStyle(
                "BriefTitle", fontName=FONT, fontSize=23, leading=30,
                textColor=colors.HexColor("#151E28"), spaceAfter=4,
            )),
            Paragraph(pdf_escape(spec["subtitle"]), ParagraphStyle(
                "BriefSub", fontName=FONT, fontSize=11.5, leading=16,
                textColor=colors.HexColor("#5C6675"), spaceAfter=3,
            )),
            Paragraph(
                f"{VERSION} · {DATE} · 臭皮匠小组",
                ParagraphStyle("BriefMeta", fontName=FONT, fontSize=8.5, leading=12,
                               textColor=colors.HexColor("#7A8592"), spaceAfter=10),
            ),
            Spacer(1, 0.25 * cm),
        ]
    else:
        story = [NextPageTemplate("body"), PageBreak()]
        # cover is drawn by the cover PageTemplate; body starts after one break
        toc_title = Paragraph("内容导览", ParagraphStyle(
            "TOCTitle", fontName=FONT, fontSize=19, leading=26,
            textColor=colors.HexColor("#151E28"), spaceAfter=4,
        ))
        story.append(toc_title)
        story.append(Paragraph(
            "各章节页码见页脚；本目录由文档生成器自动更新。",
            ParagraphStyle("TOCNote", fontName=FONT, fontSize=8.5, leading=12,
                           textColor=colors.HexColor("#7A8592"), spaceAfter=8),
        ))
        toc = TableOfContents()
        toc.levelStyles = [
            ParagraphStyle("TOC0", fontName=FONT, fontSize=10.5, leading=20,
                           leftIndent=0, firstLineIndent=0,
                           textColor=colors.HexColor("#26313D")),
        ]
        toc.dotsMinLevel = 0
        story.append(toc)
        story.append(PageBreak())

    first_h2 = True
    for kind, value in blocks:
        if kind == "h1":
            continue
        if kind == "h2":
            if not first_h2:
                if (spec["force_h2_breaks"]
                        and any(value.startswith(prefix) for prefix in spec["break_prefixes"])):
                    story.append(PageBreak())
                else:
                    story.append(CondPageBreak(5.0 * cm))
            first_h2 = False
            story.append(Paragraph(pdf_escape(value), styles["h2"]))
            continue
        if kind == "pagebreak":
            story.append(PageBreak())
            continue
        if kind == "h3":
            story.append(Paragraph(pdf_escape(value), styles["h3"]))
            continue
        if kind == "p":
            story.append(Paragraph(pdf_inline(value), styles["body"]))
            continue
        if kind == "bullets":
            for item in value:
                story.append(Paragraph(
                    pdf_inline(item), styles["bullet"], bulletText="•"
                ))
            story.append(Spacer(1, 0.08 * cm))
            continue
        if kind == "numbers":
            for index, item in enumerate(value, 1):
                story.append(Paragraph(
                    pdf_inline(item), styles["bullet"], bulletText=f"{index}."
                ))
            story.append(Spacer(1, 0.08 * cm))
            continue
        if kind == "quote":
            cell = Paragraph(pdf_inline(value), styles["quote"])
            table = Table([[cell]], colWidths=[16.4 * cm])
            table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#FFF3E8")),
                ("LINEBEFORE", (0, 0), (0, -1), 3, colors.HexColor("#C55A11")),
                ("LEFTPADDING", (0, 0), (-1, -1), 9),
                ("RIGHTPADDING", (0, 0), (-1, -1), 9),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]))
            story.append(table)
            story.append(Spacer(1, 0.2 * cm))
            continue
        if kind == "code":
            code_font = FONT if any(
                "\u4e00" <= ch <= "\u9fff" for ch in value
            ) else "Courier"
            cell = Preformatted(
                value, ParagraphStyle(
                    "CodeCN", fontName=code_font, fontSize=7.8, leading=10.5,
                    textColor=colors.HexColor("#26313D"),
                ),
            )
            table = Table([[cell]], colWidths=[16.4 * cm])
            table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F3F5F7")),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]))
            story.append(table)
            story.append(Spacer(1, 0.2 * cm))
            continue
        if kind == "table":
            pdf_add_table(story, value[0], value[1:], spec, styles)
            continue
        if kind == "image":
            caption, rel = value
            path = os.path.normpath(os.path.join(DOCS, rel))
            if not os.path.isfile(path):
                continue
            with PILImage.open(path) as im:
                iw, ih = im.size
            max_w = 9.0 * cm if ih > iw else 15.2 * cm
            max_h = 10.2 * cm
            width = max_w
            height = width * ih / iw
            if height > max_h:
                height = max_h
                width = height * iw / ih
            story.append(Image(path, width=width, height=height))
            story.append(Paragraph(pdf_escape(caption), styles["caption"]))
            story.append(Spacer(1, 0.3 * cm))
            continue

    doc.multiBuild(
        story,
        canvasmaker=lambda *a, **k: NumberedCanvas(*a, simple=simple, **k),
    )
    print("PDF:", out)
    return out


if __name__ == "__main__":
    flatten_assets()
    for spec in SPECS:
        docx_build(spec)
        pdf_build(spec)
