# build_exe.py
# 一键打包：主程序 + 管理员智能体
# 用法：python build_exe.py

import os
import subprocess
import sys


def _ensure_ascii_python():
    """
    PyInstaller 的 Qt 钩子在中文安装路径下无法解析 PyQt5 插件目录。
    当前解释器路径含非 ASCII 字符时，自动创建英文目录联接并重新执行本脚本。
    """
    if all(ord(ch) < 128 for ch in sys.executable):
        return
    link = r"C:\py39"
    if not os.path.isdir(link):
        print(f"检测到 Python 路径包含中文，创建目录联接 {link} -> {sys.prefix}", flush=True)
        result = subprocess.run(
            ["cmd", "/c", "mklink", "/J", link, sys.prefix],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        if result.returncode != 0 or not os.path.isdir(link):
            print(f'创建联接失败，请手动执行：mklink /J {link} "{sys.prefix}"')
            sys.exit(1)
    sys.exit(subprocess.run(
        [os.path.join(link, "python.exe"), os.path.abspath(__file__)] + sys.argv[1:]
    ).returncode)


_ensure_ascii_python()

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, "src")
DIST = os.path.join(ROOT, "dist")
BUILD = os.path.join(ROOT, "build")
ICON = os.path.join(ROOT, "assets", "app.ico")

APPS = [
    ("app_main.py", "精图快出", os.path.join(ROOT, "assets", "version_main.txt")),
    ("admin_main.py", "精图快出_管理员智能体",
     os.path.join(ROOT, "assets", "version_admin.txt")),
]

for entry, name, version_file in APPS:
    work = os.path.join(BUILD, name)
    spec_dir = os.path.join(BUILD, "spec")
    os.makedirs(spec_dir, exist_ok=True)
    args = [
        "-m", "PyInstaller",
        os.path.join(SRC, entry),
        f"--name={name}",
        "--noconfirm",
        "--clean",
        "--windowed",
        "--onedir",
        "--paths", SRC,
        "--distpath", DIST,
        "--workpath", work,
        "--specpath", spec_dir,
        "--add-data", os.path.join(ROOT, "assets", "app.ico") + os.pathsep + "assets",
        f"--icon={ICON}",
        f"--version-file={version_file}",
        "--exclude-module=tkinter",
    ]
    print(f"\n===== 正在打包：{name} =====", flush=True)
    result = subprocess.run([sys.executable] + args)
    if result.returncode != 0:
        print(f"打包失败：{name}", flush=True)
        sys.exit(result.returncode)
    print(f"打包完成：{os.path.join(DIST, name)}", flush=True)

# 分发说明
guide = os.path.join(DIST, "使用说明.txt")
with open(guide, "w", encoding="utf-8") as f:
    f.write(
        "精图快出 · 双端系统 v2.5.0\n"
        "===============================\n\n"
        "1. 先打开「精图快出_管理员智能体」→ 注册账号，填写员工姓名。\n"
        "   初始密码固定为 12345678。\n\n"
        "2. 再打开「精图快出」→ 使用「姓名 + 12345678」登录。\n"
        "   首次登录必须重置为字母 + 数字组合的新密码。\n\n"
        "3. 界面已按原尺寸的 2/3 缩放，适配笔记本、台式机与平板；\n"
        "   窗口可自由调整大小或最大化，主程序和管理员页面支持滚动。\n\n"
        "4. 选择或拖拽图片（支持多选/多张批量），点击「渲染参数」调整\n"
        "   亮度、对比度、阴影、高光、饱和度、色温、锐化、降噪、暗角、\n"
        "   投影与放大倍数；可切换局部渲染框选区域。\n\n"
        "5. 批量处理会逐张显示进度，可取消；完成后给出成功/失败汇总，\n"
        "   每张图片都有独立修改记录。输出为 sRGB PNG，保留 DPI 与透明通道。\n\n"
        "6. 两个程序共用数据目录：\n"
        "   %LOCALAPPDATA%\\JingTuKuaiChu\\jingtu.db\n"
        "   日志：logs  备份：backups\n\n"
        "7. 主程序没有自助注册入口，未在管理员端注册的姓名无法登录。\n\n"
        "8. 管理员端不设登录页，请仅在管理员电脑上保留。\n\n"
        "9. 员工忘记密码或账号锁定：管理员端 → 员工管理 → 打开员工，\n"
        "   可「重置密码」（恢复 12345678，保留历史）或「解除登录锁定」。\n"
        "   账号被停用/删除后，主程序最长 15 秒内自动退出，批量任务立即停止。\n\n"
        "10. 导出 CSV 已做公式注入转义；姓名不支持尖括号和不可见字符。\n"
    )
print("分发说明已写入：", guide, flush=True)
