# 精图快出应用

企业级 Windows 图片精修双端应用：员工端负责选图、参数渲染、局部精修、批量生成与下载；管理端负责账号开通、员工管理、停用/删除、解锁/重置密码、审计与备份。

> **重要：GitHub 网页不能直接运行 Windows exe。**  
> 点击 `.exe` 时 GitHub 只会显示“二进制文件/无法预览”，点击 ZIP 可能提示“不能展示这么大的档案”。这是 GitHub 的文件预览限制，不是程序损坏。请下载整个应用文件夹（或 clone 仓库）后在 Windows 上运行。
>
> **不能只下载 exe。** exe 需要同目录的 `其余文件/` 运行依赖，缺一不可；请保留 `员工端/` 或 `管理端/` 整个文件夹。

## 目录结构

```text
精图快出应用/
├── README.md
├── 员工端/
│   ├── 精图快出.exe
│   ├── 使用手册.pdf
│   ├── 项目简介.pdf
│   └── 其余文件/              # PyInstaller 运行依赖、Word 文档、问题清单、源码归档
└── 管理端/
    ├── 精图快出_管理员智能体.exe
    ├── 使用手册.pdf
    ├── 项目简介.pdf
    └── 其余文件/
```

## 下载与运行

### 方式一：git clone（推荐）

```bash
git clone https://github.com/lipengcheng2002/zuo_pin_ji.git
cd zuo_pin_ji/精图快出应用/员工端
# Windows 双击 精图快出.exe
```

管理端：

```bash
cd zuo_pin_ji/精图快出应用/管理端
# Windows 双击 精图快出_管理员智能体.exe
```

### 方式二：下载仓库 ZIP

1. 在 GitHub 仓库页点击 **Code → Download ZIP**；
2. 解压后进入 `精图快出应用/员工端`；
3. 双击 `精图快出.exe`；
4. 不要移动 exe 或删除 `其余文件/`。

首次使用：先打开管理端注册员工账号（初始密码 `12345678`），再由员工端登录并完成首次改密。详细步骤见 `员工端/使用手册.pdf`。

## 技术栈

| 层次 | 技术 | 说明 |
| --- | --- | --- |
| 语言/运行时 | Python 3.9 | 业务逻辑、数据访问、图像处理、打包入口 |
| 桌面界面 | PyQt5 5.15 | 双端窗口、信号槽、QThread、对话框/表格 |
| 数据层 | SQLite 3 | WAL、外键、索引、事务、分页、schema v3 |
| 认证安全 | hashlib / secrets | PBKDF2-SHA256 120,000 次 + 随机盐、失败锁定、首登改密 |
| 图像引擎 | Pillow 9.5 + NumPy 1.24 | ICC→sRGB、透明通道、光影色彩、局部蒙版、投影、2x |
| 并发任务 | QThread + pyqtSignal | 批量队列、逐张进度、取消、账号状态检查 |
| 打包 | PyInstaller 6.11 | Windows onedir，自定义 `其余文件` 依赖目录 |
| 测试 | unittest + 自研审查 | 8 项单元测试、279 项 × 5 轮流程审查、259 按钮审查 |

### Python 后端模块

- `core/auth.py`：账号开通、登录、PBKDF2 密码校验、首登改密、锁定/解锁、重置密码。
- `core/models.py`：SQLite 连接、WAL、外键、schema v3 迁移、事务上下文。
- `core/repo.py`：参数化查询、分页/筛选、员工与记录统计、删除级联。
- `core/audit.py`：追加式审计日志，登录/生成/导出/备份/停用/删除等留痕。
- `core/backup.py`：SQLite 在线备份，保留最近 10 份。
- `core/render_params.py`：渲染参数模型、范围校验、JSON 持久化。
- `utils/engine.py`：图片解码、色彩管理、局部蒙版、投影、原子写出。
- `BatchRenderWorker`：后台批量任务、逐张进度、取消与账号状态检查。

当前是“桌面 UI + 内嵌 Python 后端”的单机形态，不提供 HTTP API。多机部署的演进路径是抽取 `core` 业务服务为 FastAPI + PostgreSQL + 对象存储 + 任务队列，桌面端保留为客户端。

## 文档

- 员工端使用手册：`员工端/使用手册.pdf`
- 管理端使用手册：`管理端/使用手册.pdf`
- 项目简介：`员工端/项目简介.pdf`、`管理端/项目简介.pdf`
- 企业级使用问题清单（63 项）：`员工端/其余文件/文档源文件/企业级使用问题清单.pdf`
- 可编辑 Word 版、源码归档、程序 SHA256：各角色 `其余文件/` 内

## 部署边界

- 默认数据目录：`%LOCALAPPDATA%\JingTuKuaiChu`，按 Windows 用户隔离。
- 管理端与员工端只有在同一台电脑、同一 Windows 用户下（或同一 `JTKC_DATA_DIR`）才共享数据；跨电脑不会自动同步。
- 管理端没有登录页，请只在受控电脑上使用。
- 数据库、备份、图片未加密；建议 BitLocker/EFS、ACL、加密备份。
- 两个 exe 未做代码签名；Smart App Control 强制环境可能需要签名或 IT 允许列表。

## 版本

v2.5.0 · 2026-10-28 · 臭皮匠小组
